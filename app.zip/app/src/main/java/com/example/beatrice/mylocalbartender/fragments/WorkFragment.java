package com.example.beatrice.mylocalbartender.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabItem;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.beatrice.mylocalbartender.R;

/**
 * Created by Umar on 07/03/2017.
 * This is the base fragment that will nest the {@link EventFragment} and the {@link JobsFragment}
 * This fragment decided at run time to show both fragments or just one
 */

public class WorkFragment extends android.app.Fragment {


    private android.app.Fragment jobsOrWorkFragment;
    private int tabPosition;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        if (savedInstanceState != null) {

            tabPosition = (int) savedInstanceState.get("Tab");
            if(tabPosition==0){
                jobsOrWorkFragment = new JobsFragment();

            }else{
                jobsOrWorkFragment = new EventFragment();
            }

        }else{
            jobsOrWorkFragment = new JobsFragment();

        }



    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.work_fragment, null, false);

        //TabLayout.Tab jobsTab = (TabLayout.Tab) view.findViewById(R.id.jobsTab);

        getChildFragmentManager().beginTransaction().replace(R.id.work_container, jobsOrWorkFragment).commit();

        // I will not have to change this view I just have to remove

        // I do not think I need to that
        //getChildFragmentManager().beginTransaction().replace(R.id.work_container, jobsOrWorkFragment).commit();

        TabLayout tabLayout = (TabLayout) view.findViewById(R.id.tab_layout_for_work_fragment);
        TabLayout.Tab jobTab = tabLayout.getTabAt(0);
        TabLayout.Tab eventTab = tabLayout.getTabAt(1);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                jobsOrWorkFragment = null;
                switch (tab.getPosition()) {
                    case 0:
                        tabPosition = tab.getPosition();

                        jobsOrWorkFragment = new JobsFragment();
                        break;
                    case 1:
                        tabPosition = tab.getPosition();
                        jobsOrWorkFragment = new EventFragment();
                        break;
                    default:
                        break;
                }
                if (jobsOrWorkFragment != null) {
                    getChildFragmentManager().beginTransaction().replace(R.id.work_container, jobsOrWorkFragment).commit();
                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {


            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {


            }
        });


        switch (tabPosition) {
            case 0:
                jobTab.select();
                break;
            case 1:
                eventTab.select();
                break;
        }
        return view;

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {


        outState.putSerializable("Tab", tabPosition);


    }


    // a fragement withing a fragment


}
