package com.example.beatrice.mylocalbartender.async;

import android.app.NotificationManager;
import android.content.Context;
import android.os.AsyncTask;
import android.support.v4.app.NotificationCompat;

import com.example.beatrice.mylocalbartender.R;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.NameValuePair;
import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.client.entity.UrlEncodedFormEntity;
import cz.msebera.android.httpclient.client.methods.HttpPost;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;
import cz.msebera.android.httpclient.message.BasicNameValuePair;

/**
 * Created by bea on 10/03/2017.
 * Allows notification to be recieved from the server
 */

public class AsyncMessagingNotifs extends AsyncTask<String, Void, Void> {

    private Context mContext;


    @Override
    protected Void doInBackground(String... params) {


        //send notification
        try {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://mlb-server.herokuapp.com/message");

            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(3);
            nameValuePairs.add(new BasicNameValuePair("uniqueIDreceiver", params[0]));
            nameValuePairs.add(new BasicNameValuePair("nameOfSender", params[1]));
            nameValuePairs.add(new BasicNameValuePair("bodyMessage", params[2] ));
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

            // Execute HTTP Post Request
            HttpResponse response = httpclient.execute(httppost);

            BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            sb.append(reader.readLine() + "\n");
            String line = "0";
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            reader.close();
            String result11 = sb.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Send notifications as a result of a received FCM message
//        sendNotification("New Message from " + params[1], params[2]);

        return null;

    }

    /**
     * Create and show a simple notification containing the received FCM message.
     *
     * @param message FCM message body received.
     */
    private void sendNotification(String title, String message) {
       // Intent intent = new Intent(, LoginActivity1.class);
        //build notification
        //intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        //PendingIntent pIntent = PendingIntent.getActivity(this,0,intent, PendingIntent.FLAG_ONE_SHOT);

        NotificationCompat.Builder notBuilder = new NotificationCompat.Builder(mContext);
        notBuilder.setSmallIcon(R.drawable.message_nav_bar);
        notBuilder.setContentTitle(title);
        notBuilder.setContentText(message);
        notBuilder.setAutoCancel(true);
        //notBuilder.setContentIntent(pIntent);
        NotificationManager nManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        nManager.notify(null, 0, notBuilder.build());
    }
}
