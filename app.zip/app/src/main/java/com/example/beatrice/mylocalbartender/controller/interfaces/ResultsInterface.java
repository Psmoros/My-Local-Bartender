package com.example.beatrice.mylocalbartender.controller.interfaces;

import com.example.beatrice.mylocalbartender.model.Job;

/**
 * Created by Umar on 02/03/2017.
 * This interface is designed to de couple adapters from the model package
 * Every adapter should implement this interface
 *
 */

public interface ResultsInterface<E> {

    void addToList(E e);

    void notifyEmptyDataSet();

    void notifyDataChanged(E e);

    void removeFromList(E e);



}
