package com.example.beatrice.mylocalbartender.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.database.DBCallback;
import com.example.beatrice.mylocalbartender.database.DBReader;
import com.example.beatrice.mylocalbartender.database.DBWriter;
import com.example.beatrice.mylocalbartender.firebase.Callback;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Created by louis on 18/03/17.
 * This class acts as the loading class  unitl all information is loaded
 */

public class SplashActivity extends AppCompatActivity {

    private static DatabaseReference root = FirebaseDatabase.getInstance().getReference();
    private FirebaseManagement firebaseManagement = FirebaseManagement.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

      /*  LayerDrawable ld = (LayerDrawable) getResources().getDrawable(R.drawable.loading_screen_drawable);
        Drawable blinkingLogoDrawable = (Drawable) ld.findDrawableByLayerId(R.id.blinking_logo);

        ImageView blinkingLogo = (ImageView) findViewById(R.id.blinking_logo);

        final Animation animation = new AlphaAnimation((float)0.5, 0);
        animation.setDuration(1000);
        animation.setInterpolator(new LinearInterpolator());
        animation.setRepeatCount(Animation.INFINITE);
        animation.setRepeatMode(Animation.REVERSE);
        blinkingLogoDrawable.startAnimation(animation);*/

        if(FirebaseAuth.getInstance().getCurrentUser() != null){
            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            FirebaseManagement.getInstance().setUniversalUser(root.child("Users").child(uid), new Callback() {
                @Override
                public void loginSuccessful() {

                    firebaseManagement.instantiateLocalDB(getApplicationContext());

                    Intent intent = new Intent(SplashActivity.this, MainNavigationActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                }

                @Override
                public void loginFailed() {
                    Toast.makeText(SplashActivity.this, "No Internet Connection",
                            Toast.LENGTH_LONG).show();
                }
            });

        }else{
            Intent intent = new Intent(SplashActivity.this, LoginActivity1.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        }
    }
}

