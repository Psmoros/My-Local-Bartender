package com.example.beatrice.mylocalbartender.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.beatrice.mylocalbartender.model.Bartender;
import com.example.beatrice.mylocalbartender.utils.Colours;
import com.example.beatrice.mylocalbartender.utils.MyFlowLayout;
import com.example.beatrice.mylocalbartender.utils.alertDialog.GeneralDialogFragment;
import com.example.beatrice.mylocalbartender.utils.async.AsyncLocation;
import com.example.beatrice.mylocalbartender.controller.ProfilePicManager;
import com.example.beatrice.mylocalbartender.database.DBCallback;
import com.example.beatrice.mylocalbartender.database.DBReader;
import com.example.beatrice.mylocalbartender.database.DBWriter;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.model.Pair;
import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.utils.RegexCheckUtils;
import com.example.beatrice.mylocalbartender.utils.alertDialog.GeneralDialogFragment;
import com.example.beatrice.mylocalbartender.utils.async.AsyncLocation;
import com.firebase.geofire.GeoFire;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

/**
 * This class is the profile settings for the bartender and contains all the controls that allows
 * one to change his/her details
 */
public class BartenderProfileSettings extends AppCompatActivity implements GeneralDialogFragment.OnDialogFragmentClickListener  {

    private View changePasswordButton, maleButton, femaleButton, maleSelected, femaleSelected, checkEmail, save, manageDaysButton;

    private Button done_button, hide_profile, delete_account, view_profile;

    private LayoutInflater inflater;

    private static int RESULT_LOAD_IMAGE = 1;

    private EditText lastNameField, emailField, phoneField, dobField, postCodeField, barExperienceField, ratePerHourField, nigtlyRateField, firstNameField, fromTextView, toTextView, specialitiesEditText;

    private ImageButton sign_out, profilPic, addSpecialityButton;

    private PopupWindow mPopupWindow;

    private String gender;

    private int day;

    private TextView dayTextView;

    private MyFlowLayout flowLayoutForHours, specialitiesFlowLayout;

    private boolean loggedInViaFB = false;

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference root = database.getReference();

    private DatabaseReference geoFireRef = root.child("GeoFire");
    private FirebaseAuth auth;
    private GeoFire geoFire;
    private FirebaseUser user;
    private FirebaseStorage storage = FirebaseStorage.getInstance();
    private StorageReference storageRef = storage.getReference();
    private StorageReference profilePicRef = storageRef.child("ProfilePictures");
    private FirebaseManagement firebaseManagement = FirebaseManagement.getInstance();

    private Button colourButton1, colourButton2, colourButton3, colourButton4, colourButton5, colourButton6, colourButton7, colourButton8, colourButton9, colourButton10;
    private CoordinatorLayout layout1;

    private Bartender bartender;
    private boolean hideProfile = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bartender_profile_settings);
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();

        //Getting the different views from Resources

        view_profile = (Button) findViewById(R.id.view_profile_button);
        delete_account = (Button) findViewById(R.id.delete_account_button);
        hide_profile = (Button) findViewById(R.id.hide_profile_button);
        done_button = (Button) findViewById(R.id.done_button);
        sign_out = (ImageButton) findViewById(R.id.sign_out_image_button);
        checkEmail = (ImageView) findViewById(R.id.check_email);
        changePasswordButton = (Button) findViewById(R.id.change_password_button);
        firstNameField = (EditText) findViewById(R.id.edit_text_firstName);
        femaleButton = (Button) findViewById(R.id.female_button);
        maleSelected = (ImageView) findViewById(R.id.male_selected);
        femaleSelected = (ImageView) findViewById(R.id.female_selected);
        maleButton = (Button) findViewById(R.id.male_button);
        lastNameField = (EditText) findViewById(R.id.edit_text_lastName);
        emailField = (EditText) findViewById(R.id.edit_text_email);
        phoneField = (EditText) findViewById(R.id.edit_text_phone);
        dobField = (EditText) findViewById(R.id.edit_text_dob);
        barExperienceField = (EditText) findViewById(R.id.edit_text_bar_experience);
        ratePerHourField = (EditText) findViewById(R.id.edit_text_rate_per_hour);
        nigtlyRateField = (EditText) findViewById(R.id.edit_text_rate_per_night);
        postCodeField = (EditText) findViewById(R.id.edit_text_postcode);
        specialitiesEditText = (EditText) findViewById(R.id.edit_text_speciality_tags);
        addSpecialityButton = (ImageButton) findViewById(R.id.add_speciality_button);
        specialitiesFlowLayout = (MyFlowLayout) findViewById(R.id.speciality_flow_layout);
        save = (Button) findViewById(R.id.save_button);
        profilPic = (ImageButton) findViewById(R.id.profile_settings_profile_picture_button);
        manageDaysButton = (Button) findViewById(R.id.button_manage_days);

        colourButton1 = (Button) findViewById(R.id.button1);
        colourButton2 = (Button) findViewById(R.id.button2);
        colourButton3 = (Button) findViewById(R.id.button3);
        colourButton4 = (Button) findViewById(R.id.button4);
        colourButton5 = (Button) findViewById(R.id.button5);
        colourButton6 = (Button) findViewById(R.id.button6);
        colourButton7 = (Button) findViewById(R.id.button7);
        colourButton8 = (Button) findViewById(R.id.button8);
        colourButton9 = (Button) findViewById(R.id.button9);
        colourButton10 = (Button) findViewById(R.id.button10);

        layout1 = (CoordinatorLayout) findViewById(R.id.bartender_profile_settings_linearlayout);
        if(Colours.isDefault == false) {
            layout1.setBackgroundColor(Color.parseColor(Colours.backgroundColour));
        }

        colourButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#263238"));
                Colours.backgroundColour = "#263238";
                Colours.isDefault = false;
            }
        });
        colourButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#455A64"));
                Colours.backgroundColour = "#455A64";
                Colours.isDefault = false;

            }
        });
        colourButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#4c4c4c"));
                Colours.backgroundColour = "#4c4c4c";
                Colours.isDefault = false;
            }
        });
        colourButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#424242"));
                Colours.backgroundColour = "#424242";
                Colours.isDefault = false;
            }
        });
        colourButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#37474F"));
                Colours.backgroundColour = "#37474F";
                Colours.isDefault = false;
            }
        });
        colourButton6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#323232"));
                Colours.backgroundColour = "#323232";
                Colours.isDefault = false;
            }
        });
        colourButton7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#2f3f4f"));
                Colours.backgroundColour = "#2f3f4f";
                Colours.isDefault = false;
            }
        });
        colourButton8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#212121"));
                Colours.backgroundColour = "#212121";
                Colours.isDefault = false;
            }
        });
        colourButton9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#004d66"));
                Colours.backgroundColour = "#004d66";
                Colours.isDefault = false;
            }
        });
        colourButton10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#00394d"));
                Colours.backgroundColour = "#00394d";
                Colours.isDefault = false;
            }
        });


        final Animation fadeInAnimation = AnimationUtils.loadAnimation(this, R.anim.fade_in);

            geoFire = new GeoFire(geoFireRef);

            bartender = (Bartender) firebaseManagement.currentUser;
            //displayInfoFromDB();
            displayInfoFromLocalDB();

           if(firebaseManagement.loggedInViaFB()){
                loggedInViaFB = true;
                hideFields();
            }

            //Start changePassword alert dialog when clicking on this button
            changePasswordButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showChangePasswordAlertDialog();
                }
            });


            //settings listeners on click events and update the gender of the user
            maleButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    gender = "male";
                    femaleSelected.clearAnimation();
                    femaleSelected.setSystemUiVisibility(View.INVISIBLE);
                    femaleSelected.setVisibility(View.INVISIBLE);
                    maleSelected.startAnimation(fadeInAnimation);
                    maleSelected.setVisibility(View.VISIBLE);
                    if(checkDefaultProfilePicture()){
                        profilPic.setBackground(getResources().getDrawable(R.drawable.profile_icon_male));
                    }
                }
            });

            femaleButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    gender = "female";
                    maleSelected.clearAnimation();
                    maleSelected.setSystemUiVisibility(View.INVISIBLE);
                    maleSelected.setVisibility(View.INVISIBLE);
                    femaleSelected.startAnimation(fadeInAnimation);
                    femaleSelected.setVisibility(View.VISIBLE);
                    if(checkDefaultProfilePicture()){
                        profilPic.setBackground(getResources().getDrawable(R.drawable.profile_icon_female));
                    }
                }
            });

            delete_account.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showDeleteAccountAlertDialog();
                }
            });

            done_button.setOnClickListener(new View.OnClickListener() { //TODO
                @Override
                public void onClick(View v) {
                   if(!loggedInViaFB){
                        if(RegexCheckUtils.checkEmail(emailField, checkEmail, BartenderProfileSettings.this)) {
                            updateInfo();
                        }
                   }else{
                       updateInfo();
                   }
                    Intent intent = new Intent(BartenderProfileSettings.this, MainNavigationActivity.class);
                    startActivity(intent);
                }
            });

            //Button to sign_out
            sign_out.setOnClickListener(new View.OnClickListener() { //TODO
                @Override
                public void onClick(View v) {
                    showLogOutDialog();
                }
            });

            //Button to save all the fields in the DB
            save.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(!loggedInViaFB){
                        if(RegexCheckUtils.checkEmail(emailField, checkEmail, BartenderProfileSettings.this)) {
                            updateInfo();
                        }
                    }else{
                        updateInfo();
                    }
                }
            });

            manageDaysButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showPopUp();
                }
            });

            hide_profile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(hideProfile) {
                        hide_profile.setText("Profile online");
                        hideProfile = false;
                        Toast.makeText(BartenderProfileSettings.this, "Save to post your profile online",
                                Toast.LENGTH_LONG).show();
                    }
                    else{
                        hide_profile.setText("Profile hidden");
                        hideProfile = true;
                        Toast.makeText(BartenderProfileSettings.this, "Save to hide your profile",
                                Toast.LENGTH_LONG).show();

                    }
                }
            });

            //Button to change profile Pic
            profilPic.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View arg0) {

                    ProfilePicManager.onSelectImageClick(BartenderProfileSettings.this, profilPic, true);

                }
            });

            addSpecialityButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(RegexCheckUtils.checkField(specialitiesEditText, false)) {
                        specialitiesFlowLayout.addToLayout(specialitiesEditText.getText().toString(), bartender, true);
                        specialitiesEditText.setText("");
                    }else{
                        Toast.makeText(BartenderProfileSettings.this, "Enter a speciality",
                                Toast.LENGTH_LONG).show();
                    }
                }
            });


        view_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BartenderProfileSettings.this, BartenderProfile.class);
                intent.putExtra("Previous Act", "Profile Settings");
                startActivity(intent);
            }
        });

        collapseListener();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        ProfilePicManager.activityResult(requestCode,resultCode,data);
    }


    //display the info, fetched from DB
    private void setFields(Bartender bartender){

        setText(firstNameField, bartender.getFirstName());

        setText(lastNameField, bartender.getLastName());

        setText(emailField, bartender.getEmail());

        if(RegexCheckUtils.checkEmail(emailField, checkEmail, this)){
            checkEmail.setVisibility(View.VISIBLE);
        }

        if(bartender.isProfileHidden()){
            hide_profile.setText("Profile hidden");
            hideProfile = true;
        }

        setText(phoneField, bartender.getPhone());

        setText(dobField, bartender.getDoB());

        setText(barExperienceField, bartender.getBarExperience());

        setText(ratePerHourField, String.valueOf(bartender.getHourlyRate()));

        setText(nigtlyRateField, String.valueOf(bartender.getNightlyRate()));

        setText(postCodeField, bartender.getLocation());

        if(bartender.fetchSpecialities()!=null) {
            displaySpecialities(bartender);
        }

        if (bartender.getGender() != null && !bartender.getGender().isEmpty()) {
            if (bartender.getGender().equals("male")) {
                gender = "male";
                maleSelected.setVisibility(View.VISIBLE);

            } else {
                gender = "female";
                femaleSelected.setVisibility(View.VISIBLE);
            }
        }

        if(bartender.getBgColorPref()!=null && !bartender.getBgColorPref().isEmpty() && !bartender.getBgColorPref().equals(" ")) {
            Colours.backgroundColour = bartender.getBgColorPref();
            layout1.setBackgroundColor(Color.parseColor(bartender.getBgColorPref()));
            Colours.isDefault = false;
        }

        ProfilePicManager.loadProfilePicFromStorage(profilPic, this, bartender.getUid(), true, profilePicRef);

    }

    private void displayInfoFromLocalDB(){

        final Bartender[] bartenders = new Bartender[1];

        new DBReader(getApplicationContext()).execute(new Bartender(), bartender.getUid(), new DBCallback() {
            @Override
            public void callBack(Object object) {
                bartenders[0] = (Bartender) object;
                setFields(bartenders[0]);
            }
        });

    }

    private void displayInfoFromDB(){

        setFields(bartender);

    }

    private void displaySpecialities(Bartender bartender) {
        for(String speciality : bartender.fetchSpecialities()){
            specialitiesFlowLayout.addToLayout(speciality, bartender, true);
        }
    }

    //update/save the info entered in editTexts to DB
    private void updateInfo(){


        if(!checkDefaultProfilePicture()) {
             ProfilePicManager.uploadPicToStorage(profilePicRef, profilPic, user.getUid(), root.child("Users").child(bartender.getUid()));
        }

            checkEmail.setVisibility(View.VISIBLE);

            if (RegexCheckUtils.checkField(firstNameField, false))
                bartender.setFirstName(firstNameField.getText().toString());

            if (RegexCheckUtils.checkField(lastNameField, false))
                bartender.setLastName(lastNameField.getText().toString());

            bartender.setEmail(emailField.getText().toString());

            bartender.setPhone(phoneField.getText().toString());

            bartender.setDoB(dobField.getText().toString());

            bartender.setBarExperience(barExperienceField.getText().toString());

            bartender.setProfileHidden(hideProfile);

            if (RegexCheckUtils.checkField(ratePerHourField, false)) {
                bartender.setHourlyRate(Double.parseDouble(ratePerHourField.getText().toString()));
            }

            if (RegexCheckUtils.checkField(nigtlyRateField, false)) {
                bartender.setNightlyRate(Double.parseDouble(nigtlyRateField.getText().toString()));
            }

            if (gender != null && !gender.isEmpty()) {
                bartender.setGender(gender);
            }

            bartender.setLocation(postCodeField.getText().toString());

            if(RegexCheckUtils.checkField(postCodeField, false)) {

                new AsyncLocation(geoFire,postCodeField,user).execute(postCodeField.getText().toString());

            }

            bartender.setBgColorPref(Colours.backgroundColour);


            try{
                new DBWriter(getApplicationContext()).execute(bartender,new DBCallback() {
                    @Override
                    public void callBack(Object object) {
                        Log.v("db_written", object.toString());
                    }
                });
            }catch (Exception e){
                Log.v("db_write", e.getMessage());
            }


            firebaseManagement.setValue(bartender, "Users" , bartender.getUid());

            Toast.makeText(BartenderProfileSettings.this, "Profile Updated !",
                    Toast.LENGTH_LONG).show();


    }

    //When clicking on manage Days, open a popup to manage days
    private void showPopUp(){

        final Bartender bartender;
        if(user!=null)
            bartender = new Bartender("", "", "", user.getUid());
        else{
            bartender = new Bartender("", "", "", "");
        }

        inflater = (LayoutInflater) getBaseContext().getSystemService(LAYOUT_INFLATER_SERVICE);

        // Inflate the custom layout/view
        final View shiftDaysPopup = inflater.inflate(R.layout.popup_manage_days,null, false);

        // Initialize a new instance of popup window
        mPopupWindow = new PopupWindow(shiftDaysPopup, LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);

        mPopupWindow.setFocusable(true);
        WindowManager.LayoutParams windowManager = getWindow().getAttributes();
        mPopupWindow.setAnimationStyle(R.style.FadeAnimation);
        windowManager.dimAmount = 0.75f;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        mPopupWindow.update();


        // Set an elevation value for popup window
        // Call requires API level 21
        if(Build.VERSION.SDK_INT>=21){
            mPopupWindow.setElevation(5.0f);
        }


        day=0;

        //Populate arrays
        final String[] days = {"Monday","Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        final String[] hoursArray = new String[24];

        for(int i =0; i<23; i++){
            hoursArray[i] = Integer.toString(i+1);
        }

        hoursArray[23] = "24+";

        // Get reference to popup views
        ImageButton closeButton = (ImageButton) shiftDaysPopup.findViewById(R.id.close_popup_window);
        ImageButton rightButton = (ImageButton) shiftDaysPopup.findViewById(R.id.popup_right_arrow_button);
        ImageButton leftButton = (ImageButton) shiftDaysPopup.findViewById(R.id.lpopup_eft_arrow_button);
        final Button addButton = (Button) shiftDaysPopup.findViewById(R.id.add_times_button);
        dayTextView = (TextView) shiftDaysPopup.findViewById(R.id.day_of_week_text_view);
        fromTextView = (EditText) shiftDaysPopup.findViewById(R.id.start_time_auto_complete);
        toTextView = (EditText) shiftDaysPopup.findViewById(R.id.end_time_auto_complete);
        flowLayoutForHours = (MyFlowLayout) shiftDaysPopup.findViewById(R.id.shift_hours_flow_layout);

        dayTextView.setText(days[day]);
        flowLayoutForHours.removeAllViews();
        displayAvailableDates(bartender, days[day]);

        //Change the day text view and the flow layout content (shift hours) on click
        leftButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dayTextView.setText(days[decrementDay()]);
                flowLayoutForHours.removeAllViews();
                displayAvailableDates(bartender, days[day]);
            }
        });


        rightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dayTextView.setText(days[incrementDay()]);
                flowLayoutForHours.removeAllViews();
                displayAvailableDates(bartender, days[day]);
            }
        });


        //Add a linear layout widget to the flow layout and update the database if the input is correct (hours must be integer)
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Checking if the input is correct
                if(checkHours(fromTextView.getText().toString(), hoursArray) && checkHours(toTextView.getText().toString(), hoursArray)){

                    final int startTime;
                    if(!fromTextView.getText().toString().equals("24+")) {
                        startTime = Integer.parseInt(fromTextView.getText().toString());
                    }else{
                        startTime = 24;
                    }
                    final int endTime;
                    if(!toTextView.getText().toString().equals("24+")){
                        endTime = Integer.parseInt(toTextView.getText().toString());
                    }else{
                        endTime = 24;
                    }

                    final String dayString = dayTextView.getText().toString();

                    final Pair hoursAdded = new Pair(startTime, endTime);

                    fromTextView.setText("");
                    toTextView.setText("");



                    //Add the available hours to the DB
                    bartender.addAvailableDate(dayString, hoursAdded);

                    Toast.makeText(BartenderProfileSettings.this, "Shift hours for "+dayString+" updated !",
                            Toast.LENGTH_LONG).show();
                    fromTextView.setTextColor(getResources().getColor(R.color.black));
                    toTextView.setTextColor(getResources().getColor(R.color.black));

                }

                else{
                    Toast.makeText(BartenderProfileSettings.this, "Update failed, check your hours (ex:1,2,3 ... 24+) ;)",
                            Toast.LENGTH_LONG).show();
                    if(!fromTextView.getText().toString().isEmpty())
                        RegexCheckUtils.highlightField(fromTextView);
                    if(!toTextView.getText().toString().isEmpty())
                        RegexCheckUtils.highlightField(toTextView);
                }

            }
        });

        // Set a click listener for the popup window close button
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Dismiss the popup window
                bartender.disposeAvailableDateEventListener();
                mPopupWindow.dismiss();
                WindowManager.LayoutParams windowManager = getWindow().getAttributes();
                windowManager.dimAmount = 1;
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            }
        });



        mPopupWindow.showAtLocation(shiftDaysPopup, Gravity.NO_GRAVITY, 0, 0);
    }

    private int incrementDay(){
        if(day<6){
            day ++;
        }
        else{
            day =0;
        }
        return day;
    }

    private int decrementDay(){
        if(day==0){
            day = 6;
        }
        else{
            day--;
        }
        return day;
    }

    private boolean checkHours(String hourInput, String[] hours){
        for(String hour:hours){
            if(hourInput.equals(hour)){
                return true;
            }
        }
        return false;
    }

    private void displayAvailableDates(Bartender bartender, String day){

        bartender.fetchAvailableDates(day, flowLayoutForHours);

    }

    //Set text of an field
    private void setText(EditText editText, String text){
        if(text != null) {
            if (!text.isEmpty()) {
                editText.setText(text);
            }
        }
    }

    private boolean checkDefaultProfilePicture(){

        try {
            Bitmap b1 = ((BitmapDrawable) (profilPic.getBackground())).getBitmap();
            Bitmap b2 = ((BitmapDrawable) getResources().getDrawable(R.drawable.profile_icon_male)).getBitmap();
            Bitmap b3 = ((BitmapDrawable) getResources().getDrawable(R.drawable.profile_icon_female)).getBitmap();
            Bitmap b4 = ((BitmapDrawable) getResources().getDrawable(R.drawable.ic_profile_default)).getBitmap();

            if (b1.sameAs(b2) || b1.sameAs(b3) || b1.sameAs(b4)) {
                return true;
            }
        }catch (Exception e){
            return true;
        }


        return false;
    }

    //Create and show the alertDialogs
    private  void showChangePasswordAlertDialog(){

        GeneralDialogFragment changePasswordDialogFragment = GeneralDialogFragment.newInstance("Change password", "Are you sure you want to change your password ?", "No", "Yes");
        changePasswordDialogFragment.show(getSupportFragmentManager(),"dialog");

    }

    private  void showDeleteAccountAlertDialog() {

        GeneralDialogFragment deleteAccountDialogFragment = GeneralDialogFragment.newInstance("Delete account", "We are sad to see you leave ... \n Are you sure, You want to delete your account ?", "No", "Yes");
        deleteAccountDialogFragment.show(getSupportFragmentManager(), "dialog");
    }

    private  void showLogOutDialog(){
        GeneralDialogFragment setUserDialogFragment = GeneralDialogFragment.newInstance("Logging out", "Do you want to log out ?", "No", "Yes");
        setUserDialogFragment.show(getSupportFragmentManager(),"dialog");
    }

    @Override
    public void onAlertDialogLeftClicked(GeneralDialogFragment dialog) {
        dialog.dismiss();
    }

    @Override
    public void onAlertDialogRightClicked(GeneralDialogFragment dialog) {
        // if the alert dialog corresponds to change password
        if(dialog.getArguments().getString("title").equals("Change password")) {
            //send an email to the user to change his password
            auth.sendPasswordResetEmail(user.getEmail())
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Log.d("RESET PASSWORD", "Email sent.");
                                Toast.makeText(BartenderProfileSettings.this, "An email has been sent to " + user.getEmail() + " to change your password",
                                        Toast.LENGTH_LONG).show();
                            }
                        }
                    });

            dialog.dismiss();

        }
        else if (dialog.getArguments().getString("title").equals("Logging out")){
            FirebaseManagement.getInstance().currentUser = null;
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(BartenderProfileSettings.this, LoginActivity1.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            dialog.dismiss();
            startActivity(intent);
            finish();
        }
        else{
            //deletes the user from DB
            user.delete() //TODO check if it deletes the user
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Log.d("Account deleted", "deleted");
                                Toast.makeText(BartenderProfileSettings.this, "Account deleted",
                                        Toast.LENGTH_LONG).show();
                                //Redirect to loginActivity1
                                Intent intent = new Intent(BartenderProfileSettings.this, LoginActivity1.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                                finish();

                            }
                        }
                    });

            dialog.dismiss();

        }
    }

    private void hideFields(){

        TextView emailTextView = (TextView) findViewById(R.id.email_text_view);
        emailTextView.setVisibility(View.GONE);

        ImageView emailDivider = (ImageView) findViewById(R.id.email_divider);
        emailDivider.setVisibility(View.GONE);

        ImageView passwordDivider = (ImageView) findViewById(R.id.password_divider);
        passwordDivider.setVisibility(View.GONE);

        ImageView passwordIcon = (ImageView) findViewById(R.id.password_icon);
        passwordIcon.setVisibility(View.GONE);

        ImageView emailIcon = (ImageView) findViewById(R.id.email_icon);
        emailIcon.setVisibility(View.GONE);

        changePasswordButton.setVisibility(View.GONE);

        emailField.setVisibility(View.GONE);

    }

    public void collapseListener(){


        AppBarLayout appBarLayout = (AppBarLayout) findViewById(R.id.app_bar_layout_for_profile);


        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {

                if (Math.abs(verticalOffset)-appBarLayout.getTotalScrollRange() == 0)
                {
                    profilPic.setVisibility(View.INVISIBLE);


                }
                else
                {

                    profilPic.setVisibility(View.VISIBLE);

                }
            }
        });




    }

}
