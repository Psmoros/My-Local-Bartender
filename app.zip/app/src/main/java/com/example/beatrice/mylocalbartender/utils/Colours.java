package com.example.beatrice.mylocalbartender.utils;

/**
 * Created by wasanshubbar on 25/03/2017.
 * A static colors class for the background of the app
 */

public class Colours {

    public static String backgroundColour = " ";
    public static boolean isDefault = true;
}
