package com.example.beatrice.mylocalbartender.model;

import android.content.Intent;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;

import java.util.HashMap;

/**
 * Created by Umar on 03/03/2017.
 * This class represents a Tag that can used to describe a speciality or an event
 * The base class will be used to describe its speciality
 * todo Change the security rules for Tags, only the server creates tags, the client only reads the tags
 */

public class Tag {

    private String tagId;
    private String name;
    private int popularity;
    private String description;


    /**
     * A constructor for a speciality tag, the popularity will be initially 1
     *
     * @param tagId       The tagId, this will be given by the push key
     * @param name        The name of the specialty
     * @param description
     */
    public Tag(String tagId, String name, String description) {
        this.tagId = tagId;
        this.name = name;
        this.description = description;
        this.popularity = 1;
    }


    public Tag() {

    }

    /**
     * Increase the tag popularity by 1 as one transaction to avoid concurrency issues
     *
     * @param tagReference The reference of the tag within the database
     */
    public void increasePopularity(DatabaseReference tagReference) {


        tagReference.runTransaction(new Transaction.Handler() {
            @Override
            public Transaction.Result doTransaction(MutableData mutableData) {

                Tag tag = mutableData.getValue(Tag.class);
                // if the event does not exist terminate the transaction
                if (tag == null) {
                    return Transaction.success(mutableData);
                }
                // Increment the counter
                tag.popularity = tag.popularity + 1;

                mutableData.setValue(tag);

                return Transaction.success(mutableData);


            }

            @Override
            public void onComplete(DatabaseError databaseError, boolean b, DataSnapshot dataSnapshot) {
                // do not know what to do here
            }
        });

    }


    public String getTagId() {
        return tagId;
    }

    public void setTagId(String tagId) {
        this.tagId = tagId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPopularity() {
        return popularity;
    }

    public void setPopularity(int popularity) {
        this.popularity = popularity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }



}
