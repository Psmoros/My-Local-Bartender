package com.example.beatrice.mylocalbartender.database;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

/**
 * The Java class representation of the SQLite table 'booking'.
 */

public class BookingTable {
    //Database Table Booking
    public static final String TABLE_BOOKING = "booking";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_EVENT = "event_id";
    public static final String COLUMN_ORGANISER = "organiser_id";
    public static final String COLUMN_BARTENDER = "bartender_id";
    public static final String COLUMN_BOOKING_STATUS = "status";
    public static final String COLUMN_ACCEPTED = "bartenderAccepted";

    private static final String DATABASE_CREATE =
            "create table "
                    +TABLE_BOOKING
                    +"("
                    +COLUMN_ID + " TEXT PRIMARY KEY, "
                    +COLUMN_EVENT + " TEXT NOT NULL, "
                    +COLUMN_ORGANISER + " TEXT NOT NULL, "
                    +COLUMN_BARTENDER + " TEXT NOT NULL, "
                    +COLUMN_BOOKING_STATUS + " TEXT NOT NULL, "
                    +COLUMN_ACCEPTED + " INTEGER NOT NULL, "
                    +"FOREIGN KEY("+COLUMN_EVENT+") REFERENCES event(_id)"
                    + ");";

    /**
     * Called when the database is created for the first time. This is where the
     * creation of tables and the initial population of the tables happens.
     *
     * @param database The SQLite database.
     */
    public static void onCreate(SQLiteDatabase database) {
        database.execSQL(DATABASE_CREATE);
    }

    /**
     * Called when the database needs to be upgraded. The implementation
     * should use this method to drop tables, add tables, or do anything else it
     * needs to upgrade to the new schema version.
     *
     * @param database The SQLite database.
     * @param oldVersion The old database version.
     * @param newVersion The new database version.
     */
    public static void onUpgrade(SQLiteDatabase database, int oldVersion,
                                 int newVersion) {
        Log.w(BookingTable.class.getName(), "Upgrading database from version "
                + oldVersion + " to " + newVersion
                + ", which will destroy all old data");
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKING);
        onCreate(database);
    }
}