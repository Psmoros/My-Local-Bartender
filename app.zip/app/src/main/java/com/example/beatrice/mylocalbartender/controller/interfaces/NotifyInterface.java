package com.example.beatrice.mylocalbartender.controller.interfaces;

import com.example.beatrice.mylocalbartender.model.Tag;

/**
 * Created by Umar on 04/03/2017.
 * This interface is used to notify when a data tag has been added or removed
 */

public interface NotifyInterface {

    public void incomingTag(int position,Tag tag);

    public void removeTag(int position);



}
