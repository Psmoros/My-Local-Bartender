package com.example.beatrice.mylocalbartender.database;


import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;

import com.example.beatrice.mylocalbartender.model.Bartender;
import com.example.beatrice.mylocalbartender.model.BaseRequest;
import com.example.beatrice.mylocalbartender.model.Event;
import com.example.beatrice.mylocalbartender.model.Job;
import com.example.beatrice.mylocalbartender.model.Organiser;

/**
 * Used to delete individual fields from the SQL database
 */
public class DBDeleter extends AsyncTask<Object, Void, Object> {
    private SQLiteDatabase database;
    private DBHelper dbHelper;
    private DBCallback callback;

    public DBDeleter(Context context){dbHelper = new DBHelper(context);}


    @Override
    protected Object doInBackground(Object... params) {
        callback = (DBCallback) params[2];

        if (params[0].getClass() == Bartender.class){
            deleteBartender((String) params[1]);
            return null;
        }else if (params[0].getClass() == Organiser.class){
            deleteOrganiser((String) params[1]);
            return null;
        }else if (params[0].getClass() == Event.class){
            deleteEvent((String) params[1]);
            return null;
        }else if (params[0].getClass() == Job.class){
            deleteJob((String) params[1]);
            return null;
        }else if (params[0].getClass() == BaseRequest.class){
            deleteBaseRequest((String) params[1]);
            return null;
        }else {return null;}
    }

    @Override
    protected void onPostExecute(Object result) {

    }


    public void open() throws SQLException {database = dbHelper.getWritableDatabase();}

    private void close(){dbHelper.close();}

    /**
     * delete a Bartender from the DB.
     * @param _id bartender unique id
     */
    private void deleteBartender(String _id){
        String WHERE = BartenderTable.COLUMN_ID + " = '" + _id + "'";
        String[] ARGS = {};
        open();
        database.delete(BartenderTable.TABLE_BARTENDER, WHERE, ARGS);
        close();
    }

    /**
     * delete a Organiser from the DB.
     * @param _id organiser unique id
     */
    private void deleteOrganiser(String _id) {
        String WHERE = OrganiserTable.COLUMN_ID + " = '" + _id + "'";
        String[] ARGS = {};
        open();
        database.delete(OrganiserTable.TABLE_ORGANISER, WHERE, ARGS);
        close();
    }

    /**
     * delete a booking request from the DB.
     * @param baseRequestID baseRequest unique _id
     */
    private void deleteBaseRequest(String baseRequestID) {
        String WHERE = BookingTable.COLUMN_ID + " = '" + baseRequestID + "'";
        String[] ARGS = {};
        open();
        database.delete(BookingTable.TABLE_BOOKING, WHERE, ARGS);
        close();
    }

    /**
     * delete a job from the DB.
     * @param jobID Job unique _id.
     */
    private void deleteJob(String jobID) {
        String WHERE = JobTable.COLUMN_ID + " = '" + jobID + "'";
        String[] ARGS = {};
        open();
        database.delete(JobTable.TABLE_JOB, WHERE, ARGS);
        close();
    }

    /**
     * delete a Event from the DB.
     * @param eventID Event unique _id.
     */
    private void deleteEvent(String eventID) {
        String WHERE = EventTable.COLUMN_ID + " = '" + eventID + "'";
        String[] ARGS = {};
        open();
        database.delete(EventTable.TABLE_EVENT, WHERE, ARGS);
        close();
    }
}
