package com.example.beatrice.mylocalbartender.model;


public enum BookingStatus {
    OFFERED,
    ACCEPTED,
    APPROVED,
    REJECTED;

    @Override
    public String toString() {
        switch (this) {
            case OFFERED:
                return "OFFERED";
            case ACCEPTED:
                return "ACCEPTED";
            case APPROVED:
                return "APPROVED";
            case REJECTED:
                return "REJECTED";
            default:
                return "ERROR!!";
        }
    }


}
