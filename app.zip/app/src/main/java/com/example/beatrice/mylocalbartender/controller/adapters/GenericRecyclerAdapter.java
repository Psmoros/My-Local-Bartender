package com.example.beatrice.mylocalbartender.controller.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.beatrice.mylocalbartender.controller.interfaces.ResultsInterface;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

/**
 * Created by Umar on 16/03/2017.
 * This class represents a Generic Recycler adapter that will be used for many of the view holders
 */

public class GenericRecyclerAdapter<T,VH extends RecyclerView.ViewHolder> extends RecyclerView.Adapter<VH> implements ResultsInterface<T> {

    private Class<T> modelClass;
    private int layoutResource;
    private Class<VH> viewHolder;
    private ArrayList<T> list;

    /**
     * The constructor
     * @param modelClass The model class that will be used for binding data
     * @param modelLayout The layout that the view holder will use
     * @param viewHolder The class for the view holder that the model will be binded to
     */
    public GenericRecyclerAdapter(Class<T> modelClass, int modelLayout, Class<VH> viewHolder) {
        super();
        this.modelClass = modelClass;
        this.layoutResource = modelLayout;
        this.viewHolder = viewHolder;
        list = new ArrayList<>();
    }

    /**
     * This creates the view holder and inflates the resource associated with it
     * @param parent The parent view group
     * @param viewType The view type
     * @return The View that was inflated
     */
    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = (ViewGroup) LayoutInflater.from(parent.getContext()).inflate(layoutResource,parent,false);

        try {
            // using the reflection to find the matching constructor of the view holder
            Constructor<VH> constructor = viewHolder.getConstructor(View.class);
            return  constructor.newInstance(view);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException();
        } catch (IllegalAccessException e) {
            throw new RuntimeException();
        } catch (InstantiationException e) {
            throw  new RuntimeException();
        } catch (InvocationTargetException e) {
            throw new RuntimeException();
        }

    }


    /**
     * This method binds the view holder to the model and calls {@link #bindViewWithData(RecyclerView.ViewHolder, Object, int)}
     * @param holder The view that is holding the data
     * @param position the position of the model in the view
     */
    @Override
    public void onBindViewHolder(VH holder, int position) {

        T model = getItem(position);
        bindViewWithData(holder,model,position);

    }

    // TODO: 17/03/2017 Should I make this abstract -- it is cleaner
    /**
     * If you call this method without an implemenation then you will get panned
     * @param holder The view holder that holds the information of the model
     * @param model The model 
     * @param position The position that the model will be displayed in
     */
    public void bindViewWithData(VH holder, T model, int position){
        throw new UnsupportedOperationException();
    }

    private T getItem(int position) {

        return this.list.get(position);

    }

    /**
     * Returns the number of elements in the view
     * @return The size of the list
     */
    @Override
    public int getItemCount() {
        return list.size();
    }


    /**
     * Add an Item to the list
     * @param t The model object to be added
     */
    @Override
    public void addToList(T t) {
        list.add(t);

        notifyDataSetChanged();
    }

    @Override
    public void notifyEmptyDataSet() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void notifyDataChanged(T t) {

        for (T value:list) {
            if(value.equals(t)){
                list.remove(value);
                list.add(t);
                notifyDataSetChanged();
                break;
            }
        }

    }

    @Override
    public void removeFromList(T t) {


        for(int i =0; i<list.size(); i++){
            if(list.get(i).equals(t)){
                list.remove(i);
                notifyItemRemoved(i);
                break;
            }
        }
    }

    /**
     * Removing an item for the list
     * @param position The posittion of the item
     */
    public void removeItem(int position){
        this.list.remove(position);
        notifyDataSetChanged();

    }

    /**
     * Clears all the data that this adapter holds
     */
    public void clearAllData(){
        this.list.clear();
       // notifyEmptyDataSet();

    }

}
