package com.example.beatrice.mylocalbartender.controller.adapters;

import android.widget.SeekBar;

/**
 * Created by Umar on 24/02/2017.
 * This adapter has been created to make code cleaner when adding seeklisteners
 * as you do not have to implement all the methods and only the methods you need
 */

public class SeekBarListenerAdapter implements SeekBar.OnSeekBarChangeListener {
    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

   }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}
