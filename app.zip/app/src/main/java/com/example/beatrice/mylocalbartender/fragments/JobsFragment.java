package com.example.beatrice.mylocalbartender.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.braintreepayments.api.dropin.DropInResult;
import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.activity.CustomQrActivity;
import com.example.beatrice.mylocalbartender.controller.ProfilePicManager;
import com.example.beatrice.mylocalbartender.controller.adapters.GenericRecyclerAdapter;
import com.example.beatrice.mylocalbartender.controller.interfaces.ServerFace;
import com.example.beatrice.mylocalbartender.controller.view_holders.JobHolder;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.model.BaseRequest;
import com.example.beatrice.mylocalbartender.model.Job;
import com.example.beatrice.mylocalbartender.model.Organiser;
import com.example.beatrice.mylocalbartender.model.User;
import com.example.beatrice.mylocalbartender.model.UserType;
import com.example.beatrice.mylocalbartender.utils.Colours;


/**
 * create by Umar Karimabadi
 * This class is simply a fragement for displaying jobs that cyclecs between completed jobs,
 * jobs that are not completed and jobs that are on the pending section
 */
public class JobsFragment extends android.app.Fragment implements View.OnClickListener {

    private static final int REQUEST_CODE = 401;

    private RecyclerView recyclerView;

    private GenericRecyclerAdapter adapter;

    private User user;

    private ImageButton qrCode;

    private boolean isCompleted;

    private TextView currentTab;
    private FloatingActionButton completedJobs;
    private FloatingActionButton currentJobs;

    private FloatingActionButton pendingJobs;

    private ServerFace serverInterface;

    private ProgressBar progressBar;

    private TextView noJobsTextView;

    private String whereClause; // this is the where clause for the database
    private FrameLayout layout;

    /**
     *
     * This method is called when the activity restores it state
     *
     * @param savedInstanceState The bundle with all the saved information
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(savedInstanceState!=null)
            isCompleted = (boolean) savedInstanceState.get("isCompleted");

        user = FirebaseManagement.getInstance().currentUser;

        if(user.getUserType() == UserType.ORGANISER) {
            serverInterface = new ServerFace(this, (Organiser) user);
            whereClause = "organiserIdCompleted";

        }else{
            whereClause = "bartenderIdCompleted";
        }

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean("isCompleted",isCompleted);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_jobs, container, false);

        layout = (FrameLayout) view.findViewById(R.id.jobs_framelayout);

        if(Colours.isDefault == false) {
            layout.setBackgroundColor(Color.parseColor(Colours.backgroundColour));
        }

        noJobsTextView = (TextView) view.findViewById(R.id.no_current_jobs_text_view);

        progressBar = (ProgressBar) view.findViewById(R.id.progress_bar);

        qrCode = (ImageButton) view.findViewById(R.id.qr_code_scanner_button);

        qrCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), CustomQrActivity.class);
                startActivity(intent);
            }
        });

        if(whereClause.equals("organiserIdCompleted"))
            qrCode.setVisibility(View.GONE);

        recyclerView = (RecyclerView) view.findViewById(R.id.jobs_recycler_adapter);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        // the first adapetr that will be shown is the jobs adapter
        createJobsCompletedAdapter();

        recyclerView.setAdapter(adapter);

        completedJobs = (FloatingActionButton) view.findViewById(R.id.completed_jobs);

        pendingJobs = (FloatingActionButton) view.findViewById(R.id.pending_jobs);

        currentJobs = (FloatingActionButton) view.findViewById(R.id.current_jobs);

        currentTab = (TextView) view.findViewById(R.id.current_tab_title);

        completedJobs.setOnClickListener(this);

        pendingJobs.setOnClickListener(this);

        currentJobs.setOnClickListener(this);

        user.fetchCompletedJobs(adapter,whereClause,user.getUid()+"-"+"true");

        return view;

    }


    public void createJobsCompletedAdapter() {

        adapter = new GenericRecyclerAdapter<Job,JobHolder>(
                Job.class,
                R.layout.event_result_layout,
                JobHolder.class){

            @Override
            public void bindViewWithData(JobHolder holder, Job model, int position) {

                progressBar.setVisibility(View.GONE);
                noJobsTextView.setVisibility(View.GONE);
                holder.bindDataWithJob(model, user, getActivity());

            }

            @Override
            public void notifyEmptyDataSet() {
                // make toast or something
                progressBar.setVisibility(View.GONE);
                noJobsTextView.setVisibility(View.VISIBLE);
            }
        };


    }


    public void createBookingRequestAdapter(){


        adapter = new GenericRecyclerAdapter<BaseRequest,JobHolder>(
                BaseRequest.class,
                R.layout.event_result_layout,
                JobHolder.class) {


            @Override
            public void bindViewWithData(JobHolder holder, BaseRequest model, int position) {

                progressBar.setVisibility(View.GONE);
                noJobsTextView.setVisibility(View.GONE);
                holder.bindDataWithBookingRequest(model,serverInterface,user, getActivity());

            }

            @Override
            public void notifyEmptyDataSet() {
                progressBar.setVisibility(View.GONE);
                noJobsTextView.setVisibility(View.VISIBLE);
            }
        };



    }





    @Override
    public void onAttach(Context context) {

        super.onAttach(context);
    }

    /**
     * When the fragment is detatched from the activity then the child event listeners will be
     * universally detatched
     */
    @Override
    public void onDetach() {

        super.onDetach();
    }

    @Override
    public void onClick(View v) {

        // TODO: 20/03/2017 Switch everything
        switch (v.getId()){
            case R.id.completed_jobs:
                isCompleted = true;
                adapter.clearAllData();
                createJobsCompletedAdapter();
                currentTab.setText("Completed Jobs");
                user.fetchCompletedJobs(adapter,whereClause,user.getUid()+"-"+"true");
                recyclerView.setAdapter(adapter);
                break;

            case R.id.current_jobs:
                currentTab.setText("Current Jobs");
                adapter.clearAllData();
                isCompleted = false;
                createJobsCompletedAdapter();
                user.fetchCompletedJobs(adapter,whereClause,user.getUid()+"-"+"false");
                recyclerView.setAdapter(adapter);
                break;

            case R.id.pending_jobs:
                adapter.clearAllData();
                isCompleted = false;
                currentTab.setText("Pending");
                createBookingRequestAdapter();
                user.fetchPendingJobs(adapter);
                recyclerView.setAdapter(adapter);
                break;

        }


    }

//TODO Import braintree
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // result returned from the the paypal drop in ui
        if (requestCode == REQUEST_CODE) {

            if (resultCode == Activity.RESULT_OK) {
                DropInResult result = data.getParcelableExtra(DropInResult.EXTRA_DROP_IN_RESULT);
                serverInterface.postNonceToServer(result.getPaymentMethodNonce().getNonce());
                ProfilePicManager.eraseImage(getActivity(), serverInterface.getBaseRequest().getBookingID());

            } else if (resultCode == Activity.RESULT_CANCELED) {

                Log.v("result", "failed");
                // the user canceled
                // TODO ADD TOAST
            } else {
               //// TODO: 13/03/2017 ADD TOAST
              //  Exception error = (Exception) data.getSerializableExtra(DropInActivity.EXTRA_ERROR);
                //Log.v("result", error.toString());
            }
        }
    }


}
