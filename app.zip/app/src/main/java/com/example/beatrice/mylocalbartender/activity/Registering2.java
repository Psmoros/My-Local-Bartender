package com.example.beatrice.mylocalbartender.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.firebase.Callback;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.model.UserType;
import com.example.beatrice.mylocalbartender.utils.RegexCheckUtils;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Registers a UserType with MLB via email.
 */
public class Registering2 extends AppCompatActivity {
    private ImageButton backButton;
    private UserType user;
    private Button signUpButton;
    private EditText firstNameField, lastNameField, emailField, passwordField, confirmPasswordField;
    private String firstName, lastName, email, password, confirmPassword;
    private FirebaseManagement firebaseManagement;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registering3);

        firebaseManagement = FirebaseManagement.getInstance();

        backButton = (ImageButton) findViewById(R.id.signup_back_button);
        user = (UserType) getIntent().getSerializableExtra("UserType");
        firstNameField = (EditText) findViewById(R.id.firstNameField);
        lastNameField = (EditText) findViewById(R.id.lastNameField);
        emailField = (EditText) findViewById(R.id.emailField);
        passwordField = (EditText) findViewById(R.id.passwordField);
        confirmPasswordField = (EditText) findViewById(R.id.confirmPasswordField);

        signUpButton = (Button) findViewById(R.id.sign_up_button);
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firstName = firstNameField.getText().toString();
                lastName = lastNameField.getText().toString();
                email = emailField.getText().toString();
                password = passwordField.getText().toString();

                if (validInput()){
                    Toast.makeText(Registering2.this, "An email has been sent to confirm your email address",
                            Toast.LENGTH_LONG).show();
                    registerWithFirebase();
                }else{
                    Toast.makeText(Registering2.this, "Please complete all fields",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Registering2.this, LoginActivity1.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //TODO methods below will need testing.
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    private boolean validInput() {
        return  RegexCheckUtils.checkField(firstNameField, true) && RegexCheckUtils.checkField(lastNameField, true) && RegexCheckUtils.checkEmail(emailField, null, this) && RegexCheckUtils.checkPassword(passwordField, confirmPasswordField);
    }

    private synchronized void registerWithFirebase() {
        boolean launchNextIntent;
        firebaseManagement.registerWithEmail(Registering2.this,email,password,firstName,lastName, user, new Callback() {
            @Override
            public void loginSuccessful() {
                Intent intent = new Intent(Registering2.this, LoginActivity1.class);
                intent.putExtra("source", "Registering2");
                intent.putExtra("email", email);
                intent.putExtra("password", password);
                startActivity(intent);
            }

            @Override
            public void loginFailed() {

            }
        });
    }

}
