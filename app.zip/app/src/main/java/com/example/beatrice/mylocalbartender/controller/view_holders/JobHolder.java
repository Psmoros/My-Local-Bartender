package com.example.beatrice.mylocalbartender.controller.view_holders;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.activity.MessagingActivity;
import com.example.beatrice.mylocalbartender.controller.ProfilePicManager;
import com.example.beatrice.mylocalbartender.controller.interfaces.ServerFace;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.model.BaseRequest;
import com.example.beatrice.mylocalbartender.model.BookingStatus;
import com.example.beatrice.mylocalbartender.model.Event;
import com.example.beatrice.mylocalbartender.model.Job;
import com.example.beatrice.mylocalbartender.model.User;
import com.example.beatrice.mylocalbartender.model.UserType;
import com.example.beatrice.mylocalbartender.utils.GenCode;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;
import static com.example.beatrice.mylocalbartender.model.BookingStatus.OFFERED;


/**
 * This class represents a view holder that will display information of a Job or a Booking request
 */
public class JobHolder extends RecyclerView.ViewHolder {

    private TextView eventTitle;
    private TextView postCode;
    private TextView dateTime;
    private TextView shiftHours;
    private TextView rate;
    private ImageButton cancel;
    private ImageButton message;
    private ImageButton acceptButton;
    private TextView status;
    private ImageView jobImage;
    private User resultingUser;
    private ServerFace serverFace;
    private BaseRequest baseBookingRequest;
    private Job job;
    private Event event;
    private Context activity;
    private ImageButton adjustButton;
    private ImageButton qrCodeButton;
    private StorageReference storageReference = FirebaseStorage.getInstance().getReference();


    /**
     * Constructor to create a job hoder
     *
     * @param itemView The inflated view that this {@link JobHolder} will take
     */
    public JobHolder(View itemView) {

        super(itemView);
        jobImage = (ImageView) itemView.findViewById(R.id.event_image);
        adjustButton = (ImageButton) itemView.findViewById(R.id.adjust_rate_button);
        message = (ImageButton) itemView.findViewById(R.id.message_button);
        cancel = (ImageButton) itemView.findViewById(R.id.cancel_button);
        eventTitle = (TextView) itemView.findViewById(R.id.event_title);
        postCode = (TextView) itemView.findViewById(R.id.post_code);
        acceptButton = (ImageButton) itemView.findViewById(R.id.accept_job_button);
        status = (TextView) itemView.findViewById(R.id.event_status);
        qrCodeButton = (ImageButton) itemView.findViewById(R.id.qr_code_button);
        activity = itemView.getContext();
        dateTime = (TextView) itemView.findViewById(R.id.date_and_time);
        shiftHours = (TextView) itemView.findViewById(R.id.shift_hours);
        rate = (TextView) itemView.findViewById(R.id.shift_rate);


        //status = (TextView) itemView.findViewById(R.id.status_text);


    }

    /**
     * Binds the job holder to a job object
     *
     * @param job  The job to be binded
     * @param user The current user using the application
     * @param act  The activity that is hosting the {@link JobHolder}
     */
    public void bindDataWithJob(Job job, User user, Activity act) {

        this.job = job;
        this.resultingUser = user;
        Event event = job.getEvent();
        eventTitle.setText(event.getTitle());
        status.setVisibility(View.GONE);
        postCode.setText(event.getLocation());
        dateTime.setText(event.getDate());
        shiftHours.setText(event.getStartTime() + " : " + event.getFinishTime());
        rate.setText(String.valueOf(job.getEvent().getShiftRate()));

        if (resultingUser.getUserType() == UserType.ORGANISER && !job.isCompleted()) {
            qrCodeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showQrCodePopUp();
                }
            });

        } else {

            qrCodeButton.setClickable(false);
            qrCodeButton.setVisibility(View.GONE);
        }

        StorageReference eventPicRef = storageReference.child("EventPics");

        if (!job.isCompleted()) {
            ProfilePicManager.loadProfilePicFromStorage(jobImage, act, job.getEvent().getEvent_id(), false, eventPicRef);
        } else {
            ProfilePicManager.setPicFromDB(eventPicRef, act, jobImage, job.getEvent().getEvent_id(), false, false);
            ProfilePicManager.eraseImage(act, job.getEvent().getEvent_id());
        }

        jobImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDescriptionEventPopup();
            }
        });


        cancel.setVisibility(View.GONE);

        adjustButton.setVisibility(View.GONE);

        acceptButton.setVisibility(View.GONE);


        setControllerForMessaging();
    }

    public void bindDataWithBookingRequest(final BaseRequest bookingRequest, ServerFace serverFace, User user, Activity act) {

        // TODO: 23/03/2017 Call profile pic manager to get the image

        qrCodeButton.setVisibility(View.GONE);

        this.event = bookingRequest.getEvent();

        this.baseBookingRequest = bookingRequest;

        this.resultingUser = user;

        this.serverFace = serverFace;

        eventTitle.setText(event.getTitle());

        jobImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDescriptionEventPopup();
            }
        });

        rate.setText(String.valueOf(baseBookingRequest.getEvent().getShiftRate()));

        postCode.setText(event.getLocation());

        this.status.setText(bookingRequest.getStatus().toString());
        setStatusTextColor(bookingRequest.getStatus());

        postCode.setText(event.getLocation());
        dateTime.setText(event.getStartTime() + " : " + event.getFinishTime());

        StorageReference eventPicRef = storageReference.child("EventPics");

        ProfilePicManager.loadProfilePicFromStorage(jobImage, act, event.getEvent_id(), false, eventPicRef);

        if (user.getUserType() == UserType.ORGANISER) {

            if (bookingRequest.getStatus() == OFFERED) {

                acceptButton.setVisibility(View.GONE);
                acceptButton.setClickable(false);

            } else if (bookingRequest.getStatus() == BookingStatus.APPROVED) {

                acceptButton.setVisibility(View.VISIBLE);
                //acceptController(bookingRequest);
                acceptButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        acceptController(baseBookingRequest.getStatus());
                    }
                });


            }
        } else {



            // the user is the bartender
            if (bookingRequest.getStatus() == OFFERED) {


                acceptButton.setClickable(true);
                acceptButton.setVisibility(View.VISIBLE);
                acceptButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        acceptController(bookingRequest.getStatus());
                    }
                });
            } else {
                acceptButton.setClickable(false);
                acceptButton.setVisibility(View.GONE);
            }
        }


        adjustButton.setClickable(true);

        adjustButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showNegotiatePopUp();
            }
        });

        setControllerForMessaging();
    }


    /**
     * This displays the negotiating pop up that can be used to negotiate
     */
    private void showNegotiatePopUp() {
        LayoutInflater inflater = (LayoutInflater) activity.getSystemService(LAYOUT_INFLATER_SERVICE);

        // Inflate the custom layout/view
        final View negotiatePopUp = inflater.inflate(R.layout.negociate_rate_popup, null, false);

        // Initialize a new instance of popup window
        final PopupWindow mPopupWindow = new PopupWindow(negotiatePopUp, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        mPopupWindow.setFocusable(true);
        mPopupWindow.update();

        // Set an elevation value for popup window
        // Call requires API level 21
        if (Build.VERSION.SDK_INT >= 21) {
            mPopupWindow.setElevation(5.0f);
        }

        Button negotiateButton = (Button) negotiatePopUp.findViewById(R.id.negotiate_done_button);
        ImageButton exitPopUp = (ImageButton) negotiatePopUp.findViewById(R.id.exit_popup_button);
        final EditText negotiateEditText = (EditText) negotiatePopUp.findViewById(R.id.negotiated_rate_edit_text);

        negotiateEditText.setText(Double.toString(event.getShiftRate()));

        mPopupWindow.showAtLocation(negotiatePopUp, Gravity.CENTER, 0, 0);

        // Set a click listener for the popup window close button
        exitPopUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Dismiss the popup window
                mPopupWindow.dismiss();
            }
        });

        negotiateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newRate = negotiateEditText.getText().toString();
                // if the new rate is different
                if (!newRate.equals(String.valueOf(baseBookingRequest.getEvent().getShiftRate()))) {
                    event.setShiftRate(Double.parseDouble(newRate));
                    Toast.makeText(activity, "New rate sent : " + newRate,
                            Toast.LENGTH_LONG).show();
                    negotiateController(baseBookingRequest.getStatus());
                    mPopupWindow.dismiss();
                } else {
                    Toast.makeText(activity, "Please select a different rate", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }


    /**
     * This is the accepet button controller for the booking status
     *
     * @param bookingStatus The booking status
     */
    private void acceptController(BookingStatus bookingStatus) {

        if (resultingUser.getUserType() == UserType.ORGANISER) {
            switch (bookingStatus) {
                case APPROVED:
                    // TODO: 13/03/2017 Add some loading dialogue
                    serverFace.setBaseRequest(baseBookingRequest);
                    serverFace.getTokenFromServer();
                    break;

            }
        }
        // the current user is the bartender
        else {
            switch (bookingStatus) {
                case OFFERED:

                    baseBookingRequest.setStatus(bookingStatus.APPROVED);
                    FirebaseManagement.getInstance().setValue(baseBookingRequest, "BookingRequest", baseBookingRequest.getBookingID());


            }

        }

    }

    /**
     * This method changed the status color of the status text view
     *
     * @param status The status of the job request
     */
    private void setStatusTextColor(BookingStatus status) {

        switch (status) {
            case OFFERED:
                this.status.setTextColor(Color.YELLOW);
                break;
            case APPROVED:
                this.status.setTextColor(Color.MAGENTA);
                break;
            case ACCEPTED:
                this.status.setTextColor(Color.GREEN);
                break;
            case REJECTED:
                this.status.setTextColor(Color.RED);
                break;


        }


    }


    private void negotiateController(BookingStatus bookingStatus) {

        if (bookingStatus != BookingStatus.ACCEPTED) {

            if (resultingUser.getUserType() == UserType.BARTENDER) {

                baseBookingRequest.setStatus(bookingStatus.APPROVED);
                FirebaseManagement.getInstance().setValue(baseBookingRequest, "BookingRequest", baseBookingRequest.getBookingID());


            } else if (resultingUser.getUserType() == UserType.ORGANISER) {

                baseBookingRequest.setStatus(OFFERED);
                FirebaseManagement.getInstance().setValue(baseBookingRequest, "BookingRequest", baseBookingRequest.getBookingID());
            }
        }

    }

    /**
     * This method set the controller for the messaing the user directly
     */
    private void setControllerForMessaging() {

        final FirebaseManagement m = FirebaseManagement.getInstance();
        final User currentUser = m.currentUser;

        String resultingUserid;
        String firstName;
        String lastName;

        if (baseBookingRequest != null) {

            resultingUserid = currentUser.getUserType() == UserType.BARTENDER ?
                    baseBookingRequest.getOrganiserId() : baseBookingRequest.getBartenderId();

            firstName = currentUser.getUserType() == UserType.BARTENDER ?
                    baseBookingRequest.getOrganiserFirstName() : baseBookingRequest.getBartenderFirstName();

            lastName = currentUser.getUserType() == UserType.BARTENDER ?
                            baseBookingRequest.getOrganierLastName() : baseBookingRequest.getBartenderLastName();


        } else {

            resultingUserid = currentUser.getUserType() == UserType.BARTENDER ?
                    job.getOrganiserId() : job.getBartenderId();

            firstName = currentUser.getUserType() == UserType.BARTENDER ?
                    job.getOrganiserFirstName() : job.getBartenderFirstName();

            lastName = currentUser.getUserType() == UserType.BARTENDER ?
                    job.getOrganiserLastName() : job.getBartenderLastName();

        }

        // final temp variables for use in inner classes
        final String finalResultingUserid = resultingUserid;
        final String finalFirstName = firstName;
        final String finalLastName = lastName;


        message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseManagement.getInstance().addContact(currentUser.getUid(),
                        currentUser.getFirstName() + " " + currentUser.getLastName(),
                        finalResultingUserid,
                        finalFirstName + " " + finalLastName);
                Intent intent = new Intent(v.getContext(), MessagingActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("Contact_ID", finalResultingUserid);
                intent.putExtra("Contact_Name", finalFirstName + " " + finalLastName);
                v.getContext().startActivity(intent);
            }
        });

    }

    /**
     * This method inflated a qr code pop up that can be scanned
     */
    private void showQrCodePopUp() {

        LayoutInflater inflater = (LayoutInflater) activity.getSystemService(LAYOUT_INFLATER_SERVICE);

        // Inflate the custom layout/view
        final View negotiatePopUp = inflater.inflate(R.layout.qr_code_popup, null, false);

        // Initialize a new instance of popup window
        final PopupWindow mPopupWindow = new PopupWindow(negotiatePopUp, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        mPopupWindow.setFocusable(true);
        mPopupWindow.update();

        // Set an elevation value for popup window
        // Call requires API level 21
        if (Build.VERSION.SDK_INT >= 21) {
            mPopupWindow.setElevation(5.0f);
        }
        ImageButton exitPopUp = (ImageButton) negotiatePopUp.findViewById(R.id.exit_popup_button);

        ImageView imageView = (ImageView) negotiatePopUp.findViewById(R.id.qr_code_imageview);

        Bitmap bitmap = GenCode.generateBitMap(job.getSecuredData());

        BitmapDrawable ob = new BitmapDrawable(activity.getResources(), bitmap);

        imageView.setBackground(ob);

        mPopupWindow.showAtLocation(negotiatePopUp, Gravity.CENTER, 0, 0);

        // Set a click listener for the popup window close button
        exitPopUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Dismiss the popup window
                mPopupWindow.dismiss();
            }
        });

    }

    /**
     * This method represents a description pop that will displayed
     */
    private void showDescriptionEventPopup() {

        LayoutInflater inflater = (LayoutInflater) activity.getSystemService(LAYOUT_INFLATER_SERVICE);

        // Inflate the custom layout/view
        final View descriptionPopUp = inflater.inflate(R.layout.event_description_popup, null, false);

        // Initialize a new instance of popup window
        final PopupWindow mPopupWindow = new PopupWindow(descriptionPopUp, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        mPopupWindow.setFocusable(true);
        mPopupWindow.update();

        // Set an elevation value for popup window
        // Call requires API level 21
        if (Build.VERSION.SDK_INT >= 21) {
            mPopupWindow.setElevation(5.0f);
        }

        TextView description = (TextView) descriptionPopUp.findViewById(R.id.event_description_field);
        ImageButton exitPopUp = (ImageButton) descriptionPopUp.findViewById(R.id.exit_popup_button);

        if (job != null)
            description.setText(job.getEvent().getDescription());
        else {
            description.setText(event.getDescription());

        }

        mPopupWindow.showAtLocation(descriptionPopUp, Gravity.CENTER, 0, 0);

        // Set a click listener for the popup window close button
        exitPopUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Dismiss the popup window
                mPopupWindow.dismiss();
            }
        });

    }


}
