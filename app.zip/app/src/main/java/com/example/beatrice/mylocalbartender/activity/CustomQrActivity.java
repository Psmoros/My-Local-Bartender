package com.example.beatrice.mylocalbartender.activity;

/**
 * Created by louis on 09/03/17.
 */

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.view.KeyEvent;
import android.view.View;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.async.AsyncQrCode;
import com.example.beatrice.mylocalbartender.controller.OnSwipeTouchListener;
import com.google.zxing.ResultPoint;
import com.google.zxing.client.android.BeepManager;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.BarcodeView;

import java.util.List;

/**
 * This sample performs continuous scanning, displaying the barcode and source image whenever
 * a barcode is scanned.
 */
public class CustomQrActivity extends Activity {

    private BarcodeView barcodeView;
    private BeepManager beepManager;

    private BarcodeCallback callback = new BarcodeCallback() {
        @Override
        public void barcodeResult(BarcodeResult result) {


            if (result != null) {
                //Send Payment
                beepManager.playBeepSoundAndVibrate();

                String res = result.getText();
                String[] parts = res.split("\\$");
                String job_id =parts[0];
                String bartenderId = parts[1];
                String organiserId = parts[2];
                String jobId = parts[3];
                String secretKey = parts[4];

                AsyncQrCode asyncClass = new AsyncQrCode(CustomQrActivity.this,job_id,bartenderId,organiserId);
                asyncClass.execute(bartenderId, organiserId, job_id, secretKey);

            }


        }

        @Override
        public void possibleResultPoints(List<ResultPoint> resultPoints) {
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.custom_qr_code_layout);
        ConstraintLayout mainLayout = (ConstraintLayout) findViewById(R.id.mainLayout);
        mainLayout.setOnTouchListener(new OnSwipeTouchListener(this) {
            @Override
            public void onSwipeLeft() {
                Intent intent = new Intent(CustomQrActivity.this, MainNavigationActivity.class);
                startActivity(intent);
            }
        });

        beepManager = new BeepManager(this);
        beepManager.setVibrateEnabled(true);
        barcodeView = (BarcodeView) findViewById(R.id.barCodeView);
        barcodeView.decodeSingle(callback);
    }

    @Override
    protected void onResume() {
        super.onResume();

        barcodeView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();

        barcodeView.pause();
    }

    public void pause(View view) {
        barcodeView.pause();
    }

    public void resume(View view) {
        barcodeView.resume();
    }

    public void triggerScan(View view) {
        barcodeView.decodeSingle(callback);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return barcodeView.onKeyDown(keyCode, event) || super.onKeyDown(keyCode, event);
    }
}