package com.example.beatrice.mylocalbartender.model;

/**
 *  Creates an instance of Contact
 */
public class Contacts {

    //holds the UID of the contact
    private String UID;
    //holds the name of the contact
    private String name;
    //holds the last message with this contact
    private String lastMessage;
    //holds the time of the last message
    private String time;

    /**
     * Creates a instance of a Contact
     */
    public Contacts() {
    }

    /**
     * Creates a instance of a Contact
     *
     * @param UID,  The uid of the user you wish to be made into a contact as a string
     * @param name, The name of the user as a string
     */
    public Contacts(String UID, String name) {
        this.UID = UID;
        this.name = name;
    }

    /**
     * @return returns the UID of theis contact as a string
     */
    public String getUID() {
        return UID;
    }

    /**
     * @param UID, sets the UID of the contact
     */
    public void setUID(String UID) {
        this.UID = UID;
    }

    /**
     * @return returns the name of the contact as a string
     */
    public String getName() {
        return name;
    }

    /**
     * @param name, sets the name of the contact
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return returns the last message to the contact
     */
    public String getTime() { return time; }

    /**
     * @param time, sets the time of the last message to this contact
     */
    public void setTime(String time) {
        this.time = time;
    }

    /**
     * @return returns the time of the last message
     */
    public String getLastMessage() { return lastMessage; }

    /**
     * @param lastMessage, sets the lastMessage
     */
    public void setLastMessage(String lastMessage) {
        this.lastMessage = lastMessage;
    }

}
