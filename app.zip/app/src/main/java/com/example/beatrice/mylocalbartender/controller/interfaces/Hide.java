package com.example.beatrice.mylocalbartender.controller.interfaces;

/**
 * Created by Umar on 09/03/2017.
 *
 * This is a hide interface used to hide view given an event happening
 */
public interface Hide {

    public void hide();

    public void reveal();

}
