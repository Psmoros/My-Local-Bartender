package com.example.beatrice.mylocalbartender.utils;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.model.Event;
import com.example.beatrice.mylocalbartender.model.Organiser;

/**
 * Created by louis on 17/03/17.
 */

public class MyLinearLayout extends LinearLayout  {
    public MyLinearLayout(Context context) {
        super(context);
    }

    public MyLinearLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public MyLinearLayout(Context context, AttributeSet attributeSet, int defStyle) {
        super(context, attributeSet, defStyle);
    }


    public void addToLayout(final Event event, final Organiser organiser, View window){
        final View eventLayout = LayoutInflater.from(getContext()).inflate(R.layout.event_select_in_list_widget, this, false);
        TextView eventName = (TextView) eventLayout.findViewById(R.id.event_name_popup);
        final Button selectEventButton = (Button) eventLayout.findViewById(R.id.select_event_button);

        TextView title = (TextView) window.findViewById(R.id.alert_dialog_title);
        if(title.getText().toString().equals("No Events"))
            title.setText("Select Events");

        eventName.setText(event.getTitle());

        addView(eventLayout);

        selectEventButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                selectEventButton.setSelected(!selectEventButton.isSelected());

                if(selectEventButton.isSelected()){

                    organiser.addToSelectedEvents(event);

                } else{

                    organiser.eraseFromSelectedEvents(event);

                }
            }
        });
    }
}
