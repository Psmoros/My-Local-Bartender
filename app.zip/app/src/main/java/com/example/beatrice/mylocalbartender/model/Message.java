package com.example.beatrice.mylocalbartender.model;

import android.net.Uri;

/**
 * This class is used to create a Message object
 */
public class Message {

    //holds the message text
    private String text;
    //the name of the person who sent the message
    private String name;
    //the time at withc the message was sent
    private String timeStamp;
    //the uri of a photo if sent
    private Uri photoUrl;
    //tells us if the message has been read by the outher user
    private boolean read;

    /**
     * constructs an empty message object
     */
    public Message() {
    }

    /**
     * constructs a message object
     *
     * @param text,      the text you wish to send as a string
     * @param name,      the name of the contact sending the message as a string
     * @param timeStamp, the time at witch this message object is being constructed as a string
     */
    public Message(String text, String name, String timeStamp) {
        this.text = text;
        this.name = name;
        this.timeStamp = timeStamp;
    }

    /**
     * constructs a message object
     *
     * @param photoUrl,  the photo you with so send as a url
     * @param name,      the name of the contact sending the message as a string
     * @param timeStamp, the time at witch this message object is being constructed as a string
     */
    public Message(Uri photoUrl, String name, String timeStamp) {
        this.photoUrl = photoUrl;
        this.name = name;
        this.timeStamp = timeStamp;
    }

    /**
     * @param text, sets the text of the message
     */
    public void setText(String text) {
        this.text = text;
    }

    /**
     * @return returns the name of the contact created the message
     */
    public String getName() {
        return name;
    }

    /**
     * @param name, sets the name of the message
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return returns the photo uir
     */
    public Uri getPhotoUrl() {
        return photoUrl;
    }

    /**
     * @return returns the text of the message
     */
    public String getText() {
        return text;
    }

    /**
     * @param photoUrl, sets the photo uri of the message
     */
    public void setPhotoUrl(Uri photoUrl) {
        this.photoUrl = photoUrl;
    }

    /**
     * @return reuturns the time at wothc the message was sent
     */
    public String getTimeStamp() {
        return timeStamp;
    }

    /**
     * @param timeStamp, sets the time stamp of the message
     */
    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    /**
     * @return returns true of the message has been read and false if not
     */
    public boolean isRead() {
        return read;
    }

    /**
     * @param read, sets the message to be read
     */
    public void setRead(boolean read) {
        this.read = read;
    }

}
