package com.example.beatrice.mylocalbartender.model;


import com.example.beatrice.mylocalbartender.utils.GenCode;
import com.google.zxing.common.BitMatrix;

import java.math.BigInteger;
import java.security.SecureRandom;

/**
 * Created by Chris and Umar on 20/02/17.
 * This class represents a Job that needs to be completed. The event object is bundled into the job for easy viewing of data
 */

public class Job {


    private String jobId;
    private boolean completed; // completed will be false;

    private Event event;
    private String bartenderName;
    private String bartenderId;
    private BitMatrix qrCode;

    private String organiserId;
    private String organiserIdCompleted; // This only for a noSQL query hack
    private String bartenderIdCompleted; // This is only for a noSQL query hack
    private String securedData;
    private String bartenderFirstName;
    private String bartenderLastName;
    private String organiserFirstName;
    private String organiserLastName;

    public Job() {}

    /**
     * Constucts an event object
     * @param jobId
     * @param event
     * @param bartenderName
     * @param bartenderId
     * @param organiserId
     */
    public Job(String jobId,
               Event event,
               String bartenderName,
               String bartenderId,
               String organiserId,
               String bartenderFirstName,
               String bartenderLastName,
               String organiserFirstName,
               String organiserLastName) {

        this.jobId = jobId;
        this.event = event;
        this.bartenderName = bartenderName;
        this.bartenderId = bartenderId;
        this.organiserId = organiserId;
        this.organiserIdCompleted = organiserId+"-"+completed; //nosql query hack
        this.bartenderIdCompleted = bartenderId+"-"+completed; // nosql query hack
        SecureRandom randomString = new SecureRandom();
        securedData=this.jobId+"$"+bartenderId+"$"+organiserId+"$"+event.getEvent_id()+"$"+new BigInteger(130, randomString).toString(32);
        //setQrCode(GenCode.generateMatrix(bartenderId+"$"+organiserId+"$"+event.getEvent_id()));

        this.organiserFirstName = organiserFirstName;
        this.organiserLastName = organiserLastName;
        this.bartenderFirstName = bartenderFirstName;
        this.bartenderLastName = bartenderLastName;

    }


    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    public String getBartenderName() {
        return bartenderName;
    }

    public void setBartenderName(String bartenderName) {
        this.bartenderName = bartenderName;
    }

    public String getBartenderId() {
        return bartenderId;
    }

    public void setBartenderId(String bartenderId) {
        this.bartenderId = bartenderId;
    }
    public BitMatrix getQrCode() {
        return qrCode;
    }

    public void setQrCode(BitMatrix qrCode) {
        this.qrCode = qrCode;
    }
    public String getOrganiserId() {
        return organiserId;
    }

    public void setOrganiserId(String organiserId) {
        this.organiserId = organiserId;
    }

    public String getOrganiserIdCompleted() {
        return organiserIdCompleted;
    }

    public void setOrganiserIdCompleted(String organiserIdCompleted) {
        this.organiserIdCompleted = organiserIdCompleted;
    }

    public String getBartenderIdCompleted() {
        return bartenderIdCompleted;
    }

    public void setBartenderIdCompleted(String bartenderIdCompltetd) {
        this.bartenderIdCompleted = bartenderIdCompltetd;

    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getSecuredData() {
        return securedData;
    }

    public void setSecuredData(String securedData) {
        this.securedData = securedData;
    }

    public String getBartenderFirstName() {
        return bartenderFirstName;
    }

    public void setBartenderFirstName(String bartenderFirstName) {
        this.bartenderFirstName = bartenderFirstName;
    }

    public String getBartenderLastName() {
        return bartenderLastName;
    }

    public void setBartenderLastName(String bartenderLastName) {
        this.bartenderLastName = bartenderLastName;
    }

    public String getOrganiserFirstName() {
        return organiserFirstName;
    }

    public void setOrganiserFirstName(String organiserFirstName) {
        this.organiserFirstName = organiserFirstName;
    }

    public String getOrganiserLastName() {
        return organiserLastName;
    }

    public void setOrganiserLastName(String organiserLastName) {
        this.organiserLastName = organiserLastName;
    }
}
