package com.example.beatrice.mylocalbartender.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



/**
 * A helper class to manage database creation and version management.
 * Extends SQLite OpenHelper
 */
class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "UserDatabase.db";
    private static final int DATABASE_VERSION = 1;

    DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Method is called during creation of the database
    @Override
    public void onCreate(SQLiteDatabase database) {
        OrganiserTable.onCreate(database);
        BartenderTable.onCreate(database);
        EventTable.onCreate(database);
        BookingTable.onCreate(database);
        JobTable.onCreate(database);
    }

    // Method is called during an upgrade of the database,
    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion,
                          int newVersion) {
        OrganiserTable.onUpgrade(database, oldVersion, newVersion);
        BartenderTable.onUpgrade(database, oldVersion, newVersion);
        EventTable.onUpgrade(database, oldVersion, newVersion);
        BookingTable.onUpgrade(database, oldVersion, newVersion);
        JobTable.onUpgrade(database, oldVersion, newVersion);
    }



}