package com.example.beatrice.mylocalbartender.controller;

import com.example.beatrice.mylocalbartender.model.Bartender;
import com.example.beatrice.mylocalbartender.model.Pair;

/**
 * Created by louis on 01/03/17.
 */

public interface MyFlowLayoutInterface {

    public void addToLayout(Pair pair, Bartender bartender, String day);

    public void addToLayout(String speciality, Bartender bartender, boolean clickable);


}
