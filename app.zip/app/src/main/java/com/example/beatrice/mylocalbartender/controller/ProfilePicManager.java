package com.example.beatrice.mylocalbartender.controller;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.model.UserType;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import static android.app.Activity.RESULT_OK;

/**
 * Created by louis on 05/03/17.
 * This class is used to load images from the storage bucket and the local sql cache async
 */

public abstract class ProfilePicManager {


    private static Activity activity;
    private static View profilPic;
    private static Uri cropImageUri;
    private static boolean isOval;
    private static boolean modified = false;


    public static void onSelectImageClick(Activity act, View profilePic, boolean oval) {
        isOval = oval;
        activity = act;
        profilPic = profilePic;
        CropImage.startPickImageActivity(act);
    }

    @SuppressLint("NewApi")
    public static void activityResult(int requestCode, int resultCode, Intent data) {

        // handle result of pick image chooser
        if (requestCode == CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE && resultCode == RESULT_OK) {

            Uri imageUri = CropImage.getPickImageResultUri(activity, data);

            // For API >= 23 we need to check specifically that we have permissions to read external storage.
            if (CropImage.isReadExternalStoragePermissionsRequired(activity, imageUri)) {

                // request permissions and handle the result in onRequestPermissionsResult()
                cropImageUri = imageUri;
                activity.requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},   CropImage.PICK_IMAGE_PERMISSIONS_REQUEST_CODE);
            } else {
                // no permissions required or already grunted, can start crop image activity
                startCropImageActivity(imageUri);
            }
        }

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri();
                Bitmap myBitmap = BitmapFactory.decodeFile(resultUri.getPath());
                Drawable drawable;
                if(isOval)
                    drawable = new BitmapDrawable(activity.getResources(), CropImage.toOvalBitmap(myBitmap));
                else{
                    drawable = new BitmapDrawable(activity.getResources(), myBitmap);

                }
                profilPic.setBackground(drawable);
                modified = true;
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();

            }
        }

    }

    private void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (requestCode == CropImage.PICK_IMAGE_PERMISSIONS_REQUEST_CODE) {
            if (cropImageUri != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // required permissions granted, start crop image activity
                startCropImageActivity(cropImageUri);
            } else {
                Toast.makeText(activity, "Cancelling, required permissions are not granted", Toast.LENGTH_LONG).show();
            }
        }
    }

    private static void startCropImageActivity(Uri imageUri) {

        CropImageView.CropShape cropShape = null;
        if(isOval){
            cropShape = CropImageView.CropShape.OVAL;
        }
        else{
            cropShape = CropImageView.CropShape.RECTANGLE;
        }
        CropImage.activity(imageUri)
                .setCropShape(cropShape)
                .setMinCropResultSize(200,200)
                .setMaxCropResultSize(8000,8000)
                .start(activity);
    }


    public static void uploadPicToStorage(final StorageReference storageObjectRef, View profilPic, String uid, final DatabaseReference objectRef){

        if(modified == true) {
            profilPic.setDrawingCacheEnabled(true);
            profilPic.buildDrawingCache();
            Bitmap bitmap = profilPic.getDrawingCache();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] data = baos.toByteArray();

            saveToInternalStorage(bitmap, activity, uid);

            UploadTask uploadTask = storageObjectRef.child(uid).putBytes(data);
            uploadTask.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {
                    // Handle unsuccessful uploads
                }
            }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    // taskSnapshot.getMetadata() contains file metadata such as size, content-type, and download URL.
                    Uri downloadUrl = taskSnapshot.getDownloadUrl();
                    Log.v("URI", downloadUrl.toString());
                    modified = false;
                }
            });
        }
        else{
            Log.v("Not Modified", "Image not pushed to DB");
        }

    }

    public static void setPicFromDB(StorageReference storageObjectRef, final Activity act, final View profilePic, final String uid, final boolean isOval, final boolean store){

        final BitmapDrawable[] drawable = new BitmapDrawable[1];
        final Bitmap[] bitmapToReturn = new Bitmap[1];
        final long ONE_MEGABYTE = 1024 * 1024;

        storageObjectRef.child(uid).getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                if(isOval){
                    bitmapToReturn[0] = CropImage.toOvalBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.length));
                }
                else{
                    bitmapToReturn[0] = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                }
                drawable[0] = new BitmapDrawable(act.getResources(), bitmapToReturn[0]);
                profilePic.setBackground(drawable[0]);
                if(store == true){
                    saveToInternalStorage(bitmapToReturn[0], act, uid);
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {


                    Log.d("FailedToLoadImage",exception.toString());
                if(isOval) {
                    profilePic.setBackground(
                            act.getResources().getDrawable(R.drawable.ic_profile_default));
                }else{
                    profilePic.setBackground(
                            act.getResources().getDrawable(R.drawable.organizer));
                }

            }
        });

    }

    private static String saveToInternalStorage(Bitmap bitmapImage, Activity act, String uid){
        ContextWrapper cw = new ContextWrapper(act.getApplicationContext());
        // path to /data/data/yourapp/app_data/imageDir
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        // Create imageDir
        File mypath=new File(directory,uid);

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return directory.getAbsolutePath();
    }

    public static void loadProfilePicFromStorage(View profilePic, Activity act, String uid, boolean isOval, StorageReference storageReference)
    {

        Log.v("Profile Pic manager", "Loading pic "+uid+" from storage");

        try {
            ContextWrapper cw = new ContextWrapper(act.getApplicationContext());
            File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
            File f=new File(directory.getAbsolutePath(), uid);
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
            Drawable drawable = new BitmapDrawable(act.getResources(),b);
            profilePic.setBackground(drawable);


        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
            setPicFromDB(storageReference, act, profilePic, uid, isOval, true);
        }

    }

    public static boolean eraseImage(Activity act, String uid){
        ContextWrapper cw = new ContextWrapper(act.getApplicationContext());
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        File f=new File(directory.getAbsolutePath(), uid);
        boolean deleted = f.delete();
        return deleted;
    }


}
