package com.example.beatrice.mylocalbartender.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.activity.NewEventActivity;
import com.example.beatrice.mylocalbartender.controller.adapters.GenericRecyclerAdapter;
import com.example.beatrice.mylocalbartender.controller.view_holders.EventHolder;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.model.Event;
import com.example.beatrice.mylocalbartender.model.Organiser;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

/**
 * Created by Umar on 02/03/2017.
 * This class is a fragment for displaying the events that are organised by public or private.
 * This is the class where you will also create an event, public or priavte
 *
 */

public class EventFragment extends android.app.Fragment implements View.OnClickListener {

    private GenericRecyclerAdapter adapter;
    private boolean isPublicEvent = false;
    private FloatingActionButton offMarketEvents;
    private FloatingActionButton onMarketEvents;
    private FloatingActionButton createEvent;
    private final String AVAILABILITY = "isPublicEvent";
    private FirebaseStorage storage = FirebaseStorage.getInstance();
    private Organiser organiser;
    private ImageView dividerToHide;
    private RecyclerView recyclerView;
    private Button createEventsButton;
    private TextView noEventTextView;
    private TextView currentTabTitle;
    private FrameLayout layout;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        organiser = (Organiser) FirebaseManagement.getInstance().currentUser;

        if (savedInstanceState != null) {

            isPublicEvent = (boolean) savedInstanceState.get(AVAILABILITY);
        }

    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        View view = inflater.inflate(R.layout.events_view, container, false);

        layout = (FrameLayout) view.findViewById(R.id.events_framelayout);

        adapter = new GenericRecyclerAdapter<Event,EventHolder>(
                Event.class
                ,R.layout.event_result_layout
                ,EventHolder.class){

            @Override
            public void bindViewWithData(EventHolder holder, Event model, int position) {

                createEventsButton.setVisibility(View.GONE);
                noEventTextView.setVisibility(View.GONE);
                dividerToHide.setVisibility(View.GONE);
                holder.bindData(model,getActivity(),organiser);

            }

            @Override
            public void notifyEmptyDataSet() {

                createEventsButton.setVisibility(View.VISIBLE);
                noEventTextView.setVisibility(View.VISIBLE);

            }

        };

        dividerToHide = (ImageView) view.findViewById(R.id.divider_to_hide);

        currentTabTitle = (TextView) view.findViewById(R.id.current_tab_title);

        createEventsButton= (Button) view.findViewById(R.id.create_event_button);

        noEventTextView = (TextView) view.findViewById(R.id.no_events_text_view);

        offMarketEvents = (FloatingActionButton) view.findViewById(R.id.off_market_events);

        onMarketEvents = (FloatingActionButton) view.findViewById(R.id.on_market_events);

        createEvent = (FloatingActionButton) view.findViewById(R.id.create_event);

        offMarketEvents.setOnClickListener(this);

        onMarketEvents.setOnClickListener(this);

        createEventsButton.setOnClickListener(this);

        createEvent.setOnClickListener(this);

        recyclerView = (RecyclerView) view.findViewById(R.id.eventrecycler_view);

        recyclerView.setHasFixedSize(true);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        setFirebaseAdapter(isPublicEvent,adapter);

        return view;


    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }


    @Override
    public void onDetach() {

        super.onDetach();


    }


    /**
     * This will set the firebase adapter
     *
     * @param isPublicEvent Specifies whether the event is public or not
     */

    public void setFirebaseAdapter(boolean isPublicEvent, GenericRecyclerAdapter genericRecyclerAdapter) {

        organiser.fetchEventsFromDB(genericRecyclerAdapter, isPublicEvent);

        recyclerView.setAdapter(adapter);

        adapter.notifyDataSetChanged();

    }

    /**
     * Saving the instance state of the boolean that shows the adapter
     *
     * @param outState
     */
    @Override
    public void onSaveInstanceState(Bundle outState) {

        outState.putBoolean(AVAILABILITY, isPublicEvent);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.off_market_events:
                isPublicEvent = false;
                currentTabTitle.setText("Private Events");
                adapter.clearAllData();
                setFirebaseAdapter(isPublicEvent,adapter);
                break;
            case R.id.on_market_events:
                isPublicEvent = true;
                currentTabTitle.setText("Public Events");
                adapter.clearAllData();
                setFirebaseAdapter(isPublicEvent,adapter);
                break;
            case R.id.create_event:
                Intent intent = new Intent(getActivity(), NewEventActivity.class);
                startActivity(intent);
                break;
            case R.id.create_event_button:
                Intent intent1 = new Intent(getActivity(), NewEventActivity.class);
                startActivity(intent1);
                break;

        }
    }

}
