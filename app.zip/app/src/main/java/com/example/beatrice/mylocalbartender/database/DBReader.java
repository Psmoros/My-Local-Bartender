package com.example.beatrice.mylocalbartender.database;


import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;

import com.example.beatrice.mylocalbartender.model.Bartender;
import com.example.beatrice.mylocalbartender.model.BaseRequest;
import com.example.beatrice.mylocalbartender.model.BookingStatus;
import com.example.beatrice.mylocalbartender.model.Event;
import com.example.beatrice.mylocalbartender.model.Job;
import com.example.beatrice.mylocalbartender.model.Organiser;
import com.example.beatrice.mylocalbartender.model.UserType;

import java.util.ArrayList;

/**
 * Used to read data from the sql database.
 */
public class DBReader extends AsyncTask<Object, Void, Object> {
    private SQLiteDatabase database;
    private DBHelper dbHelper;
    private DBCallback callback;

    public DBReader(Context context){dbHelper = new DBHelper(context);}

    @Override
    protected Object doInBackground(Object... params) {
        callback = (DBCallback) params[2];

        if (params[0].getClass() == Bartender.class){
            return readBartenderTable((String)params[1]);
        }else if (params[0].getClass() == Organiser.class){
            return readOrganiserTable(((String)params[1]));
        }else if (params[0].getClass() == Event.class){
            return readEventTable((String)params[1]);
        }else if (params[0].getClass() == Job.class){
            return readJobTable();
        }else if (params[0].getClass() == BaseRequest.class){
            return readBookingTable();
        }else {return null;}

    }

    @Override
    protected void onPostExecute(Object result) {
        callback.callBack(result);

    }

    public void open() throws SQLException {database = dbHelper.getReadableDatabase();}

    private void close(){dbHelper.close();}

    private Bartender readBartenderTable(String _id){
        open();
        String[] projection = {
                        BartenderTable.COLUMN_ID,
                        BartenderTable.COLUMN_FIRST_NAME,
                        BartenderTable.COLUMN_LAST_NAME,
                        BartenderTable.COLUMN_EMAIL,
                        BartenderTable.COLUMN_GENDER,
                        BartenderTable.COLUMN_PHONE,
                        BartenderTable.COLUMN_LOCATION,
                        BartenderTable.COLUMN_DOB,
                        BartenderTable.COLUMN_USER_TYPE,
                        BartenderTable.COLUMN_PICTURE,
                        BartenderTable.COLUMN_BARTENDER_EXPERIENCE,
                        BartenderTable.COLUMN_SPECIALITY,
                        BartenderTable.COLUMN_NIGHTLY_RATE,
                        BartenderTable.COLUMN_HOURLY_RATE};


        String selection = BartenderTable.COLUMN_ID + " = '" + _id + "'";

        Cursor cursor = database.query(
                BartenderTable.TABLE_BARTENDER,                     // The table to query
                projection,                               // The columns to return
                selection,                                // The columns for the WHERE clause
                null,                                     // The values for the WHERE clause
                null,                                     // group the rows
                null,                                     // filter by row groups
                null                                      // The sort order
        );

        if (cursor != null) {
            cursor.moveToFirst();

            Bartender bartender;
            String firstName, lastName, email, uid, gender, phone, location, dob, userType,
                    picture, barExperience, speciality, nightlyRate, hourlyRate;

            uid = cursor.getString(cursor.getColumnIndex(BartenderTable.COLUMN_ID));
            firstName = cursor.getString(cursor.getColumnIndexOrThrow(BartenderTable.COLUMN_FIRST_NAME));
            lastName = cursor.getString(cursor.getColumnIndexOrThrow(BartenderTable.COLUMN_LAST_NAME));
            email = cursor.getString(cursor.getColumnIndexOrThrow(BartenderTable.COLUMN_EMAIL));
            gender = cursor.getString(cursor.getColumnIndexOrThrow(BartenderTable.COLUMN_GENDER));
            phone = cursor.getString(cursor.getColumnIndexOrThrow(BartenderTable.COLUMN_PHONE));
            location = cursor.getString(cursor.getColumnIndexOrThrow(BartenderTable.COLUMN_LOCATION));
            dob = cursor.getString(cursor.getColumnIndexOrThrow(BartenderTable.COLUMN_DOB));
            userType = cursor.getString(cursor.getColumnIndexOrThrow(BartenderTable.COLUMN_USER_TYPE));
            picture = cursor.getString(cursor.getColumnIndexOrThrow(BartenderTable.COLUMN_PICTURE));
            barExperience = cursor.getString(cursor.getColumnIndexOrThrow(BartenderTable.COLUMN_BARTENDER_EXPERIENCE));
            speciality = cursor.getString(cursor.getColumnIndexOrThrow(BartenderTable.COLUMN_SPECIALITY));
            nightlyRate = cursor.getString(cursor.getColumnIndexOrThrow(BartenderTable.COLUMN_NIGHTLY_RATE));
            hourlyRate = cursor.getString(cursor.getColumnIndexOrThrow(BartenderTable.COLUMN_HOURLY_RATE));
            cursor.close();
            close();

            bartender = new Bartender(firstName,lastName,email,uid);
                bartender.setGender((gender));
                bartender.setPhone(phone);
                bartender.setLocation(location);
                bartender.setDoB(dob);
                if(!userType.isEmpty()){bartender.setUserType(getUserType(userType));}
                bartender.setPicURI(picture);
                bartender.setBarExperience(barExperience);
                bartender.setSpecialities(speciality);
                if(!nightlyRate.isEmpty()){bartender.setNightlyRate(Double.valueOf(nightlyRate));}
                if(!hourlyRate.isEmpty()){bartender.setHourlyRate(Double.valueOf(hourlyRate));}

            return bartender;

        }else{
            close();
            return null;
        }

    }

    private Organiser readOrganiserTable(String _id){
        open();
        String[] projection = {
                OrganiserTable.COLUMN_ID,
                OrganiserTable.COLUMN_FIRST_NAME,
                OrganiserTable.COLUMN_LAST_NAME,
                OrganiserTable.COLUMN_EMAIL,
                OrganiserTable.COLUMN_GENDER,
                OrganiserTable.COLUMN_PHONE,
                OrganiserTable.COLUMN_LOCATION,
                OrganiserTable.COLUMN_DOB,
                OrganiserTable.COLUMN_USER_TYPE,
                OrganiserTable.COLUMN_PICTURE,
                OrganiserTable.COLUMN_PROFESSION,
                OrganiserTable.COLUMN_BUSINESS_NAME,
                OrganiserTable.COLUMN_BUSINESS_PROFILE};

        String selection = OrganiserTable.COLUMN_ID + " = '" + _id + "'";

        Cursor cursor = database.query(
                OrganiserTable.TABLE_ORGANISER,           // The table to query
                projection,                               // The columns to return
                selection,                                // The columns for the WHERE clause
                null,                                     // The values for the WHERE clause
                null,                                     // don't group the rows
                null,                                     // don't filter by row groups
                null                                      // The sort order
        );

        if (cursor != null) {
            cursor.moveToFirst();

            Organiser organiser;
            String firstName, lastName, email, uid, gender, phone, location, dob, userType,
                    picture, profession, business, profile;

            firstName = cursor.getString(cursor.getColumnIndexOrThrow(OrganiserTable.COLUMN_FIRST_NAME));
            lastName = cursor.getString(cursor.getColumnIndexOrThrow(OrganiserTable.COLUMN_LAST_NAME));
            email = cursor.getString(cursor.getColumnIndexOrThrow(OrganiserTable.COLUMN_EMAIL));
            uid = cursor.getString(cursor.getColumnIndexOrThrow(OrganiserTable.COLUMN_ID));
            gender = cursor.getString(cursor.getColumnIndexOrThrow(OrganiserTable.COLUMN_GENDER));
            phone = cursor.getString(cursor.getColumnIndexOrThrow(OrganiserTable.COLUMN_PHONE));
            location = cursor.getString(cursor.getColumnIndexOrThrow(OrganiserTable.COLUMN_LOCATION));
            dob = cursor.getString(cursor.getColumnIndexOrThrow(OrganiserTable.COLUMN_DOB));
            userType = cursor.getString(cursor.getColumnIndexOrThrow(OrganiserTable.COLUMN_USER_TYPE));
            picture = cursor.getString(cursor.getColumnIndexOrThrow(OrganiserTable.COLUMN_PICTURE));
            profession = cursor.getString(cursor.getColumnIndexOrThrow(OrganiserTable.COLUMN_PROFESSION));
            business = cursor.getString(cursor.getColumnIndexOrThrow(OrganiserTable.COLUMN_BUSINESS_NAME));
            profile = cursor.getString(cursor.getColumnIndexOrThrow(OrganiserTable.COLUMN_BUSINESS_PROFILE));
            cursor.close();
            close();

            organiser = new Organiser(firstName,lastName,email,uid);
            organiser.setGender((gender));
            organiser.setPhone(phone);
            organiser.setLocation(location);
            organiser.setDoB(dob);
            if(!userType.isEmpty()){organiser.setUserType(getUserType(userType));}
            organiser.setPicURI(picture);
            organiser.setProfessionalPosition(profession);
            organiser.setFirstName(business);
            organiser.setBusinessBio(profile);


            return organiser;

        }else{
            close();
            return null;
        }

    }

    private ArrayList<Event> readEventTable(String UserUid) {
        open();
        String[] projection = {
                EventTable.COLUMN_ID,
                EventTable.COLUMN_PICTURE,
                EventTable.COLUMN_TITLE,
                EventTable.COLUMN_DESCRIPTION,
                EventTable.COLUMN_LOCATION,
                EventTable.COLUMN_DATE,
                EventTable.COLUMN_START,
                EventTable.COLUMN_END,
                EventTable.COLUMN_ORGANISER_UID,
                EventTable.COLUMN_ORGANISER_NAME,
                EventTable.COLUMN_SHIFT_RATE,
                EventTable.COLUMN_AVAILABLE,
                EventTable.COLUMN_BARTENDERS,
                EventTable.COLUMN_DAY_EVENT,
                EventTable.COLUMN_PUBLIC};

        String selection = EventTable.COLUMN_ORGANISER_UID+ " ='" + UserUid + "'";

        Cursor cursor = database.query(
                EventTable.TABLE_EVENT,           // The table to query
                projection,                               // The columns to return
                selection,                                // The columns for the WHERE clause
                null,                                     // The values for the WHERE clause
                null,                                     // don't group the rows
                null,                                     // don't filter by row groups
                null                                      // The sort order
        );

        if (cursor != null) {
            ArrayList<Event> events = new ArrayList<>();
            int rows = cursor.getCount();
            cursor.moveToFirst();
            for (int i = 0; i < rows;){
                Event event = new Event();
                String id, picURI, title, description, location, date, start, end, organiserUID, organiserName;
                Double shiftRate;
                Integer availability, requiredBartenders, isDayEvent, isPublicEvent;

                id = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_ID));
                picURI = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_PICTURE));
                title = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_TITLE));
                description = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_LOCATION));
                location = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_LOCATION));
                date = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_DATE));
                start = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_START));
                end = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_END));
                organiserUID = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_ORGANISER_UID));
                organiserName = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_ID));
                shiftRate = Double.valueOf(cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_SHIFT_RATE))) ;
                availability = cursor.getInt(cursor.getColumnIndexOrThrow(EventTable.COLUMN_AVAILABLE));
                requiredBartenders = cursor.getInt(cursor.getColumnIndexOrThrow(EventTable.COLUMN_BARTENDERS));
                isDayEvent = cursor.getInt(cursor.getColumnIndexOrThrow(EventTable.COLUMN_DAY_EVENT));
                isPublicEvent = cursor.getInt(cursor.getColumnIndexOrThrow(EventTable.COLUMN_PUBLIC));

                event.setEvnet_id(id);
                event.setPicURI(picURI);
                event.setTitle(title);
                event.setDescription(description);
                event.setLocation(location);
                event.setDate(date);
                event.setStartTime(start);
                event.setFinishTime(end);
                event.setOrganiserUid(organiserUID);
                event.setOrganiserName(organiserName);
                event.setShiftRate(shiftRate);
                event.setAvailable(translateInteger(availability));
                event.setRequiredBartenders(requiredBartenders);
                event.setDayEvent(translateInteger(isDayEvent));
                event.setEventPublic(translateInteger(isPublicEvent));

                events.add(event);
                i++;
                cursor.move(i);
            }
            cursor.close();
            close();
            return events;

        }else{
            close();
            return null;
        }
    }


    private ArrayList<BaseRequest> readBookingTable() {
        open();
        String[] projection = {
                BookingTable.COLUMN_ID,
                BookingTable.COLUMN_EVENT,
                BookingTable.COLUMN_ORGANISER,
                BookingTable.COLUMN_BARTENDER,
                BookingTable.COLUMN_BOOKING_STATUS,
                BookingTable.COLUMN_ACCEPTED,
                };

        String selection = "*";

        Cursor cursor = database.query(
                BookingTable.TABLE_BOOKING,           // The table to query
                projection,                               // The columns to return
                selection,                                // The columns for the WHERE clause
                null,                                     // The values for the WHERE clause
                null,                                     // don't group the rows
                null,                                     // don't filter by row groups
                null                                      // The sort order
        );

        if (cursor != null) {
            ArrayList<BaseRequest> bookings = new ArrayList<>();
            int rows = cursor.getCount();
            cursor.moveToFirst();
            for (int i = 0; i < rows;){
                BaseRequest booking = new BaseRequest();
                String id, event_id, organiser_id, bartender_id, status;
                Integer bartenderAccepted;

                id = cursor.getString(cursor.getColumnIndexOrThrow(BookingTable.COLUMN_ID));
                event_id = cursor.getString(cursor.getColumnIndexOrThrow(BookingTable.COLUMN_EVENT));
                organiser_id = cursor.getString(cursor.getColumnIndexOrThrow(BookingTable.COLUMN_ORGANISER));
                bartender_id = cursor.getString(cursor.getColumnIndexOrThrow(BookingTable.COLUMN_BARTENDER));
                status = cursor.getString(cursor.getColumnIndexOrThrow(BookingTable.COLUMN_BOOKING_STATUS));
                bartenderAccepted = cursor.getInt(cursor.getColumnIndexOrThrow(BookingTable.COLUMN_ACCEPTED));

                booking.setBookingID(id);
                booking.setEvent(singleEvent(event_id));
                booking.setOrganiserId(organiser_id);
                booking.setBartenderId(bartender_id);
                booking.setStatus(getBookingStatus(status));
                booking.setBartenderAccepted(translateInteger(bartenderAccepted));

                bookings.add(booking);
                i++;
                cursor.move(i);
            }
            cursor.close();
            close();
            return bookings;

        }else{
            close();
            return null;
        }

    }

    private ArrayList<Job> readJobTable() {
        open();
        String[] projection = {
                JobTable.COLUMN_ID,
                JobTable.COLUMN_EVENT,
                JobTable.COLUMN_COMPLETED,
                JobTable.COLUMN_BARTENDER_NAME,
                JobTable.COLUMN_BARTENDER_ID,
                JobTable.COLUMN_ORGANISER_ID,
                JobTable.COLUMN_QR};

        String selection = "*";

        Cursor cursor = database.query(
                JobTable.TABLE_JOB,           // The table to query
                projection,                               // The columns to return
                selection,                                // The columns for the WHERE clause
                null,                                     // The values for the WHERE clause
                null,                                     // don't group the rows
                null,                                     // don't filter by row groups
                null                                      // The sort order
        );

        if (cursor != null) {
            ArrayList<Job> jobs = new ArrayList<>();
            int rows = cursor.getCount();
            cursor.moveToFirst();
            for (int i = 0; i < rows;){
                Job job = new Job();
                String id, eventID, bartenderName, bartenderID, organiserID, QRCode;
                Integer completed;

                id = cursor.getString(cursor.getColumnIndexOrThrow(JobTable.COLUMN_ID));
                eventID = cursor.getString(cursor.getColumnIndexOrThrow(JobTable.COLUMN_EVENT));
                completed = cursor.getInt(cursor.getColumnIndexOrThrow(JobTable.COLUMN_COMPLETED));
                bartenderName = cursor.getString(cursor.getColumnIndexOrThrow(JobTable.COLUMN_BARTENDER_NAME));
                bartenderID = cursor.getString(cursor.getColumnIndexOrThrow(JobTable.COLUMN_BARTENDER_ID));
                organiserID = cursor.getString(cursor.getColumnIndexOrThrow(JobTable.COLUMN_ORGANISER_ID));
                QRCode = cursor.getString(cursor.getColumnIndexOrThrow(JobTable.COLUMN_QR));

                job.setJobId(id);
                job.setEvent(singleEvent(eventID));
                job.setCompleted(translateInteger(completed));
                job.setBartenderName(bartenderName);
                job.setBartenderId(bartenderID);
                job.setOrganiserId(organiserID);
                //job.setQrCode(BitMatrix.parse(QRCode));

                jobs.add(job);
                i++;
                cursor.move(i);
            }
            cursor.close();
            close();
            return jobs;

        }else{
            close();
            return null;
        }
    }

    private Event singleEvent(String event_id){
        open();
        String[] projection = {
                EventTable.COLUMN_ID,
                EventTable.COLUMN_PICTURE,
                EventTable.COLUMN_TITLE,
                EventTable.COLUMN_DESCRIPTION,
                EventTable.COLUMN_LOCATION,
                EventTable.COLUMN_DATE,
                EventTable.COLUMN_START,
                EventTable.COLUMN_END,
                EventTable.COLUMN_ORGANISER_UID,
                EventTable.COLUMN_ORGANISER_NAME,
                EventTable.COLUMN_SHIFT_RATE,
                EventTable.COLUMN_AVAILABLE,
                EventTable.COLUMN_BARTENDERS,
                EventTable.COLUMN_DAY_EVENT,
                EventTable.COLUMN_PUBLIC};

        String selection = EventTable.COLUMN_ID + " = '" + event_id + "'";;

        Cursor cursor = database.query(
                EventTable.TABLE_EVENT,           // The table to query
                projection,                               // The columns to return
                selection,                                // The columns for the WHERE clause
                null,                                     // The values for the WHERE clause
                null,                                     // don't group the rows
                null,                                     // don't filter by row groups
                null                                      // The sort order
        );

        if (cursor != null) {

            cursor.moveToFirst();

                Event event = new Event();
                String id, picURI, title, description, location, date, start, end, organiserUID, organiserName;
                Double shiftRate;
                Integer availability, requiredBartenders, isDayEvent, isPublicEvent;

                id = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_ID));
                picURI = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_PICTURE));
                title = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_TITLE));
                description = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_LOCATION));
                location = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_LOCATION));
                date = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_DATE));
                start = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_START));
                end = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_END));
                organiserUID = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_ORGANISER_UID));
                organiserName = cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_ID));
                shiftRate = Double.valueOf(cursor.getString(cursor.getColumnIndexOrThrow(EventTable.COLUMN_SHIFT_RATE))) ;
                availability = cursor.getInt(cursor.getColumnIndexOrThrow(EventTable.COLUMN_AVAILABLE));
                requiredBartenders = cursor.getInt(cursor.getColumnIndexOrThrow(EventTable.COLUMN_BARTENDERS));
                isDayEvent = cursor.getInt(cursor.getColumnIndexOrThrow(EventTable.COLUMN_DAY_EVENT));
                isPublicEvent = cursor.getInt(cursor.getColumnIndexOrThrow(EventTable.COLUMN_PUBLIC));

                event.setEvnet_id(id);
                event.setPicURI(picURI);
                event.setTitle(title);
                event.setDescription(description);
                event.setLocation(location);
                event.setDate(date);
                event.setStartTime(start);
                event.setFinishTime(end);
                event.setOrganiserUid(organiserUID);
                event.setOrganiserName(organiserName);
                event.setShiftRate(shiftRate);
                event.setAvailable(translateInteger(availability));
                event.setRequiredBartenders(requiredBartenders);
                event.setDayEvent(translateInteger(isDayEvent));
                event.setEventPublic(translateInteger(isPublicEvent));



            cursor.close();
            close();
            return event;

        }else{
            close();
            return null;
        }
    }

    private UserType getUserType(String stringUserType){
        UserType userType;
        if (stringUserType.equals(UserType.BARTENDER.toString())){
            userType = UserType.BARTENDER;
        } else {
            userType = UserType.ORGANISER;
        }
        return userType;
    }

    private BookingStatus getBookingStatus(String stringBookingStatus){
        if(stringBookingStatus.equals(BookingStatus.ACCEPTED.toString())){
            return BookingStatus.ACCEPTED;
        }else if (stringBookingStatus.equals(BookingStatus.APPROVED.toString())){
            return BookingStatus.APPROVED;
        }else if (stringBookingStatus.equals(BookingStatus.OFFERED.toString())){
            return BookingStatus.OFFERED;
        }else if (stringBookingStatus.equals(BookingStatus.REJECTED.toString())){
            return BookingStatus.REJECTED;
        }else{
            return null;
        }
    }

    private Boolean translateInteger(Integer i){
        if (i == 0){return false;}
        else   {return true;}
    }
}