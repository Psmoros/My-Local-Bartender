package com.example.beatrice.mylocalbartender.async;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.NameValuePair;
import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.client.entity.UrlEncodedFormEntity;
import cz.msebera.android.httpclient.client.methods.HttpPost;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;
import cz.msebera.android.httpclient.message.BasicNameValuePair;

/**
 * Created by Umar on 10/03/2017.
 * This allows the registerations tokens for each device to be sent to the server
 *
 */

public class MessagingAsync extends AsyncTask<String,String,Void> {

    @Override
    protected Void doInBackground(String... params) {

        try {

            sendRegistrationToServer(params[0], params[1]);

        } catch (IOException e) {

            e.printStackTrace();
        }

        return null;

    }


    /**
     * Send token to Node server
     *
     * @param token The new token.
     */
    private void sendRegistrationToServer(String token, String id) throws IOException {
        //   URL url = new URL("http://mlb-server.herokuapp.com/token");
        try {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://mlb-server.herokuapp.com/token");

            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
            nameValuePairs.add(new BasicNameValuePair("token", token));
            nameValuePairs.add(new BasicNameValuePair("id", id));
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

            // Execute HTTP Post Request
            HttpResponse response = httpclient.execute(httppost);

            BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            sb.append(reader.readLine() + "\n");
            String line = "0";
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            reader.close();
            String result11 = sb.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }





}
