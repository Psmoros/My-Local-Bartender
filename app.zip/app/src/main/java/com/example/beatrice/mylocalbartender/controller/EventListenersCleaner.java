package com.example.beatrice.mylocalbartender.controller;

import android.provider.ContactsContract;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DatabaseReference;

import java.util.EventListener;
import java.util.HashMap;

/**
 * Created by louis on 07/03/17.
 */

public  class EventListenersCleaner {
    private static HashMap<ChildEventListener, DatabaseReference> toClean = new HashMap<>();

    public static void addRefToClean(DatabaseReference ref, ChildEventListener event){
        toClean.put(event, ref);
    }

    public static void cleanEventListeners(){
      for(ChildEventListener event : toClean.keySet()){
          toClean.get(event).removeEventListener(event);
      }

        toClean.clear();
    }

}
