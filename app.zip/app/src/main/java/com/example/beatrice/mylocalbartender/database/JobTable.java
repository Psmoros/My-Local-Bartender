package com.example.beatrice.mylocalbartender.database;


import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

/**
 * The Java class representation of the SQLite table 'job'.
 */
public class JobTable {
    public static final String TABLE_JOB = "job";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_EVENT = "event_id";
    public static final String COLUMN_COMPLETED = "is_completed";
    public static final String COLUMN_BARTENDER_NAME = "bartenderName";
    public static final String COLUMN_BARTENDER_ID = "bartenderId";
    public static final String COLUMN_ORGANISER_ID = "organiserId";
    public static final String COLUMN_QR = "qrCode";

    private static final String DATABASE_CREATE =
            "create table "
                    +TABLE_JOB
                    +"("
                    +COLUMN_ID + " TEXT PRIMARY KEY, "
                    +COLUMN_EVENT + " TEXT NOT NULL, "
                    +COLUMN_COMPLETED + " INTEGER NOT NULL, "
                    +COLUMN_BARTENDER_NAME + " TEXT NOT NULL, "
                    +COLUMN_BARTENDER_ID + " TEXT NOT NULL, "
                    +COLUMN_ORGANISER_ID + " TEXT NOT NULL, "
                    +COLUMN_QR + " TEXT NOT NULL, "
                    +"FOREIGN KEY("+COLUMN_EVENT+") REFERENCES event(_id)"
                    + ");";

    /**
     * Called when the database is created for the first time. This is where the
     * creation of tables and the initial population of the tables happens.
     *
     * @param database The SQLite database.
     */
    public static void onCreate(SQLiteDatabase database) {
        database.execSQL(DATABASE_CREATE);
    }

    /**
     * Called when the database needs to be upgraded. The implementation
     * should use this method to drop tables, add tables, or do anything else it
     * needs to upgrade to the new schema version.
     *
     * @param database The SQLite database.
     * @param oldVersion The old database version.
     * @param newVersion The new database version.
     */
    public static void onUpgrade(SQLiteDatabase database, int oldVersion,
                                 int newVersion) {
        Log.w(JobTable.class.getName(), "Upgrading database from version "
                + oldVersion + " to " + newVersion
                + ", which will destroy all old data");
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_JOB);
        onCreate(database);
    }
}