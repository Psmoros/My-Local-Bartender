package com.example.beatrice.mylocalbartender.database;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;

import com.example.beatrice.mylocalbartender.model.Bartender;
import com.example.beatrice.mylocalbartender.model.BaseRequest;
import com.example.beatrice.mylocalbartender.model.Event;
import com.example.beatrice.mylocalbartender.model.Job;
import com.example.beatrice.mylocalbartender.model.Organiser;

/**
 * Used to write data to the SQL database.
 */
public class DBWriter extends AsyncTask<Object, Void, Object> {
    private SQLiteDatabase database;
    private DBHelper dbHelper;
    private DBCallback callback;


    public DBWriter(Context context){
        dbHelper = new DBHelper(context);
    }


    @Override
    protected Object doInBackground(Object... params) {
        callback = (DBCallback) params[1];

        if (params[0].getClass() == Bartender.class){
            return writeToBartenderTable((Bartender) params[0]);
        }else if (params[0].getClass() == Organiser.class){
            return writeToOrganiserTable((Organiser) params[0]);
        }else if (params[0].getClass() == Event.class){
            return writeToEventTable((Event) params[0]);
        }else if (params[0].getClass() == Job.class){
            return writeToJobTable((Job) params[0]);
        }else if (params[0].getClass() == BaseRequest.class){
            return writeToBookingTable((BaseRequest) params[0]);
        }else {return null;}
    }

    @Override
    protected void onPostExecute(Object result) {
        callback.callBack(result);
    }

    public void open() throws SQLException{
        database = dbHelper.getWritableDatabase();
    }

    private void close(){dbHelper.close();}

    private Bartender writeToBartenderTable(Bartender bartender){
        open();
        ContentValues values = new ContentValues();

        values.put(BartenderTable.COLUMN_ID, bartender.getUid());
        values.put(BartenderTable.COLUMN_FIRST_NAME, bartender.getFirstName());
        values.put(BartenderTable.COLUMN_LAST_NAME, bartender.getLastName());
        values.put(BartenderTable.COLUMN_EMAIL, bartender.getEmail());
        values.put(BartenderTable.COLUMN_GENDER, bartender.getGender());
        values.put(BartenderTable.COLUMN_PHONE, bartender.getPhone());
        values.put(BartenderTable.COLUMN_LOCATION, bartender.getLocation());
        values.put(BartenderTable.COLUMN_DOB, bartender.getDoB());
        if(bartender.getUserType() != null){
            values.put(BartenderTable.COLUMN_USER_TYPE, bartender.getUserType().toString());
        }
        values.put(BartenderTable.COLUMN_PICTURE, bartender.getPicURI());
        values.put(BartenderTable.COLUMN_BARTENDER_EXPERIENCE, bartender.getBarExperience());
        values.put(BartenderTable.COLUMN_SPECIALITY, bartender.getSpecialities());
        values.put(BartenderTable.COLUMN_NIGHTLY_RATE, bartender.getNightlyRate());
        values.put(BartenderTable.COLUMN_HOURLY_RATE, bartender.getHourlyRate());

        if(checkRow(BartenderTable.TABLE_BARTENDER, BartenderTable.COLUMN_ID,bartender.getUid())){
            String[] whereClauseArguments ={bartender.getUid()};
            database.update(BartenderTable.TABLE_BARTENDER, values,BartenderTable.COLUMN_ID+ "=?",whereClauseArguments);
        }else{
            database.insert(BartenderTable.TABLE_BARTENDER, null, values);
        }
        close();
        return bartender;
    }

    private Organiser writeToOrganiserTable(Organiser organiser) {
        open();
        ContentValues values = new ContentValues();

        values.put(OrganiserTable.COLUMN_ID, organiser.getUid());
        values.put(OrganiserTable.COLUMN_FIRST_NAME, organiser.getFirstName());
        values.put(OrganiserTable.COLUMN_LAST_NAME, organiser.getLastName());
        values.put(OrganiserTable.COLUMN_EMAIL, organiser.getEmail());
        values.put(OrganiserTable.COLUMN_GENDER, organiser.getGender());
        values.put(OrganiserTable.COLUMN_PHONE, organiser.getPhone());
        values.put(OrganiserTable.COLUMN_LOCATION, organiser.getLocation());
        values.put(OrganiserTable.COLUMN_DOB, organiser.getDoB());
        if(organiser.getUserType() != null){
            values.put(OrganiserTable.COLUMN_USER_TYPE, organiser.getUserType().toString());
        }
        values.put(OrganiserTable.COLUMN_PICTURE, organiser.getPicURI());
        values.put(OrganiserTable.COLUMN_PROFESSION, organiser.getProfessionalPosition());
        values.put(OrganiserTable.COLUMN_BUSINESS_NAME, organiser.getBusinessName());
        values.put(OrganiserTable.COLUMN_BUSINESS_PROFILE, organiser.getBusinessBio());

        if(checkRow(OrganiserTable.TABLE_ORGANISER, OrganiserTable.COLUMN_ID,organiser.getUid())){
            String[] whereClauseArguments = {organiser.getUid()};
            database.update(OrganiserTable.TABLE_ORGANISER, values,OrganiserTable.COLUMN_ID+ "=?", whereClauseArguments );
        }else{
            database.insert(OrganiserTable.TABLE_ORGANISER, null, values);
        }
        close();
        return organiser;
    }


    private BaseRequest writeToBookingTable(BaseRequest baseRequest) {
        open();
        ContentValues values = new ContentValues();

        values.put(BookingTable.COLUMN_ID, baseRequest.getBookingID());
        values.put(BookingTable.COLUMN_EVENT, baseRequest.getEvent().getEvent_id());
        values.put(BookingTable.COLUMN_ORGANISER, baseRequest.getOrganiserId());
        values.put(BookingTable.COLUMN_BARTENDER, baseRequest.getBartenderId());
        values.put(BookingTable.COLUMN_BOOKING_STATUS, baseRequest.getStatus().toString());
        values.put(BookingTable.COLUMN_ACCEPTED, translateBoolean(baseRequest.isBartenderAccepted()));

        if(checkRow(BookingTable.TABLE_BOOKING, BookingTable.COLUMN_ID,baseRequest.getBookingID())){
            database.update(BookingTable.TABLE_BOOKING, values,null,null);
        }else{
            database.insert(BookingTable.TABLE_BOOKING, null, values);
        }
        close();
        return baseRequest;
    }

    private Job writeToJobTable(Job job) {
        open();
        ContentValues values = new ContentValues();

        values.put(JobTable.COLUMN_ID, job.getJobId());
        values.put(JobTable.COLUMN_EVENT, job.getEvent().getEvent_id());
        values.put(JobTable.COLUMN_COMPLETED, translateBoolean(job.isCompleted()));
        values.put(JobTable.COLUMN_BARTENDER_NAME, job.getBartenderName());
        values.put(JobTable.COLUMN_BARTENDER_ID, job.getBartenderId());
        values.put(JobTable.COLUMN_ORGANISER_ID, job.getOrganiserId());
        values.put(JobTable.COLUMN_QR, job.getQrCode().toString());

        if(checkRow(JobTable.TABLE_JOB, JobTable.COLUMN_ID,job.getJobId())){
            database.update(JobTable.TABLE_JOB, values,null,null);
        }else{
            database.insert(JobTable.TABLE_JOB, null, values);
        }
        close();
        return job;
    }

    private Event writeToEventTable(Event event) {
        open();
        ContentValues values = new ContentValues();

        values.put(EventTable.COLUMN_ID, event.getEvent_id());
        values.put(EventTable.COLUMN_PICTURE, event.getPicURI());
        values.put(EventTable.COLUMN_TITLE, event.getTitle());
        values.put(EventTable.COLUMN_DESCRIPTION, event.getDescription());
        values.put(EventTable.COLUMN_LOCATION, event.getLocation());
        values.put(EventTable.COLUMN_DATE, event.getDate());
        values.put(EventTable.COLUMN_START, event.getStartTime());
        values.put(EventTable.COLUMN_END, event.getFinishTime());
        values.put(EventTable.COLUMN_ORGANISER_UID, event.getOrganiserUid());
        values.put(EventTable.COLUMN_ORGANISER_NAME, event.getOrganiserName());
        values.put(EventTable.COLUMN_SHIFT_RATE, event.getShiftRate());
        values.put(EventTable.COLUMN_AVAILABLE, translateBoolean(event.isAvailable()));
        values.put(EventTable.COLUMN_BARTENDERS, event.getRequiredBartenders());
        values.put(EventTable.COLUMN_DAY_EVENT, translateBoolean(event.isDayEvent()));
        values.put(EventTable.COLUMN_PUBLIC, translateBoolean(event.isEventPublic()));


       if(checkRow(EventTable.TABLE_EVENT, EventTable.COLUMN_ID,event.getEvent_id())){
            database.update(EventTable.TABLE_EVENT, values,null,null);
        }else{
           database.insert(EventTable.TABLE_EVENT, null, values);
       }
        close();
        return event;
    }

    private Integer translateBoolean(Boolean boo){
        if (boo){return 1;}
        else {return 0;}
    }


    private boolean checkRow(String TableName, String columnName, String fieldValue) {
        String query = "SELECT * FROM " + TableName + " WHERE " + columnName + " = '" + fieldValue+ "'";
        Cursor cursor = database.rawQuery(query, null);
        if(cursor.getCount() <= 0){
            cursor.close();
            return false;
        }
        cursor.close();
        return true;
    }

}