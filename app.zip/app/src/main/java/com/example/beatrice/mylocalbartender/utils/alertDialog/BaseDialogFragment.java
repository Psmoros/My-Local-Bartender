package com.example.beatrice.mylocalbartender.utils.alertDialog;

import android.app.Activity;
import android.support.v4.app.DialogFragment;

/**
 * Created by louis on 16/03/17.
 * This respresents a base alert dialogue that all dialogues will inherit from
 */

public abstract class BaseDialogFragment<T> extends DialogFragment {
    private T mActivityInstance;

    public final T getActivityInstance() {
        return mActivityInstance;
    }

    @Override
    public void onAttach(Activity activity) {
        mActivityInstance = (T) activity;
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mActivityInstance = null;
    }
}