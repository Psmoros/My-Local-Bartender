package com.example.beatrice.mylocalbartender.model;

import android.support.annotation.VisibleForTesting;
import android.util.Log;

import com.example.beatrice.mylocalbartender.controller.EventListenersCleaner;
import com.example.beatrice.mylocalbartender.controller.interfaces.ResultsInterface;
import com.example.beatrice.mylocalbartender.firebase.FirebaseChildAdapter;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQueryEventListener;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

/**
 * Created by louis on 12/03/17.
 * This class searches for events and bartenders that fall within a location box
 */

public class SearchGeoListener implements GeoQueryEventListener {

    private DatabaseReference usersRef;
    private DatabaseReference root;
    private ResultsInterface<User> userSearchQueryInterface;
    private ResultsInterface<Event> eventSearchQueryInterface;

    // adding the recycler adapter so you can popul
    //
    // ate from the results

    private UserType userType;
    private double rate, nightlyRate, hourlyRate;
    private String speciality;
    private String day;
    private int startTime, endTime;
    private String lastUserFound;
    private ArrayList<String> founds;

    public SearchGeoListener(UserType userType,
                             double rate,
                             double nightlyRate,
                             double hourlyRate,
                             String speciality,
                             String day,
                             int startTime,
                             int endTime,
                             ResultsInterface searchQueryInterface) {

        this.root = FirebaseDatabase.getInstance().getReference();
        usersRef = FirebaseDatabase.getInstance().getReference().child("Users");
        this.hourlyRate = hourlyRate;
        this.rate = rate;
        this.nightlyRate = nightlyRate;
        this.speciality = speciality;
        this.day = day;
        this.startTime = startTime;
        this.endTime = endTime;
        lastUserFound = "";
        founds = new ArrayList<>();

        this.userType = userType;
        if (userType == UserType.BARTENDER) {
            this.eventSearchQueryInterface = searchQueryInterface;
        } else {
            this.userSearchQueryInterface = searchQueryInterface;

        }
    }

    @VisibleForTesting
    protected SearchGeoListener(UserType userType,
                                double rate,
                                double nightlyRate,
                                double hourlyRate,
                                String speciality,
                                String day,
                                int startTime,
                                int endTime,
                                ResultsInterface searchQueryInterface,
                                DatabaseReference usersRef,
                                DatabaseReference root) {


        this.usersRef = usersRef;
        this.root = root;
        this.hourlyRate = hourlyRate;
        this.rate = rate;
        this.nightlyRate = nightlyRate;
        this.speciality = speciality;
        this.day = day;
        this.startTime = startTime;
        this.endTime = endTime;
        lastUserFound = "";
        founds = new ArrayList<>();

        this.userType = userType;
        if (userType == UserType.BARTENDER) {
            this.eventSearchQueryInterface = searchQueryInterface;
        } else {
            this.userSearchQueryInterface = searchQueryInterface;

        }


    }

    @Override
    public void onKeyEntered(final String key, GeoLocation location) {


        //To Filter by available Dates
        DatabaseReference selectedRef;
        final String split[] = key.split("SPECIALSPLIT");


        if (userType == UserType.BARTENDER) {
            selectedRef = root.child("Events").child(split[1]);
        } else {
            selectedRef = root.child("AvailableDate").child(key).child(day);
        }

        ChildEventListener selectedRefListener = selectedRef.addChildEventListener(new FirebaseChildAdapter() {

            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                if (dataSnapshot.getValue() != null) {
                    if (userType == UserType.ORGANISER) {
                        Pair pair = dataSnapshot.getValue(Pair.class);
                        if ((pair.getStartTime() <= startTime && pair.getEndTime() >= endTime && pair.isAvailable() == true &&
                                key != lastUserFound)
                                || (startTime == 24 && endTime == 24 && key != lastUserFound)) {
                            lastUserFound = key;
                            query(key, userSearchQueryInterface);
                        }
                    } else {
                        Event event = dataSnapshot.getValue(Event.class);
                        if ((event.isAvailable() == true && !founds.contains(event.getEvent_id()))
                                || (startTime == 24 && endTime == 24 && !founds.contains(event.getEvent_id()))) {
                            founds.add(event.getEvent_id());
                            eventSearchQueryInterface.addToList(event);
                        }
                    }
                }
            }


        });

        EventListenersCleaner.addRefToClean(selectedRef, selectedRefListener);
    }

    @Override
    public void onKeyExited(String key) {

    }

    @Override
    public void onKeyMoved(String key, GeoLocation location) {

    }

    @Override
    public void onGeoQueryReady() {

    }

    @Override
    public void onGeoQueryError(DatabaseError error) {

    }

    /**
     * Query by type Of User, Rate and price
     *
     * @param key
     */
    private void query(String key, final ResultsInterface searchQueryInterface) {
        final DatabaseReference selectedChild = usersRef.child(key);

        //To Filter by type of user
        selectedChild.child("userType").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if ((boolean) dataSnapshot.getValue().equals("BARTENDER")) {

                    //To Filter by rate
                    selectedChild.child("rate").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if ((long) dataSnapshot.getValue() >= rate) {
                                if (nightlyRate == 0.0) {
                                    //To Filter by hourlyRate
                                    selectedChild.child("hourlyRate").addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(DataSnapshot dataSnapshot) {
                                            if ((long) dataSnapshot.getValue()
                                                    <= hourlyRate) {
                                                selectedChild.addListenerForSingleValueEvent(new SearchValueListener(speciality, searchQueryInterface));
                                            }
                                        }

                                        @Override
                                        public void onCancelled(DatabaseError databaseError) {

                                        }
                                    });

                                } else if (hourlyRate == 0.0) {
                                    //To Filter by nightlyRate
                                    selectedChild.child("nightlyRate").addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(DataSnapshot dataSnapshot) {
                                            if ((long) dataSnapshot.getValue() <= nightlyRate) {
                                                selectedChild.addListenerForSingleValueEvent(new SearchValueListener(speciality, searchQueryInterface));
                                            }
                                        }

                                        @Override
                                        public void onCancelled(DatabaseError databaseError) {

                                        }
                                    });
                                }
                            }
                        }


                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }


        });
    }
}
