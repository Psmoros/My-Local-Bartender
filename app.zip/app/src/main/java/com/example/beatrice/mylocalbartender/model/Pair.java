package com.example.beatrice.mylocalbartender.model;

/**
 * Created by wasanshubbar on 10/02/2017.
 * This class is used to hold a pair of dates that a bartender is available for
 */

public class Pair {
    private int startTime;
    private int endTime;
    private boolean available;
    private String id;

    public Pair(int startTime, int endTime) {
        this.startTime = startTime;
        this.endTime = endTime;
        available = true;
        id = Integer.toString(startTime) + Integer.toString(endTime);
    }

    public Pair() {

    }

    public int getStartTime() {
        return startTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public String toString() {
        return startTime + " - " + endTime;
    }

    public boolean equals(Pair pair) {
        return this.id == pair.getId();
    }


}