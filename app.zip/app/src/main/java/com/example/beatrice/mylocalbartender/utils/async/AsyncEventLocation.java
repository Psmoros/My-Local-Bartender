package com.example.beatrice.mylocalbartender.utils.async;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.google.android.gms.maps.model.LatLng;

/**

 * Created by Umar on 22/03/2017.
 * Asynchronously uploads a location to the database for an event

 */

public class AsyncEventLocation extends AsyncLocation {


    private String eventId;
    private String organiserId;


    /**
     * Pass in the geo fire object the edit text and the current firebase user
     *
     * @param geoFire
     */
    public AsyncEventLocation(GeoFire geoFire, String eventId,String organiserId) {
        super(geoFire);
        this.eventId = eventId;
        this.organiserId = organiserId;
    }

    @Override
    protected void onPostExecute(LatLng latLng) {
        if(latLng!=null) {
            geoFire.setLocation(eventId+"SPECIALSPLIT"+organiserId, new GeoLocation(latLng.latitude, latLng.longitude));
        }
    }
}
