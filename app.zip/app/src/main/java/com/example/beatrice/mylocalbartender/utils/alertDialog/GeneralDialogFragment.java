package com.example.beatrice.mylocalbartender.utils.alertDialog;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.example.beatrice.mylocalbartender.R;

/**
 * Created by louis on 16/03/17.
 * A general dialogue pop up. Use this class if you would like to have a standard pop up framework
 */

public class GeneralDialogFragment extends BaseDialogFragment<GeneralDialogFragment.OnDialogFragmentClickListener> {

    // interface to handle the dialog click back to the Activity
    public interface OnDialogFragmentClickListener {
        public void onAlertDialogLeftClicked(GeneralDialogFragment dialog);
        public void onAlertDialogRightClicked(GeneralDialogFragment dialog);
    }

    // Create an instance of the Dialog with the input
    public static GeneralDialogFragment newInstance(String title, String message, String leftButton, String rightButton) {
        GeneralDialogFragment frag = new GeneralDialogFragment();
        Bundle args = new Bundle();
        args.putString("title", title);
        args.putString("content", message);
        args.putString("leftButton", leftButton);
        args.putString("rightButton", rightButton);
        frag.setArguments(args);
        return frag;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.my_alert_dialog, container, false);
        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getDialog().getWindow().requestFeature(Window.FEATURE_SWIPE_TO_DISMISS);
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        getDialog().getWindow().setWindowAnimations(R.style.FadeAnimation);

        Button leftButton = (Button) view.findViewById(R.id.alert_dialog_left_button);
        Button rightButton = (Button) view.findViewById(R.id.alert_dialog_right_button);
        TextView title = (TextView) view.findViewById(R.id.alert_dialog_title);
        TextView content = (TextView) view.findViewById(R.id.alert_dialog_content);

        title.setText(getArguments().getString("title"));
        content.setText(getArguments().getString("content"));


        leftButton.setText(getArguments().getString("leftButton"));
        leftButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivityInstance().onAlertDialogLeftClicked(GeneralDialogFragment.this);
            }
        });

        rightButton.setText(getArguments().getString("rightButton"));
        rightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivityInstance().onAlertDialogRightClicked(GeneralDialogFragment.this);
            }
        });


        return view;
    }

}
