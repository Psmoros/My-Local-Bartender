package com.example.beatrice.mylocalbartender.activity;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.controller.ProfilePicManager;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.model.Bartender;
import com.example.beatrice.mylocalbartender.model.BaseRequest;
import com.example.beatrice.mylocalbartender.model.BookingStatus;
import com.example.beatrice.mylocalbartender.model.Event;
import com.example.beatrice.mylocalbartender.model.Organiser;
import com.example.beatrice.mylocalbartender.utils.Colours;
import com.example.beatrice.mylocalbartender.utils.Keys;
import com.example.beatrice.mylocalbartender.utils.MyFlowLayout;
import com.example.beatrice.mylocalbartender.utils.MyLinearLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

/**
 * Created by wasanshubbar on 01/03/2017.
 *
 * This class holds all the information for a bartender that can be displayed
 */

public class BartenderProfile extends AppCompatActivity {

    private Bartender bartender;
    private ImageView profileImage;
    private TextView bartenderName;
    private ImageView bartenderRating;
    private TextView hourlyRating;
    private TextView nightlyRating;
    private TextView bartenderDescription;
    private MyFlowLayout specialitiesFlowLayout;
    private Button sendJobRequestButton;


    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference root = database.getReference();
    private FirebaseManagement firebaseManagement = FirebaseManagement.getInstance();
    private FirebaseStorage storage = FirebaseStorage.getInstance();
    private StorageReference storageRef = storage.getReference();
    private StorageReference profilePicRef = storageRef.child("ProfilePictures");

    private  Organiser organiser;
    private LinearLayout layout3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.bartender_profile);

        profileImage = (ImageView) findViewById(R.id.bartender_profile_pic_field);
        bartenderName = (TextView) findViewById(R.id.bartender_name_field);
        bartenderRating = (ImageView) findViewById(R.id.bartender_rating);
        hourlyRating = (TextView) findViewById(R.id.hourly_shift_rate_field);
        nightlyRating = (TextView) findViewById(R.id.nightly_shift_rate_field);
        bartenderDescription = (TextView) findViewById(R.id.bartender_description_field);
        sendJobRequestButton = (Button) findViewById(R.id.send_job_request_button);
        specialitiesFlowLayout = (MyFlowLayout) findViewById(R.id.bartender_specialitity_flow_layout);
        layout3 = (LinearLayout) findViewById(R.id.bartender_profile_layout);

        if(Colours.isDefault == false) {
            layout3.setBackgroundColor(Color.parseColor(Colours.backgroundColour));
        }

        if (!getIntent().getExtras().get("Previous Act").equals("Profile Settings")){
            bartender = (Bartender) getIntent().getExtras().get(Keys.BARTENDER);
            organiser = (Organiser) FirebaseManagement.getInstance().currentUser;
            sendJobRequestButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showHirePopUp();
                }
            });
            ProfilePicManager.setPicFromDB(profilePicRef, this, profileImage, bartender.getUid(), true, false);

        }
        else{
            bartender = (Bartender) FirebaseManagement.getInstance().currentUser;
            organiser = null;
            sendJobRequestButton.setVisibility(View.GONE);
            ProfilePicManager.loadProfilePicFromStorage(profileImage, this, bartender.getUid(),true, profilePicRef);
        }



        bartenderDescription.setMovementMethod(new ScrollingMovementMethod());

        //to stop parent linearlayout scrollview when touched on textview
        bartenderDescription.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });

        setText(bartenderName, bartender.getFirstName().toUpperCase().charAt(0) + " . " + bartender.getLastName().toUpperCase().charAt(0));

        if(bartender.getRate() == 0.0)
            bartenderRating.setBackground(getResources().getDrawable(R.drawable.glass_rating_0));
        else if(Math.floor(bartender.getRate()) <= 1.0)
            bartenderRating.setBackground(getResources().getDrawable(R.drawable.glass_rating_1));
        else if(bartender.getRate() > 1.0 && Math.floor(bartender.getRate()) <= 1.5)
            bartenderRating.setBackground(getResources().getDrawable(R.drawable.glass_rating_15));
        else if(bartender.getRate() > 1.5 && Math.floor(bartender.getRate()) <= 2.0)
            bartenderRating.setBackground(getResources().getDrawable(R.drawable.glass_rating_2));
        else if(bartender.getRate() > 2.0 && Math.floor(bartender.getRate()) <= 2.5)
            bartenderRating.setBackground(getResources().getDrawable(R.drawable.glass_rating_25));
        else if(bartender.getRate() > 2.5 && Math.floor(bartender.getRate()) <= 3.0)
            bartenderRating.setBackground(getResources().getDrawable(R.drawable.glass_rating_3));
        else if(bartender.getRate() > 3.0 && Math.floor(bartender.getRate()) <= 3.5)
            bartenderRating.setBackground(getResources().getDrawable(R.drawable.glass_rating_35));
        else if(bartender.getRate() > 3.5 && Math.floor(bartender.getRate()) <= 4.0)
            bartenderRating.setBackground(getResources().getDrawable(R.drawable.glass_rating_4));
        else if(bartender.getRate() > 4.0 && Math.floor(bartender.getRate()) <= 4.5)
            bartenderRating.setBackground(getResources().getDrawable(R.drawable.glass_rating_45));
        else if(bartender.getRate() > 4.5 && Math.floor(bartender.getRate()) <= 5.0)
            bartenderRating.setBackground(getResources().getDrawable(R.drawable.glass_rating_5));

        setText(hourlyRating, String.valueOf(bartender.getHourlyRate()));

        setText(nightlyRating, String.valueOf(bartender.getNightlyRate()));

        setText(bartenderDescription, bartender.getBarExperience());


        if(bartender.fetchSpecialities()!=null) {
            displaySpecialities(bartender);
        }


    }

    //Set text of an field
    private void setText(TextView textView, String text){
        if(text != null) {
            if (!text.isEmpty()) {
                textView.setText(text);
            }
        }
    }

    private void displaySpecialities(Bartender bartender) {
        for(String speciality : bartender.fetchSpecialities()){
            specialitiesFlowLayout.addToLayout(speciality, bartender, false);
        }
    }

    private void showHirePopUp(){
        LayoutInflater inflater = (LayoutInflater) getBaseContext().getSystemService(LAYOUT_INFLATER_SERVICE);

        // Inflate the custom layout/view
        final View hirePopUp = inflater.inflate(R.layout.choose_events_when_hire, null, false);

        // Initialize a new instance of popup window
        final PopupWindow mPopupWindow = new PopupWindow(hirePopUp, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        mPopupWindow.setFocusable(true);
        mPopupWindow.update();
        WindowManager.LayoutParams windowManager = getWindow().getAttributes();
        mPopupWindow.setAnimationStyle(R.style.FadeAnimation);
        windowManager.dimAmount = 0.5f;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);

        // Set an elevation value for popup window
        // Call requires API level 21
        if(Build.VERSION.SDK_INT>=21){
            mPopupWindow.setElevation(5.0f);
        }

        ImageButton exitPopUp = (ImageButton) hirePopUp.findViewById(R.id.exit_popup_button);
        Button hireButton =  (Button) hirePopUp.findViewById(R.id.hire_button);
        MyLinearLayout eventsLayout = (MyLinearLayout) hirePopUp.findViewById(R.id.events_linear_layout);

        mPopupWindow.showAtLocation(hirePopUp, Gravity.CENTER, 0, 0);

        organiser.fetchEvents(eventsLayout, hirePopUp);

        // Set a click listener for the popup window close button
        exitPopUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Dismiss the popup window
                mPopupWindow.dismiss();
                WindowManager.LayoutParams windowManager = getWindow().getAttributes();
                windowManager.dimAmount = 1;
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            }
        });

        hireButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(Event event : organiser.fetchSelectedEvents()){
                    BaseRequest organiserBookingRequest = new BaseRequest("stub",
                            false,
                            event,
                            organiser.getUid(),
                            bartender.getUid(),
                            organiser.getFirstName(),
                            organiser.getLastName(),
                            bartender.getFirstName(),
                            bartender.getLastName(), event.getShiftRate());
                    pushBookingRequest(organiserBookingRequest);

                }
                Toast.makeText(BartenderProfile.this, "Bartender hired !",
                        Toast.LENGTH_LONG).show();
                mPopupWindow.dismiss();

            }
        });


    }
    //// TODO: 23/03/2017  this code needs to be removed to another class
    private void pushBookingRequest(BaseRequest request){

        DatabaseReference pushRef= root.child(Keys.BOOKING_REQEUEST_TABLE).push();
        request.setBookingID(pushRef.getKey());
        request.setStatus(BookingStatus.APPROVED);
        pushRef.setValue(request);
    }

}
