package com.example.beatrice.mylocalbartender.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.model.UserType;

/**
 *Gives user a choice of registering a MLB account as Bartender or Organiser.
 * Launches Register3.
 * @author Team Astra@kcl.ac.uk
 */
public class Registering1 extends AppCompatActivity {

    private Button nextButton;
    private ImageButton bartenderImageButton;
    private ImageButton organiserImageButton;
    private ImageView bartenderGlowDivider;
    private ImageView organiserGlowDider;
    private Animation fadeOutAnimation;
    private Animation fadeInAnimation;
    private TextView userType; // text view to display whether I am a bartender or organiser
    private UserType user;
    // TODO: 18/02/2017 Fix the divider line issue

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registering1);

        userType = (TextView) findViewById(R.id.user_type);
        bartenderGlowDivider = (ImageView) findViewById(R.id.bartender_glow_divider);
        organiserGlowDider = (ImageView) findViewById(R.id.organiser_glow_divider);
        fadeInAnimation = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        fadeOutAnimation = AnimationUtils.loadAnimation(this, R.anim.fade_out);

        //sets UserType as ORGANISER.
        organiserImageButton = (ImageButton) findViewById(R.id.organiser_image_button);
        organiserImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                organiserGlowDider.clearAnimation();
                organiserGlowDider.setVisibility(View.INVISIBLE);
                bartenderGlowDivider.startAnimation(fadeInAnimation);
                bartenderGlowDivider.setVisibility(View.VISIBLE);
                userType.setText((R.string.i_am_a_organiser));
                userType.setVisibility(View.VISIBLE);
                user = UserType.ORGANISER;

            }
        });

        //sets UserType as BARTENDER.
        bartenderImageButton = (ImageButton) findViewById(R.id.bartender_image_button);
        bartenderImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bartenderGlowDivider.clearAnimation();
                bartenderGlowDivider.setVisibility(View.INVISIBLE);
                organiserGlowDider.startAnimation(fadeInAnimation);
                organiserGlowDider.setVisibility(View.VISIBLE);
                userType.setText(R.string.i_am_a_bartender);
                userType.setVisibility(View.VISIBLE);
                user = UserType.BARTENDER;
            }
        });
        //launches Register2 Activity
        nextButton = (Button) findViewById(R.id.next_button);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(user == null)){
                    Intent intent = new Intent(Registering1.this, Registering2.class);
                    intent.putExtra("UserType", user);
                    startActivity(intent);
                }else{
                    Toast.makeText(Registering1.this, "umm who are you?",
                            Toast.LENGTH_LONG).show();
                }

            }
        });

    }

}
