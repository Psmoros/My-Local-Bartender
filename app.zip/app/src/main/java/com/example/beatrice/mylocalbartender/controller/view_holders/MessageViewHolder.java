package com.example.beatrice.mylocalbartender.controller.view_holders;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.beatrice.mylocalbartender.R;

/**
 *  Activity that shows the messages between current user and the chosen contact
 */
public class MessageViewHolder extends RecyclerView.ViewHolder {
    public TextView messageTextView;
    public TextView timeStamp;

    /**
     *
     * @param v, Takes a View
     */
    public MessageViewHolder(View v) {
        super(v);
        messageTextView = (TextView) itemView.findViewById(R.id.txt_msg);
        timeStamp = (TextView) itemView.findViewById(R.id.time_stamp);
    }
}

