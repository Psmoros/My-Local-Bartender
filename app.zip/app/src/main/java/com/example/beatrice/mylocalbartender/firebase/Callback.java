package com.example.beatrice.mylocalbartender.firebase;

import android.content.Context;

/**
 * Created by Umar on 10/02/2017.
 * This interface is primarily used for sign in to decouple the Firebase management class from the screen it is being called from
 */

public interface Callback {

    /**
     * This method should be called in the event of a success
     */
    public void loginSuccessful();

    /**
     * The  method should be called in the event of a failed sign in
     */
    public void loginFailed();



    //public void callBack(Object object);
}

