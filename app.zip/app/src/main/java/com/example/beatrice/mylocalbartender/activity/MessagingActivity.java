package com.example.beatrice.mylocalbartender.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.async.AsyncMessagingNotifs;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.model.Message;
import com.example.beatrice.mylocalbartender.controller.view_holders.MessageViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Activity showing the messages between two users
 */
public class MessagingActivity extends AppCompatActivity {

    // -- variables that hold values used in the activity

    //variable message length as desided by firebase configerations
    public static final String MSG_LENGTH = "msg_length";
    //holds the default length of a message
    private static final int DEFAULT_MSG_LENGTH_LIMIT = 400;
    //holds the number of messages loaded from firebase
    private int numberOfMessagesToLoad = 100;
    //holds the username of the current authenticated user
    private String username;
    //holds the UID of the current authenticated user
    private String userUid;
    //holds the name of the user this activity is communication with
    private String userContactingName;
    //holds the UID of the user this activity is communication with
    private String userContactingUid;
    //holds a instance of a shared preferences (can be altered via firebase)
    private SharedPreferences sharedPreferences;

    // -- variables that hold references to objects and the view

    //holds a instance of the sendButton that sends a message
    private Button sendButton;
    //holds the text to be sent
    private EditText messageToSend;
    //the view that holds ass the messages
    private RecyclerView messageRecyclerView;
    //the layout used by the messageRecyclerView
    private LinearLayoutManager linearLayoutManager;
    //holds a instance of the tool bar that is located at the top of the activity
    private Toolbar toolbar;

    // -- Firebase instance variables

    //holds a firebase reference of the current authenticated user
    private FirebaseAuth firebaseAuth;
    //holds a firebase reference of the name of the current authenticated user
    private FirebaseUser firebaseUser;
    //holds a database reference that points to the area of the database this activity works woth
    private DatabaseReference firebaseDatabaseRef;
    //holds a edited location to the firebaseDatabaseRef
    private DatabaseReference chatRef;
    //a firebase reference to the remote configerations (length of the messages)
    private FirebaseRemoteConfig firebaseRemoteConfigeration;
    //the addapter that is a middel man between the database and the Recycler view
    private FirebaseRecyclerAdapter<Message, MessageViewHolder> firebaseAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messaging);

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        // -- initialize view objects
        sendButton = (Button) findViewById(R.id.sendButton);
        messageToSend = (EditText) findViewById(R.id.messageEditText);
        toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        messageRecyclerView = (RecyclerView) findViewById(R.id.messageRecyclerView);

        // -- initialize Recycler view
        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setStackFromEnd(true);
        messageRecyclerView.setLayoutManager(linearLayoutManager);

        // -- Initialize Firebase
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        firebaseDatabaseRef = FirebaseDatabase.getInstance().getReference();

        // -- initialize user information
        username = FirebaseManagement.getInstance().currentUser.getFirstName();
        userUid = firebaseUser.getUid();
        userContactingUid = getOtherCommunicatorUid();
        userContactingName = getOtherCommunicatorName();

        if(userContactingUid.compareTo(userUid) < 0){
            chatRef = firebaseDatabaseRef.child("MessageData").child(userContactingUid + " " + userUid);
        } else {
            chatRef = firebaseDatabaseRef.child("MessageData").child(userUid + " " + userContactingUid);
        }

        // -- set up of the activity

        //adds the toolBar and sets preferences
        setToolBar();

        //obtains the max message length from firebase or uses defalt_length if unable to obtain firebase value
        setMessageLength();

        //sets the send button to clickable when there is information in the EditText 'messageToSend'
        changeOnInputAllowed();

        //configers the send, camara and gallery buttons
        buttonConfig();

        //loads the chat history
        loadHistory();

        //configers the load more messages button
        addapterAction();

    }


    //adds the toolBar and sets preferences
    private void setToolBar() {

        //adds the toolbar to the activity
        setSupportActionBar(toolbar);

        //gets an editable instance of the toolbar
        ActionBar actionBar = getSupportActionBar();

        //adds a back button returns the activity to the parent activity of this (defined in the manifest)
        actionBar.setDisplayHomeAsUpEnabled(true);

        //sets the title of the tool bar to the name of the contact
        actionBar.setTitle(userContactingName);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home){
            Intent i = new Intent(MessagingActivity.this, MainNavigationActivity.class);
            i.putExtra("fragmentOption",2);
            startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }

    //obtains the max message length from firebase or uses defalt_length if unable to obtain firebase value
    private void setMessageLength(){

        //gets an instance of the firebase configerations (atributes set in firebase)
        firebaseRemoteConfigeration = FirebaseRemoteConfig.getInstance();

        // Define Firebase Remote Config Settings
        FirebaseRemoteConfigSettings firebaseRemoteConfigSettings = new FirebaseRemoteConfigSettings.Builder()
                        .setDeveloperModeEnabled(true)
                        .build();

        // Define default config values. Defaults are used when fetched config values are no available
        Map<String, Object> defaultConfigMap = new HashMap<>();
        defaultConfigMap.put("msg_length", 400);

        // Apply config settings and default values.
        firebaseRemoteConfigeration.setConfigSettings(firebaseRemoteConfigSettings);
        firebaseRemoteConfigeration.setDefaults(defaultConfigMap);

        // Fetch remote configeration information
        fetchConfig();
    }


    //sets the send button to clickable when there is information in the EditText 'messageToSend'
    private void changeOnInputAllowed(){

        //sets the length of char the messageToSend can hold
        messageToSend.setFilters(new InputFilter[]{new InputFilter.LengthFilter(sharedPreferences
                .getInt(MSG_LENGTH, DEFAULT_MSG_LENGTH_LIMIT))});

        //add's a listener to 'messageToSend', when it contains text 'sendButton' is clickable
        //stops user spamming empty messages
        messageToSend.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //if there is text
                if (charSequence.toString().trim().length() > 0) {
                    //set the button to clickable
                    sendButton.setEnabled(true);
                } else {
                    //set the button to not clickable
                    sendButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
    }


    //configers the send, camara and gallery buttons
    private void buttonConfig(){

        //on the click of the 'sendButton' this creates a new Message Object and adds it to the database
        sendButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                final DatabaseReference current = firebaseDatabaseRef.child("Contacts").child(userUid).child(userContactingUid);
                final DatabaseReference contact = firebaseDatabaseRef.child("Contacts").child(userContactingUid).child(userUid);

                //holds a time stamp for the message
                final String timeStamp = getTimeStamp();
                final String text = messageToSend.getText().toString();

                //a new message, it is given the text to be sent, a timestamp and the name of the user that sent it
                Message message = new Message(text,username,timeStamp);

                //pushes the message to the database
                chatRef.push().setValue(message);

                //sets the content of the 'messageToSend' to be empty
                messageToSend.setText("");


                current.child("chatLength").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        int val = Integer.parseInt(dataSnapshot.getValue().toString());
                        val++;

                        AsyncMessagingNotifs nm = new AsyncMessagingNotifs();
                        nm.execute(userContactingUid, username, messageToSend.getText().toString());

                        current.child("time").setValue(timeStamp);
                        current.child("lastMessage").setValue(text);
                        current.child("chatLength").setValue(val);
                        contact.child("time").setValue(timeStamp);
                        contact.child("lastMessage").setValue(text);
                        contact.child("chatLength").setValue(val);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });



                //sets the content of the 'messageToSend' to be empty
                messageToSend.setText("");


            }
        });

        /*camara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent,1);
            }
        });*/
    }

    //loads the chat history into the recycler view
    private void loadHistory(){

        //creates a query to get a defined number of messages
        Query recentMessages = chatRef.limitToLast(numberOfMessagesToLoad);


        //creates a new firebase recycler, is given a java class 'messages' that has the structure of the data to be requested from the database
        //a layout that the information will take
        //a class that transformes the java class information into the given layout
        //a query
        firebaseAdapter = new FirebaseRecyclerAdapter<Message,
                MessageViewHolder>(
                Message.class,
                R.layout.right_message,
                MessageViewHolder.class,
                recentMessages ) {

            //changes the layout (left or right message) depending on who sent the message
            @Override
            public int getItemViewType(int position) {

                if (getItem(position).getName().equals(username)) {
                    return R.layout.right_message;
                } else {
                    return R.layout.left_message;
                }
            }

            //returns the chosen layout (right or left message) to the class ('MessageViewHolder')
            @Override
            public MessageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
                if(viewType == R.layout.right_message) {
                    View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.right_message, parent, false);
                    return new MessageViewHolder(view);
                } else {
                    View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.left_message, parent, false);
                    return new MessageViewHolder(view);
                }
            }

            //populates the recycler view
            @Override
            protected void populateViewHolder(MessageViewHolder viewHolder,
                                              Message message, int position) {

                //gets the message content and adds ot the the class ('MessageViewHolder') that will pass it to the chosen layout
                viewHolder.messageTextView.setText(message.getText());

                String time  = message.getTimeStamp();
                time = time.substring(11,16);


                //adds ticks, one tick for message not read, two for message read
                if (message.getName().equals(username)) {

                    //if message is mine has it been read
                    if(message.isRead()){
                        //read set to two tics
                        viewHolder.timeStamp.setText(time + "  ✓✓");
                    } else {
                        //not read set one tick
                        viewHolder.timeStamp.setText(time + "  ✓");
                    }
                } else {

                    //message isent mine just add the time to the layout
                    viewHolder.timeStamp.setText(time);

                    //update the database that you have read the messages
                    DatabaseReference r = this.getRef(position).child("read");
                    r.setValue(true);
                }
            }
        };

        //sets the view the the bottom of the recycler view
        firebaseAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onItemRangeInserted(int positionStart, int itemCount) {
                super.onItemRangeInserted(positionStart, itemCount);
                int friendlyMessageCount = firebaseAdapter.getItemCount();
                int lastVisiblePosition = linearLayoutManager.findLastCompletelyVisibleItemPosition();

                //if not at the bottom go to the bottom of the recycler view
                if (lastVisiblePosition == -1 || (positionStart >= (friendlyMessageCount - 1) &&
                        lastVisiblePosition == (positionStart - 1))) {
                    messageRecyclerView.scrollToPosition(positionStart);
                }
            }
        });

        //sets the layout of the recicaler of the recycler view (vertical linearLayout)
        messageRecyclerView.setLayoutManager(linearLayoutManager);
        //adds the adapter
        messageRecyclerView.setAdapter(firebaseAdapter);
    }


    //configers the load more messages button
    private void addapterAction(){



        messageRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public final void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (dy < 0) {
                    if (!recyclerView.canScrollVertically(-1)) {
                        onScrolledToTop();
                    }
                }
            }

            public void onScrolledToTop() {

                final DatabaseReference current = firebaseDatabaseRef.child("Contacts").child(userUid).child(userContactingUid);

                current.child("chatLength").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        int val = Integer.parseInt(dataSnapshot.getValue().toString());

                       if(val > numberOfMessagesToLoad){

                           numberOfMessagesToLoad += 50;
                           messageRecyclerView.removeAllViewsInLayout();

                           //reloads the adapter
                           loadHistory();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

            }
        });
    }


    // -- sub methods --


    //creates a time stamp (24 hour clock)
    private String getTimeStamp(){

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");

        String valnow = dateFormat.format(new Date());

        return valnow;
    }


    //returns the name of the contact
    private String getOtherCommunicatorName(){

        //if the intent holds this information get it
        Intent i = this.getIntent();
        if (i != null) {

            //The key argument here must match that used in the other activity
            String var = i.getStringExtra("Contact_Name");
            return var;

        } else {
            return(null);
        }
    }


    //returns the Uid of the contact
    private String getOtherCommunicatorUid(){

        //if the intent holds this information get it
        Intent i = this.getIntent();
        if (i != null) {

            //The key argument here must match that used in the other activity
            String var = i.getStringExtra("Contact_ID");
            return var;

        } else {
            return(null);
        }
    }


    // Fetch the config to determine the allowed length of messages
    //cashes the information for an hour.
    public void fetchConfig() {
        // 1 hour in seconds
        long cacheExpiration = 3600;

        if (firebaseRemoteConfigeration.getInfo().getConfigSettings()
                .isDeveloperModeEnabled()) {
            cacheExpiration = 0;
        }

        firebaseRemoteConfigeration.fetch(cacheExpiration)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        firebaseRemoteConfigeration.activateFetched();
                        //the fetch was a succsess
                        applyRetrievedLengthLimit();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // There has been an error fetching the config
                        applyRetrievedLengthLimit();
                    }
                });
    }

    //Apply retrieved length limit to edit text field
    private void applyRetrievedLengthLimit() {
        Long friendly_msg_length = firebaseRemoteConfigeration.getLong("msg_length");
        messageToSend.setFilters(new InputFilter[]{new
                InputFilter.LengthFilter(friendly_msg_length.intValue())});
    }
}