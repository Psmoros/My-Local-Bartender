package com.example.beatrice.mylocalbartender.controller.interfaces;

import com.example.beatrice.mylocalbartender.model.Organiser;

/**
 * Created by Umar on 26/03/2017.
 * This was creatd to notify that an async task has been accomplished and that an organiser has been
 * retrieved from the server
 */

public interface OrganiserCallback {

    void provideUser(Organiser organiser);

}
