package com.example.beatrice.mylocalbartender.controller.view_holders;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.activity.MessagingActivity;
import com.example.beatrice.mylocalbartender.controller.ProfilePicManager;
import com.example.beatrice.mylocalbartender.model.Contacts;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;


/**
 *  Creates a view for a contact in contactsActivity
 */
public class ContactViewHolder extends RecyclerView.ViewHolder {
    public TextView contactName;
    public TextView timeOfLastMessage;
    public TextView lastMessage;
    public ImageView image;
    public LinearLayout layout;

    /**
     *
     * @param v, Takes a View
     */
    public ContactViewHolder(View v) {
        super(v);
        contactName = (TextView) itemView.findViewById(R.id.contactName);
        timeOfLastMessage = (TextView) itemView.findViewById(R.id.time);
        lastMessage = (TextView) itemView.findViewById(R.id.lastMessage);
        image = (ImageView) itemView.findViewById(R.id.contactImageView);
        layout = (LinearLayout) itemView.findViewById(R.id.contactSelector);
    }


    public void bindWithContact(final Contacts contact, final Activity activity){

        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReference();
        StorageReference profilePicRef = storageRef.child("ProfilePictures");

        ProfilePicManager.loadProfilePicFromStorage(image, activity, contact.getUID(), true, profilePicRef);
        contactName.setText(contact.getName());

        String lastMessage;
        String time;
        try {
            lastMessage = contact.getLastMessage();
            time = contact.getTime().substring(11,16);
        } catch (Exception e){
            lastMessage = "Send your new contact a message";
            time = "";
        }

        timeOfLastMessage.setText(time);

        if(lastMessage.length() > 60) {
            lastMessage = lastMessage.substring(0,60) + " ...";
        }

        this.lastMessage.setText(lastMessage);

        //if the layout for this contact is clicked open the messaging activity
        layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(view.getContext(),MessagingActivity.class);

                //passes the name and UID of the contact to the new activity
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("Contact_ID", contact.getUID() );
                i.putExtra("Contact_Name",contact.getName());
                activity.startActivity(i);
            }
        });













    }


}
