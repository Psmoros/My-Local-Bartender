package com.example.beatrice.mylocalbartender.model;

import com.google.firebase.database.DatabaseReference;


/**
 * This class respresents a booking request either from an organiser or a bartender
 */
public class BaseRequest {


    private String bookingID;
    private boolean bartenderAccepted; // has the bartender accepted it
    private Event event;
    private String organiserId;
    private String bartenderId;
    private BookingStatus status;
    private String bartenderFirstName;
    private String bartenderLastName;
    private String organiserFirstName;
    private String organierLastName;
    private double rate;





    public BaseRequest() {
    }

    public BaseRequest(String bookingID,
                       boolean bartenderAccepted,
                       Event event,
                       String organiserId,
                       String bartenderId,
                       String organiserFirstName,
                       String organierLastName,
                       String bartenderFirstName,
                       String bartenderLastName, double rate) {

        this.bartenderAccepted = bartenderAccepted;
        this.event = event;
        this.organiserId = organiserId;
        this.bartenderId = bartenderId;
        this.rate = rate;

        this.status = BookingStatus.OFFERED;
        this.bookingID = bookingID;
        this.organiserFirstName = organiserFirstName;
        this.organierLastName = organierLastName;
        this.bartenderFirstName = bartenderFirstName;
        this.bartenderLastName = bartenderLastName;
    }

    public String getBookingID() {
        return bookingID;
    }

    public void setBookingID(String bookingID) {
        this.bookingID = bookingID;
    }

    public String getOrganiserId() {
        return organiserId;
    }

    public void setOrganiserId(String organiserId) {
        this.organiserId = organiserId;
    }

    public String getBartenderId() {
        return bartenderId;
    }

    public void setBartenderId(String bartenderId) {
        this.bartenderId = bartenderId;
    }

    public BookingStatus getStatus() {
        return status;
    }

    public void setStatus(BookingStatus status) {
        this.status = status;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }


    public boolean isBartenderAccepted() {
        return bartenderAccepted;
    }

    public void setBartenderAccepted(boolean bartenderAccepted) {
        this.bartenderAccepted = bartenderAccepted;
    }

    /**
     * Two base request objecsts are the same if they contain the same uid
     * @param obj The object that will be compated
     * @return True if they are equal, false if they are not equal
     */
    @Override
    public boolean equals(Object obj) {

        BaseRequest comparedRequest = (BaseRequest) obj;
        return comparedRequest.getBookingID().equals(bookingID);
    }

    public String getBartenderFirstName() {
        return bartenderFirstName;
    }

    public void setBartenderFirstName(String bartenderFirstName) {
        this.bartenderFirstName = bartenderFirstName;
    }

    public String getBartenderLastName() {
        return bartenderLastName;
    }

    public void setBartenderLastName(String bartenderLastName) {
        this.bartenderLastName = bartenderLastName;
    }

    public String getOrganiserFirstName() {
        return organiserFirstName;
    }

    public void setOrganiserFirstName(String organiserFirstName) {
        this.organiserFirstName = organiserFirstName;
    }

    public String getOrganierLastName() {
        return organierLastName;
    }

    public void setOrganierLastName(String organierLastName) {
        this.organierLastName = organierLastName;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }
}
