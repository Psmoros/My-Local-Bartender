package com.example.beatrice.mylocalbartender.utils;

import android.content.Context;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.beatrice.mylocalbartender.activity.BartenderProfileSettings;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by louis on 12/03/17.
 * A utility regex class for rudimentary regex checking such as email patterns and passwords
 */

public class RegexCheckUtils {

    /**
     *
     * @param emailField
     * @param checkEmail
     * @param context
     * @return
     */
    public static boolean checkEmail(EditText emailField, View checkEmail, Context context){
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        Pattern pattern = Pattern.compile(EMAIL_PATTERN);

        if(validate(emailField.getText().toString(), pattern)) {
            restoreTextField(emailField);
            return true;
        }
        else{
            if(checkEmail != null)
                checkEmail.setVisibility(View.GONE);

            Toast.makeText(context, "Failure, check your email ;)",
                    Toast.LENGTH_LONG).show();
            highlightField(emailField);
            return false;
        }
    }

    /**
     Whole combination is means, 6 to 20 characters string with at least one digit,
     one upper case letter, one lower case letter.
     */
    public static boolean checkPassword(EditText passwordField, EditText confirmPasswordField) {

        final String PASSWORD_PATTERN = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{6,20})";
        Pattern pattern = Pattern.compile(PASSWORD_PATTERN);

        String password = passwordField.getText().toString();
        if(validate(password, pattern) && password.equals(confirmPasswordField.getText().toString())){
            return true;
        }else{
            highlightField(passwordField);
            highlightField(confirmPasswordField);
            return false;
        }
    }

    public static boolean checkField(EditText editText, boolean highlights) {
        String toCheck = editText.getText().toString();
        if (!toCheck.isEmpty() && toCheck!=null ){
            if(highlights)
                RegexCheckUtils.restoreTextField(editText);
            return true;
        }else{
            if(highlights)
                RegexCheckUtils.highlightField(editText);
            return false;
        }
    }

    /**
     *
     * @param hex
     * @param pattern
     * @return
     */
    private static boolean validate(final String hex, Pattern pattern) {
        Matcher matcher = pattern.matcher(hex);
        return matcher.matches();
    }

    /**
     *
     * @param editText
     */
    public static void highlightField(EditText editText) {
        editText.setTextColor(0xffff0000);
    }

    /**
     *
     * @param editText
     */
    public static void restoreTextField(EditText editText){
        editText.setTextColor(0xffffffff);
    }

}
