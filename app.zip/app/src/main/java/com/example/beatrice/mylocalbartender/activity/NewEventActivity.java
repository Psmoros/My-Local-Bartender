package com.example.beatrice.mylocalbartender.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.controller.ProfilePicManager;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.model.Event;
import com.example.beatrice.mylocalbartender.model.Organiser;
import com.example.beatrice.mylocalbartender.utils.Colours;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This is the class that one uses when wanting to create an activity
 */

public class NewEventActivity extends AppCompatActivity {

    private Button button;
    private ImageButton eventImageButton;
    private EditText eventTitle, location, date, startTime, endTime, jobDescription;
    private String eventName, postCode, eventDate, startJob, endJob, description, shiftRate;
    private int requiredBartenders;
    private boolean isDayEvent = false; // todo add isDayEvent;
    private FirebaseStorage storage = FirebaseStorage.getInstance();
    private StorageReference storageRef = storage.getReference();
    private StorageReference eventPicRef = storageRef.child("EventPics");
    private static DatabaseReference root = FirebaseDatabase.getInstance().getReference();
    private Event event;
    private boolean isPublicEvent = true;
    private Button publicEventButton, cancelEventButton;
    private EditText approximateValue;
    private EditText requiredBartenderText;
    private LinearLayout layout4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (savedInstanceState != null) {
            isPublicEvent = (boolean) savedInstanceState.get("isPublicEvent");
        }
        setContentView(R.layout.activity_new_event);
        eventTitle = (EditText) findViewById(R.id.evnet_name_edit_text);
        location = (EditText) findViewById(R.id.location);
        date = (EditText) findViewById(R.id.date);
        startTime = (EditText) findViewById(R.id.start_time);
        endTime = (EditText) findViewById(R.id.end_time);
        jobDescription = (EditText) findViewById(R.id.edit_text_event_description);
        eventImageButton = (ImageButton) findViewById(R.id.event_image_button);
        publicEventButton = (Button) findViewById(R.id.public_event_button);
        approximateValue = (EditText) findViewById(R.id.rate_edit_text);
        requiredBartenderText = (EditText) findViewById(R.id.number_of_bartender_edit_text);
        cancelEventButton = (Button) findViewById(R.id.cancel_event_button);
        layout4 = (LinearLayout) findViewById(R.id.new_event_layout);

        if(Colours.isDefault == false) {
            layout4.setBackgroundColor(Color.parseColor(Colours.backgroundColour));
        }

        publicEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isPublicEvent) {

                    isPublicEvent = false;
                    publicEventButton.setText("PRIVATE EVENT");

                } else {
                    isPublicEvent = true;
                    publicEventButton.setText("PUBLIC EVENT");
                }


            }
        });


        //// TODO: 21/03/2017 Handle the private public event button 
        eventImageButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                ProfilePicManager.onSelectImageClick(NewEventActivity.this, eventImageButton, false);

            }
        });


        button = (Button) findViewById(R.id.done_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: 10/03/2017 Get location, day, shiftrate, date
                shiftRate = approximateValue.getText().toString();
                eventName = eventTitle.getText().toString();
                postCode = location.getText().toString();
                eventDate = date.getText().toString();
                startJob = startTime.getText().toString();
                endJob = endTime.getText().toString();
                description = jobDescription.getText().toString();

                if(!requiredBartenderText.getText().toString().equals("")) {

                    requiredBartenders = Integer.valueOf(requiredBartenderText.getText().toString());

                }else{
                    Toast.makeText(NewEventActivity.this, "Please complete all fields",
                            Toast.LENGTH_LONG).show();
                    return;
                }

                if (validInput()) {
                    event = createEvent();
                    if (!checkDefaultProfilePicture()) {
                        ProfilePicManager.uploadPicToStorage(
                                eventPicRef,
                                eventImageButton,
                                event.getEvent_id(),
                                root.child("Events").child(event.getEvent_id()));
                    }

                    Intent intent = new Intent(NewEventActivity.this, MainNavigationActivity.class);
                    startActivity(intent);
                    Toast.makeText(NewEventActivity.this, "Event created !",
                            Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(NewEventActivity.this, "Please complete all fields",
                            Toast.LENGTH_LONG).show();
                }

            }
        });

        cancelEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NewEventActivity.this, MainNavigationActivity.class);
                startActivity(intent);
            }
        });
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean("isPublicEvent", isPublicEvent);
    }

    private Event createEvent() {

        Organiser organiser = (Organiser) FirebaseManagement.getInstance().currentUser;
        return organiser.createEvent(requiredBartenders,
                isDayEvent,
                isPublicEvent, this, eventName,
                description,
                location.getText().toString(),
                date.getText().toString(),
                startJob,
                endJob,shiftRate);

    }

    private boolean validInput() {
        if (checkTitle() && checkDate() && checkTime() &&
                checkDescription() && checkShiftRate() && checkRequiredBartenders()) {
            return true;
        }
        return false;

    }

    private boolean checkDescription() {
        if (description.isEmpty()) {
            highlightField(jobDescription);
            return false;
        }
        return true;

    }

    private boolean checkShiftRate() {

        if (shiftRate.isEmpty()) {
            highlightField(approximateValue);
            return false;
        }

        return true;
    }

    private boolean checkRequiredBartenders() {

        if (requiredBartenders <= 0) {
            highlightField(requiredBartenderText);
            return false;
        }
        return true;

    }


    private boolean checkTime() {
        final String TIME_PATTERN = "^([01]\\d|2[0-3]):?([0-5]\\d)$";
        boolean start, finish;
        Pattern pattern = Pattern.compile(TIME_PATTERN);

        if (validate(startJob, pattern)) {
            start = true;
        } else {
            highlightField(startTime);
            start = false;
        }
        if (validate(endJob, pattern)) {
            finish = true;
        } else {
            highlightField(endTime);
            finish = false;
        }
        if (start && finish) {
            return true;
        } else {
            return false;
        }

    }

    private boolean checkDate() {
        final String DATE_PATTERN = "^\\d{1,2}/\\d{1,2}/\\d{4}$";
        Pattern pattern = Pattern.compile(DATE_PATTERN);

        if (validate(eventDate, pattern)) {
            return true;
        } else {
            highlightField(date);
            return false;
        }
    }

    private boolean checkTitle() {
        if (!eventName.isEmpty()) {
            return true;
        } else {
            highlightField(eventTitle);
            return false;
        }
    }

    private boolean validate(final String hex, Pattern pattern) {
        Matcher matcher = pattern.matcher(hex);
        return matcher.matches();
    }

    private void highlightField(EditText editText) {
        editText.setTextColor(0xffff0000);
    }

    private boolean checkDefaultProfilePicture() {

        Bitmap b1 = ((BitmapDrawable) (eventImageButton.getBackground())).getBitmap();
        Bitmap b2 = ((BitmapDrawable) getResources().getDrawable(R.drawable.event_pic_icon)).getBitmap();

        if (b1.sameAs(b2)) {
            return true;
        }

        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        ProfilePicManager.activityResult(requestCode,resultCode,data);
    }

}
