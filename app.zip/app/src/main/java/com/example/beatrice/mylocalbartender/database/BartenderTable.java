package com.example.beatrice.mylocalbartender.database;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

/**
 * The Java class representation of the SQLite table 'job'.
 */
public class BartenderTable {
    //Database Table User
    public static final String TABLE_BARTENDER = "bartender";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_FIRST_NAME = "firstName";
    public static final String COLUMN_LAST_NAME = "lastName";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_GENDER = "gender";
    public static final String COLUMN_PHONE = "phoneNumber";
    public static final String COLUMN_LOCATION = "location";
    public static final String COLUMN_DOB = "dob";
    public static final String COLUMN_USER_TYPE = "userType";
    public static final String COLUMN_PICTURE = "picture";
    public static final String COLUMN_BARTENDER_EXPERIENCE = "barExperience";
    public static final String COLUMN_SPECIALITY = "speciality";
    public static final String COLUMN_NIGHTLY_RATE = "nightlyRate";
    public static final String COLUMN_HOURLY_RATE = "hourlyRate";


    private static final String DATABASE_CREATE =
            "create table "
                    + TABLE_BARTENDER
                    + "("
                    + COLUMN_ID + " TEXT PRIMARY KEY, "
                    + COLUMN_FIRST_NAME + " TEXT NOT NULL, "
                    + COLUMN_LAST_NAME + " TEXT NOT NULL, "
                    + COLUMN_EMAIL + " TEXT NOT NULL, "
                    + COLUMN_GENDER + " TEXT, "
                    + COLUMN_PHONE + " TEXT, "
                    + COLUMN_LOCATION + " TEXT, "
                    + COLUMN_DOB + " TEXT, "
                    + COLUMN_USER_TYPE + " TEXT, "
                    + COLUMN_PICTURE + " TEXT, "
                    + COLUMN_BARTENDER_EXPERIENCE + " TEXT, "
                    + COLUMN_SPECIALITY + " TEXT, "
                    + COLUMN_NIGHTLY_RATE + " TEXT, "
                    + COLUMN_HOURLY_RATE + " TEXT "
                    + ");";

    /**
     * Called when the database is created for the first time. This is where the
     * creation of tables and the initial population of the tables happens.
     *
     * @param database The SQLite database.
     */
    public static void onCreate(SQLiteDatabase database) {
        database.execSQL(DATABASE_CREATE);

    }

    /**
     * Called when the database needs to be upgraded. The implementation
     * should use this method to drop tables, add tables, or do anything else it
     * needs to upgrade to the new schema version.
     *
     * @param database The SQLite database.
     * @param oldVersion The old database version.
     * @param newVersion The new database version.
     */
    public static void onUpgrade(SQLiteDatabase database, int oldVersion,
                                 int newVersion) {
        Log.w(BartenderTable.class.getName(), "Upgrading database from version "
                + oldVersion + " to " + newVersion
                + ", which will destroy all old data");
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_BARTENDER);
        onCreate(database);
    }
}
