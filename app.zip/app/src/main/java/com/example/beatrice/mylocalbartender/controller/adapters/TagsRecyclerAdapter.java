package com.example.beatrice.mylocalbartender.controller.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.controller.interfaces.NotifyInterface;
import com.example.beatrice.mylocalbartender.controller.interfaces.ResultsInterface;
import com.example.beatrice.mylocalbartender.model.Tag;

import java.util.ArrayList;

/**
 * Created by Umar on 04/03/2017.
 * This class is RecyclerAdapter for Tag objects that will be retrieved from Firebase
 *
 *
 */

public class TagsRecyclerAdapter extends RecyclerView.Adapter implements ResultsInterface<Tag> {

    private ArrayList<Tag> tags;
    private NotifyInterface notifyInterface;

    public TagsRecyclerAdapter(ArrayList<Tag> tags, NotifyInterface notifyInterface) {
        super();
        this.tags = tags;
        this.notifyInterface = notifyInterface;
    }

    @Override
    public void addToList(Tag tag) {

        tags.add(tag);
        notifyDataSetChanged();

    }

    @Override
    public void notifyEmptyDataSet() {

    }

    @Override
    public void notifyDataChanged(Tag tag) {

    }

    @Override
    public void removeFromList(Tag tag) {

    }

    public void replaceList(ArrayList<Tag> newTags){

        this.tags = newTags;
        notifyDataSetChanged();

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.tag_layout,null,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {


        ViewHolder viewHolder = (ViewHolder) holder;

        viewHolder.bindData(tags.get(position));



    }

    @Override
    public int getItemCount() {
        return tags.size();
    }



    private class ViewHolder extends RecyclerView.ViewHolder {


        private TextView tagsTitle;
        private TextView tagsDescription;
        private CheckBox checkBox;


        public ViewHolder(View itemView) {

            super(itemView);

            tagsTitle = (TextView) itemView.findViewById(R.id.tag_title);
            checkBox = (CheckBox) itemView.findViewById(R.id.select_tag);

            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                    if(isChecked){


                        notifyInterface.incomingTag(getAdapterPosition(),tags.get(getAdapterPosition()));

                    }else{

                        notifyInterface.removeTag(getAdapterPosition());


                    }


                }
            });
        }


        public void bindData(Tag tag) {

            tagsTitle.setText(tag.getName());

            //tagsPopularty.setText(tag.getPopularity());

        }
    }



}
