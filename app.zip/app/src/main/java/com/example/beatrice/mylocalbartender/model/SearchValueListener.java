package com.example.beatrice.mylocalbartender.model;

import com.example.beatrice.mylocalbartender.controller.interfaces.ResultsInterface;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

/**
 * Created by louis on 12/03/17.
 * This class filters out the location {@link SearchGeoListener} results event further by filtering
 * the bartender or the event
 */

public /**
 * To Retrieve the objects depending on their type
 */
class SearchValueListener implements ValueEventListener {

    private String speciality;

    private ResultsInterface<User> searchQueryInterface;

    SearchValueListener(String speciality,
                        ResultsInterface searchQueryInterface) {

        this.speciality = speciality;
        this.searchQueryInterface = searchQueryInterface;

    }

    @Override
    public void onDataChange(DataSnapshot dataSnapshot) {

        if (dataSnapshot.getValue() != null) {

                Bartender barTenderFound = dataSnapshot.getValue(Bartender.class);
                if (speciality != null) {
                    if (barTenderFound.getSpecialities().contains(speciality)) {
                        searchQueryInterface.addToList(barTenderFound);
                    }
                } else {
                    if (!barTenderFound.isProfileHidden()) {
                        if (speciality != null) {
                            if (barTenderFound.getSpecialities().contains(speciality)) {
                                searchQueryInterface.addToList(barTenderFound);
                            }
                        } else {
                            searchQueryInterface.addToList(barTenderFound);

                        }
                    }
                }
        }

    }


    @Override
    public void onCancelled(DatabaseError databaseError) {

    }


}
