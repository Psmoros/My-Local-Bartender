package com.example.beatrice.mylocalbartender.model;

import java.io.Serializable;

/**
 * Enum representing a UserType of MLB app
 */

public enum UserType implements Serializable
{
    BARTENDER,
    ORGANISER;

    @Override
    public String toString() {
        switch(this) {
            case BARTENDER: return "BARTENDER";
            case ORGANISER: return "ORGANISER";
            default: return "user unknown";
        }
    }
}