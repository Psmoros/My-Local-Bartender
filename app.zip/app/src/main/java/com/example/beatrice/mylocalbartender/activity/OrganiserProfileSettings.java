package com.example.beatrice.mylocalbartender.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.controller.ProfilePicManager;
import com.example.beatrice.mylocalbartender.database.DBCallback;
import com.example.beatrice.mylocalbartender.database.DBReader;
import com.example.beatrice.mylocalbartender.database.DBWriter;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.model.Organiser;
import com.example.beatrice.mylocalbartender.utils.Colours;
import com.example.beatrice.mylocalbartender.utils.RegexCheckUtils;
import com.example.beatrice.mylocalbartender.utils.alertDialog.GeneralDialogFragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

/**
 * This is the class that allows an organiser to change his/her personal details
 */
public class OrganiserProfileSettings extends AppCompatActivity  implements GeneralDialogFragment.OnDialogFragmentClickListener {

    private View changePasswordButton, maleButton, femaleButton, maleSelected, femaleSelected, checkEmail, sign_out, save, done_button, delete_account;

    private EditText lastNameField, emailField, phoneField, dobField, firstNameField, professionalPosition;

    private ImageButton profilPic;

    private String gender;

    private Button colourButton1, colourButton2, colourButton3, colourButton4, colourButton5, colourButton6, colourButton7, colourButton8, colourButton9, colourButton10;
    private CoordinatorLayout layout1;

    private boolean loggedInViaFB = false;

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference root = database.getReference();
    private FirebaseManagement firebaseManagement = FirebaseManagement.getInstance();
    private FirebaseUser user;
    private FirebaseAuth auth;
    private FirebaseStorage storage = FirebaseStorage.getInstance();
    private StorageReference storageRef = storage.getReference();
    private StorageReference profilePicRef = storageRef.child("ProfilePictures");


    private Organiser organiser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_organiser_profile_settings);
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();

        //Getting the different views from Resources
        delete_account = (Button) findViewById(R.id.delete_account_button);
        done_button = (Button) findViewById(R.id.done_button);
        sign_out = (ImageButton) findViewById(R.id.sign_out_image_button);
        professionalPosition = (EditText) findViewById(R.id.edit_text_professional_position);
        checkEmail = (ImageView) findViewById(R.id.check_email);
        changePasswordButton = (Button) findViewById(R.id.change_password_button);
        firstNameField = (EditText) findViewById(R.id.edit_text_firstName);
        femaleButton = (Button) findViewById(R.id.female_button);
        maleSelected = (ImageView) findViewById(R.id.male_selected);
        femaleSelected = (ImageView) findViewById(R.id.female_selected);
        maleButton = (Button) findViewById(R.id.male_button);
        lastNameField = (EditText) findViewById(R.id.edit_text_lastName);
        emailField = (EditText) findViewById(R.id.edit_text_email);
        phoneField = (EditText) findViewById(R.id.edit_text_phone);
        dobField = (EditText) findViewById(R.id.edit_text_dob);
        save = (Button) findViewById(R.id.save_button);
        profilPic = (ImageButton) findViewById(R.id.profile_settings_profile_picture_button);

        colourButton1 = (Button) findViewById(R.id.button1);
        colourButton2 = (Button) findViewById(R.id.button2);
        colourButton3 = (Button) findViewById(R.id.button3);
        colourButton4 = (Button) findViewById(R.id.button4);
        colourButton5 = (Button) findViewById(R.id.button5);
        colourButton6 = (Button) findViewById(R.id.button6);
        colourButton7 = (Button) findViewById(R.id.button7);
        colourButton8 = (Button) findViewById(R.id.button8);
        colourButton9 = (Button) findViewById(R.id.button9);
        colourButton10 = (Button) findViewById(R.id.button10);

        layout1 = (CoordinatorLayout) findViewById(R.id.organiser_profile_settings_layout);
        if(Colours.isDefault == false) {
            layout1.setBackgroundColor(Color.parseColor(Colours.backgroundColour));
        }

        colourButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#263238"));
                Colours.backgroundColour = "#263238";
                Colours.isDefault = false;
            }
        });
        colourButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#455A64"));
                Colours.backgroundColour = "#455A64";
                Colours.isDefault = false;

            }
        });
        colourButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#4c4c4c"));
                Colours.backgroundColour = "#4c4c4c";
                Colours.isDefault = false;
            }
        });
        colourButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#424242"));
                Colours.backgroundColour = "#424242";
                Colours.isDefault = false;
            }
        });
        colourButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#37474F"));
                Colours.backgroundColour = "#37474F";
                Colours.isDefault = false;
            }
        });
        colourButton6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#323232"));
                Colours.backgroundColour = "#323232";
                Colours.isDefault = false;
            }
        });
        colourButton7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#2f3f4f"));
                Colours.backgroundColour = "#2f3f4f";
                Colours.isDefault = false;
            }
        });
        colourButton8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#212121"));
                Colours.backgroundColour = "#212121";
                Colours.isDefault = false;
            }
        });
        colourButton9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#004d66"));
                Colours.backgroundColour = "#004d66";
                Colours.isDefault = false;
            }
        });
        colourButton10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout1.setBackgroundColor(Color.parseColor("#00394d"));
                Colours.backgroundColour = "#00394d";
                Colours.isDefault = false;
            }
        });


        final Animation fadeInAnimation = AnimationUtils.loadAnimation(this, R.anim.fade_in);

        organiser = (Organiser) firebaseManagement.currentUser;

        if (firebaseManagement.loggedInViaFB()) {
            loggedInViaFB = true;
            hideFields();
        }

        displayInfoFromLocalDB();


        //Start changePassword alertDialog when clicking on this button
        changePasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showChangePasswordAlertDialog();
            }
        });

        //Start deleteAccount alertDialog
        delete_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteAccountAlertDialog();
            }
        });

        //settings listeners on click events and update the gender of the user
        maleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gender = "male";
                femaleSelected.clearAnimation();
                femaleSelected.setSystemUiVisibility(View.INVISIBLE);
                femaleSelected.setVisibility(View.INVISIBLE);
                maleSelected.startAnimation(fadeInAnimation);
                maleSelected.setVisibility(View.VISIBLE);
                if (checkDefaultProfilePicture()) {
                    profilPic.setBackground(getResources().getDrawable(R.drawable.profile_icon_male));
                }
            }
        });

        femaleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gender = "female";
                maleSelected.clearAnimation();
                maleSelected.setSystemUiVisibility(View.INVISIBLE);
                maleSelected.setVisibility(View.INVISIBLE);
                femaleSelected.startAnimation(fadeInAnimation);
                femaleSelected.setVisibility(View.VISIBLE);
                if (checkDefaultProfilePicture()) {
                    profilPic.setBackground(getResources().getDrawable(R.drawable.profile_icon_female));
                }
            }
        });


        done_button.setOnClickListener(new View.OnClickListener() { //TODO
            @Override
            public void onClick(View v) {
                if (!loggedInViaFB) {
                    if (RegexCheckUtils.checkEmail(emailField, checkEmail, OrganiserProfileSettings.this)) {
                        updateInfo();
                    }
                } else {
                    updateInfo();
                }
                Intent intent = new Intent(OrganiserProfileSettings.this, MainNavigationActivity.class);
                startActivity(intent);
            }
        });

        //Button to sign_out
        sign_out.setOnClickListener(new View.OnClickListener() { //TODO
            @Override
            public void onClick(View v) {
                showLogOutDialog();
            }
        });


        //Button to save all the fields in the DB
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!loggedInViaFB) {
                    if (RegexCheckUtils.checkEmail(emailField, checkEmail, OrganiserProfileSettings.this)) {
                        updateInfo();
                    }
                } else {
                    updateInfo();
                }
            }
        });


        //Button to change profile Pic
        profilPic.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                ProfilePicManager.onSelectImageClick(OrganiserProfileSettings.this, profilPic, true);

            }
        });

        collapseListener();
    }

    private void displayInfoFromLocalDB(){

        final Organiser[] organisers = new Organiser[1];

        new DBReader(getApplicationContext()).execute(new Organiser(), organiser.getUid(), new DBCallback() {
            @Override
            public void callBack(Object object) {
                organisers[0] = (Organiser) object;
                setFields(organisers[0]);
            }
        });

    }

    private void displayInfoFromDB(){

        setFields(organiser);

    }


    //display the info, fetched from DB
    private void setFields(Organiser organiser){

        setText(firstNameField, organiser.getFirstName());

        setText(lastNameField, organiser.getLastName());

        setText(emailField, organiser.getEmail());

        if (RegexCheckUtils.checkEmail(emailField, checkEmail, this)) {
            checkEmail.setVisibility(View.VISIBLE);
        }

        setText(phoneField, organiser.getPhone());

        setText(dobField, organiser.getDoB());

        setText(professionalPosition, organiser.getProfessionalPosition());


        if (organiser.getGender() != null && !organiser.getGender().isEmpty()) {
            if (organiser.getGender().equals("male")) {
                gender = "male";
                maleSelected.setVisibility(View.VISIBLE);

            } else {
                gender = "female";
                femaleSelected.setVisibility(View.VISIBLE);
            }
        }

        if(organiser.getBgColorPref()!=null && !organiser.getBgColorPref().isEmpty() && !organiser.getBgColorPref().equals(" ")) {
            Colours.backgroundColour = organiser.getBgColorPref();
            layout1.setBackgroundColor(Color.parseColor(organiser.getBgColorPref()));
            Colours.isDefault = false;
        }

        ProfilePicManager.loadProfilePicFromStorage(profilPic, this, organiser.getUid(), true, profilePicRef);

    }

    //update/save the info entered in editTexts to DB
    private void updateInfo() {

        if (!checkDefaultProfilePicture()) {
            ProfilePicManager.uploadPicToStorage(profilePicRef, profilPic, user.getUid(), root.child("Users").child(organiser.getUid()));
        }
        checkEmail.setVisibility(View.VISIBLE);

        if (RegexCheckUtils.checkField(firstNameField, false))
            organiser.setFirstName(firstNameField.getText().toString());

        if (RegexCheckUtils.checkField(lastNameField, false))
            organiser.setLastName(lastNameField.getText().toString());

        organiser.setProfessionalPosition(professionalPosition.getText().toString());

        organiser.setEmail(emailField.getText().toString());


        organiser.setPhone(phoneField.getText().toString());

        organiser.setDoB(dobField.getText().toString());

        if (gender != null && !gender.isEmpty()) {
            organiser.setGender(gender);
        }

        organiser.setBgColorPref(Colours.backgroundColour);


            try{
                new DBWriter(getApplicationContext()).execute(organiser,new DBCallback() {
                    @Override
                    public void callBack(Object object) {
                        Log.v("db_written", object.toString());
                    }
                });
            }catch (Exception e){
                Log.v("db_write", e.getMessage());
            }

            firebaseManagement.setValue(organiser, "Users", organiser.getUid());

        Toast.makeText(OrganiserProfileSettings.this, "Profile Updated !",
                Toast.LENGTH_LONG).show();


    }

    //Set text of an field
    private void setText(EditText editText, String text) {
        if (text != null) {
            if (!text.isEmpty()) {
                editText.setText(text);
            }
        }
    }

    private boolean checkDefaultProfilePicture() {
        Bitmap b1 = ((BitmapDrawable) (profilPic.getBackground())).getBitmap();
        Bitmap b2 = ((BitmapDrawable) getResources().getDrawable(R.drawable.profile_icon_male)).getBitmap();
        Bitmap b3 = ((BitmapDrawable) getResources().getDrawable(R.drawable.profile_icon_female)).getBitmap();
        Bitmap b4 = ((BitmapDrawable) getResources().getDrawable(R.drawable.ic_profile_default)).getBitmap();

        if (b1.sameAs(b2) || b1.sameAs(b3) || b1.sameAs(b4)) {
            return true;
        }

        return false;
    }


    private void showChangePasswordAlertDialog() {
        GeneralDialogFragment changePasswordDialogFragment = GeneralDialogFragment.newInstance("Change password", "Are you sure you want to change your password ?", "No", "Yes");
        changePasswordDialogFragment.show(getSupportFragmentManager(), "dialog");
    }

    private void showLogOutDialog() {
        GeneralDialogFragment setUserDialogFragment = GeneralDialogFragment.newInstance("Logging out", "Do you want to log out ?", "No", "Yes");
        setUserDialogFragment.show(getSupportFragmentManager(), "dialog");
    }

    private void showDeleteAccountAlertDialog() {

        GeneralDialogFragment deleteAccountDialogFragment = GeneralDialogFragment.newInstance("Delete account", "We are sad to see you leave ... \n Are you sure, You want to delete your account ?", "No", "Yes");
        deleteAccountDialogFragment.show(getSupportFragmentManager(), "dialog");

    }

    @Override
    public void onAlertDialogLeftClicked(GeneralDialogFragment dialog) {
        dialog.dismiss();
    }

    @Override
    public void onAlertDialogRightClicked(GeneralDialogFragment dialog) {
        if (dialog.getArguments().getString("title").equals("Change password")) {
            auth.sendPasswordResetEmail(user.getEmail())
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Log.d("RESET PASSWORD", "Email sent.");
                                Toast.makeText(OrganiserProfileSettings.this, "An email has been sent to " + user.getEmail() + " to change your password",
                                        Toast.LENGTH_LONG).show();
                            }
                        }
                    });

            dialog.dismiss();

        } else if (dialog.getArguments().getString("title").equals("Logging out")) {
            FirebaseManagement.getInstance().currentUser = null;
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(OrganiserProfileSettings.this, LoginActivity1.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            dialog.dismiss();
            startActivity(intent);
            finish();
        } else {
            user.delete() //TODO
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Log.d("Account deleted", "deleted");
                                Toast.makeText(OrganiserProfileSettings.this, "Account deleted",
                                        Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(OrganiserProfileSettings.this, LoginActivity1.class);
                                startActivity(intent);
                            }
                        }
                    });

            dialog.dismiss();

        }
    }

    private void hideFields() {

        TextView emailTextView = (TextView) findViewById(R.id.email_text_view);
        emailTextView.setVisibility(View.GONE);

        ImageView emailDivider = (ImageView) findViewById(R.id.email_divider);
        emailDivider.setVisibility(View.GONE);

        ImageView passwordDivider = (ImageView) findViewById(R.id.password_divider);
        passwordDivider.setVisibility(View.GONE);

        ImageView passwordIcon = (ImageView) findViewById(R.id.password_icon);
        passwordIcon.setVisibility(View.GONE);

        ImageView emailIcon = (ImageView) findViewById(R.id.email_icon);
        emailIcon.setVisibility(View.GONE);

        changePasswordButton.setVisibility(View.GONE);

        emailField.setVisibility(View.GONE);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        ProfilePicManager.activityResult(requestCode, resultCode, data);
    }


    public void collapseListener() {


        AppBarLayout appBarLayout = (AppBarLayout) findViewById(R.id.app_bar_layout_for_profile);


        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {

                if (Math.abs(verticalOffset) - appBarLayout.getTotalScrollRange() == 0) {
                    profilPic.setVisibility(View.INVISIBLE);


                } else {

                    profilPic.setVisibility(View.VISIBLE);

                }
            }
        });


    }

}
