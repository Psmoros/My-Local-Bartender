package com.example.beatrice.mylocalbartender.activity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.example.beatrice.mylocalbartender.database.DBCallback;
import com.example.beatrice.mylocalbartender.database.DBReader;
import com.example.beatrice.mylocalbartender.database.DBWriter;
import com.example.beatrice.mylocalbartender.utils.alertDialog.GeneralDialogFragment;
import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.firebase.Callback;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.model.UserType;
import com.example.beatrice.mylocalbartender.utils.alertDialog.GeneralDialogFragment;
import com.example.beatrice.mylocalbartender.utils.mutedVideoView.MutedVideoView;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

/**
 * The Launcher Activity for MLB
 * @author Team Astra@kcl.ac.uk
 * TODO 19/2/17 onClickListener for both Google_sign_in and Facebook_sign_in buttons.
 */
public class LoginActivity1 extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener, View.OnClickListener, GeneralDialogFragment.OnDialogFragmentClickListener {

    private MutedVideoView mVideoView;


    //launches Registering1 Activity
    private Button registerUser;

    private FirebaseManagement firebaseManagement = FirebaseManagement.getInstance();

    private Button signInEmail;

    private CallbackManager callbackManager;
    private LoginButton loginButton;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FacebookSdk.sdkInitialize(getApplicationContext());

        setContentView(R.layout.activity_login1);

        addVideo();

        registerUser = (Button) findViewById(R.id.registerUser);
        registerUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity1.this, Registering1.class);
                startActivity(intent);
            }
        });

        signInEmail = (Button) findViewById(R.id.sign_in_Email);
        signInEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLogInPopUp();
            }
        });

        // setting the onclick listener for the overlay facebook button
        findViewById(R.id.facebook_signin).setOnClickListener(this);

        // setting the click listener for the google button
        findViewById(R.id.sign_in_google).setOnClickListener(this);

        callbackManager  = CallbackManager.Factory.create();
        loginButton = (LoginButton) findViewById(R.id.actual_facebook_button);
        loginButton.setReadPermissions("email","public_profile");
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {

                FirebaseManagement.getInstance().onResultFacebook(loginResult.getAccessToken(), LoginActivity1.this, new Callback() {
                    @Override
                    public void loginSuccessful() {

                        firebaseManagement.instantiateLocalDB(getApplicationContext());

                        Intent intent = new Intent(LoginActivity1.this, MainNavigationActivity.class);
                        startActivity(intent);

                    }

                    @Override
                    public void loginFailed() {

                        GeneralDialogFragment setUserDialogFragment = GeneralDialogFragment.newInstance("Who are you ?", "Are you a bartender or an Organiser ?", "Bartender", "Organiser");
                        setUserDialogFragment.show(getSupportFragmentManager(),"dialog");

                    }
                });
            }



            @Override
            public void onCancel() {

                Toast.makeText(LoginActivity1.this,"Error",Toast.LENGTH_LONG).show();
            }

            @Override
            public void onError(FacebookException error) {

                Toast.makeText(LoginActivity1.this,"Error",Toast.LENGTH_LONG).show();

            }


        });


    }

    @Override
    protected void onResume() {
        super.onResume();
        addVideo();
    }

    private void addVideo(){
        mVideoView = (MutedVideoView) findViewById(R.id.bgvideoView);
        Uri video_uri = Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.video_background);

        mVideoView.setVideoURI(video_uri);
        mVideoView.start();

        mVideoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
            mediaPlayer.setLooping(true);
            }
        });
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode,resultCode,data);


        FirebaseManagement.getInstance().onResult(this, requestCode, data, new Callback() {
            @Override
            public void loginSuccessful() {

                firebaseManagement.instantiateLocalDB(getApplicationContext());

                Intent intent = new Intent(LoginActivity1.this, MainNavigationActivity.class);
                startActivity(intent);
            }

            @Override
            public void loginFailed() {

                GeneralDialogFragment setUserDialogFragment = GeneralDialogFragment.newInstance("Who are you ?", "Are you a bartender or an Organiser ?", "Bartender", "Organiser");
                setUserDialogFragment.show(getSupportFragmentManager(),"dialog");
            }
        });

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.facebook_signin){
            loginButton.performClick();
            return;
        }
        if(v.getId() == R.id.sign_in_google){
            setSignInWithGoogle();
            return;
        }
    }


    private void setSignInWithGoogle() {

        FirebaseManagement.getInstance().signInWithGoogle(this, this, FirebaseManagement.SIGN_IN_GMAIL);

    }

    @Override
    public void onAlertDialogLeftClicked(GeneralDialogFragment dialog) {
        createNewUserInDB(UserType.BARTENDER);
    }

    @Override
    public void onAlertDialogRightClicked(GeneralDialogFragment dialog) {
        createNewUserInDB(UserType.ORGANISER);
    }

    private void createNewUserInDB(UserType userType){
        firebaseManagement.createNewUserInDB(userType, FirebaseAuth.getInstance().getCurrentUser().getEmail(), new Callback() {
            @Override
            public void loginSuccessful() {

                firebaseManagement.instantiateLocalDB(getApplicationContext());

                Intent intent = new Intent(LoginActivity1.this, MainNavigationActivity.class);
                startActivity(intent);

            }

            @Override
            public void loginFailed() {
                Toast.makeText(LoginActivity1.this, "Login failed",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void showLogInPopUp(){
        LayoutInflater inflater = (LayoutInflater) getBaseContext().getSystemService(LAYOUT_INFLATER_SERVICE);

        // Inflate the custom layout/view
        final View loginPopUp = inflater.inflate(R.layout.sign_in_popup, null, false);

        // Initialize a new instance of popup window
        final PopupWindow mPopupWindow = new PopupWindow(loginPopUp, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        mPopupWindow.setFocusable(true);
        mPopupWindow.update();
        mPopupWindow.setOutsideTouchable(true);
        WindowManager.LayoutParams windowManager = getWindow().getAttributes();
        mPopupWindow.setAnimationStyle(R.style.FadeAnimation);
        windowManager.dimAmount = 0.5f;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mPopupWindow.setElevation(10);
        }


        // Set an elevation value for popup window
        // Call requires API level 21
        if(Build.VERSION.SDK_INT>=21){
            mPopupWindow.setElevation(5.0f);
        }

        Button signInButton = (Button) loginPopUp.findViewById(R.id.sign_in);
        final EditText emailField= (EditText) loginPopUp.findViewById(R.id.emailField);
        final EditText passwordField= (EditText) loginPopUp.findViewById(R.id.PasswordField);
        ImageButton exitButton = (ImageButton) loginPopUp.findViewById(R.id.exit_popup_button);

        mPopupWindow.showAtLocation(loginPopUp, Gravity.CENTER, 0, 0);


        // Set a click listener for the popup window close button
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Dismiss the popup window
                mPopupWindow.dismiss();
                WindowManager.LayoutParams windowManager = getWindow().getAttributes();
                windowManager.dimAmount = 0;
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            }
        });

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailField.getText().toString();
                String password = passwordField.getText().toString();
                if(!(email == null || password == null || email.isEmpty() || password.isEmpty())) {
                    FirebaseManagement.getInstance().signInWithEmail(email, password, new Callback() {
                        @Override
                        public void loginSuccessful() {
                            Log.v("LoginActivity1", "Login successful");

                            firebaseManagement.instantiateLocalDB(getApplicationContext());

                            Intent intent = new Intent(LoginActivity1.this, MainNavigationActivity.class);
                            startActivity(intent);
                            mPopupWindow.dismiss();
                        }

                        @Override
                        public void loginFailed() {
                            Log.v("LoginActivity1", "Login fail");
                            Toast.makeText(LoginActivity1.this, "Check your email (registered ?) or your password (Must contain a Cap and a number)",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
                else{
                    Toast.makeText(LoginActivity1.this, "Please, check your input",
                            Toast.LENGTH_LONG).show();
                }
            }
        });



    }

}
