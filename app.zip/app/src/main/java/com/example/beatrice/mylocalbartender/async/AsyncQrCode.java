package com.example.beatrice.mylocalbartender.async;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import com.example.beatrice.mylocalbartender.activity.MainNavigationActivity;
import com.google.firebase.database.FirebaseDatabase;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.NameValuePair;
import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.client.entity.UrlEncodedFormEntity;
import cz.msebera.android.httpclient.client.methods.HttpPost;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;
import cz.msebera.android.httpclient.message.BasicNameValuePair;

/**
 * Created by bea on 15/03/2017.
 * Sends the qr code information scanned to the server for processing
 */

public class AsyncQrCode extends AsyncTask<String, String, String> {

    private Activity activity;
    private String job;
    private String organiserId;
    private String bartnderId;

    public AsyncQrCode(Activity activity, String job_id, String bartenderId, String organiserId) {
        super();
        this.activity = activity;
        this.job = job_id;
        this.bartnderId = bartenderId;
        this.organiserId = organiserId;
    }

    @Override
    protected String doInBackground(String... params) {
        StringBuilder sb=null;
        try {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://mlb-server.herokuapp.com/payment");

            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);
            nameValuePairs.add(new BasicNameValuePair("bartenderId", params[0]));
            nameValuePairs.add(new BasicNameValuePair("organiserId", params[1]));
            nameValuePairs.add(new BasicNameValuePair("eventId", params[2]));
            nameValuePairs.add(new BasicNameValuePair("secretKey", params[3]));
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

            // Execute HTTP Post Request
            HttpResponse response = httpclient.execute(httppost);

            BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "iso-8859-1"), 8);
            sb = new StringBuilder();
            sb.append(reader.readLine() + "\n");
            String line = "";
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            reader.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return sb.toString();
    }

    @Override
    protected void onPostExecute(String s) {

        Intent intent = new Intent(activity, MainNavigationActivity.class);
        if(s.trim().equals("Secret key matches")){
            Toast.makeText(activity, "Payment sent !", Toast.LENGTH_LONG).show();

            FirebaseDatabase.getInstance().getReference().child("Jobs").child(job)
                    .child("organiserIdCompleted").setValue(organiserId+"-"+true);

            FirebaseDatabase.getInstance().getReference().child("Jobs").child(job)
                    .child("bartenderIdCompleted").setValue(bartnderId+"-"+true);

            FirebaseDatabase.getInstance().getReference().child("Jobs").child(job)
                    .child("completed").setValue(true);

        } else {
            Toast.makeText(activity, "Payment failed ... Please, try again", Toast.LENGTH_LONG).show();
        }
        activity.startActivity(intent);
    }
}
