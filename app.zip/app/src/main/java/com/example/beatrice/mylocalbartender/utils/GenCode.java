package com.example.beatrice.mylocalbartender.utils;

import android.graphics.Bitmap;
import android.graphics.Color;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

/**
 * Created by louis on 09/03/17.
 * This class generates a qr code bit map from a string
 */

public class GenCode {

    static int width = 200;
    static int height = 200;


    /**
     * Generate a bitmap from a string (ex: url) using generateMatrix() method.
     * You can call this method to populate an image view with the bitmap (it will give u the corresponding QR code)
     * @param content
     * @return
     */
    public static Bitmap generateBitMap(String content){
        BitMatrix matrix = generateMatrix(content);
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                bitmap.setPixel(i, j, matrix.get(i, j) ? Color.BLACK: Color.WHITE);
            }
        }
        return bitmap;
    }

    private static BitMatrix generateMatrix(String content) {
        QRCodeWriter write = new QRCodeWriter();
        BitMatrix bitMatrix = null;
        try {
            bitMatrix = write.encode(content, BarcodeFormat.QR_CODE, width, height);
        } catch (WriterException e) {
            e.printStackTrace();
        }

        return bitMatrix;
    }

    }
