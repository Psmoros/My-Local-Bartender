package com.example.beatrice.mylocalbartender.utils;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.controller.MyFlowLayoutInterface;

import com.example.beatrice.mylocalbartender.model.Bartender;
import com.example.beatrice.mylocalbartender.model.Pair;

import org.apmem.tools.layouts.FlowLayout;

/**
 * Created by louis on 01/03/17.
 * A custome flowLayout created to decuple the flow a flow layout from the model
 * If you do not need a flow layout attatched to a modle you can use the standard flow layout
 */


public class MyFlowLayout extends FlowLayout implements MyFlowLayoutInterface {


    public MyFlowLayout(Context context) {
        super(context);
    }

    public MyFlowLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public MyFlowLayout(Context context, AttributeSet attributeSet, int defStyle) {
        super(context, attributeSet, defStyle);
    }

    @Override
    public void addToLayout(final Pair pair, final Bartender bartender, final String day) {

        final View shiftHoursWidget = LayoutInflater.from(getContext()).inflate(R.layout.shift_hours_widget, this, false);
        TextView startTimeWidget = (TextView)  shiftHoursWidget.findViewById(R.id.widget_start_time);
        TextView endTimeWidget = (TextView) shiftHoursWidget.findViewById(R.id.widget_end_time);


        if(shiftHoursWidget.getParent()!= null)
            ((ViewGroup) shiftHoursWidget.getParent()).removeView(shiftHoursWidget);
        addView(shiftHoursWidget);
        startTimeWidget.setText(String.valueOf(pair.getStartTime()));
        endTimeWidget.setText(String.valueOf(pair.getEndTime()));

         shiftHoursWidget.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    removeView(shiftHoursWidget);
                    bartender.deleteAvailableDate(day,pair);
                }
            });
    }

    @Override
    public void addToLayout(final String speciality, final Bartender bartender, boolean clickable) {
        final View specialityWidget = LayoutInflater.from(getContext()).inflate(R.layout.specialities_widget, this, false);
        TextView specialityName = (TextView)  specialityWidget.findViewById(R.id.speciality_text_view);
        if(specialityWidget.getParent()!= null)
            ((ViewGroup) specialityWidget.getParent()).removeView(specialityWidget);
        specialityName.setText(speciality);
        addView(specialityWidget);
        if(clickable) {
            bartender.addSpeciality(speciality);
            specialityWidget.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    removeView(specialityWidget);
                    bartender.eraseSpeciality(speciality);
                }
            });
        }

    }
}
