package com.example.beatrice.mylocalbartender.fragments;

import android.app.Fragment;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.controller.adapters.GenericRecyclerAdapter;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.controller.view_holders.ContactViewHolder;
import com.example.beatrice.mylocalbartender.model.Contacts;
import com.example.beatrice.mylocalbartender.utils.Colours;

/**
 * Activity that shows the contacts of the current user
 */
public class ContactFragment extends Fragment {

    // -- variables to do with the view

    //holds the recycler view
    private RecyclerView messageRecyclerView;
    //the layout used by the recycler view
    private LinearLayoutManager linearLayoutManager;
    //holds an instance of the progress bar
    private ProgressBar progressBar;

    // -- Firebase instance variables

    //the addapter that is a middel man between the database and the Recycler view
    private GenericRecyclerAdapter firebaseAdapter;

    private LinearLayout layout7;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        View view = inflater.inflate(R.layout.activity_contacts,null,false);

        layout7 = (LinearLayout) view.findViewById(R.id.contacts_layout);

        if(Colours.isDefault == false) {
            layout7.setBackgroundColor(Color.parseColor(Colours.backgroundColour));
        }

        // -- initialize view objects
        progressBar = (ProgressBar) view.findViewById(R.id.progressBarOne);
        messageRecyclerView = (RecyclerView) view.findViewById(R.id.contactRecyclerView);
        linearLayoutManager = new LinearLayoutManager(view.getContext());

        // -- initialize Recycler view
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        messageRecyclerView.setLayoutManager(linearLayoutManager);

        loadContacts();

        progressBar.setVisibility(ProgressBar.INVISIBLE);

        return view;

    }

    public void onCreateView(Bundle savedInstanceState) {
        
    }


    //loades the users that is user is able to comunicate with
    private void loadContacts(){

        //creates a new firebase recycler, is given a java class 'messages' that has the structure of the data to be requested from the database
        //a layout that the information will take
        //a class that transformes the java class information into the given layout
        //a database reference

        firebaseAdapter = new GenericRecyclerAdapter<Contacts,ContactViewHolder>(
                Contacts.class,
                R.layout.item_message,
                ContactViewHolder.class) {

            //populates the recycler view


            @Override
            public void bindViewWithData(ContactViewHolder holder, Contacts contacts, int position) {

                holder.bindWithContact(contacts,getActivity());
                progressBar.setVisibility(ProgressBar.INVISIBLE);

            }
        };

        //sets the layout of the recicaler of the recycler view (vertical linearLayout)
        messageRecyclerView.setLayoutManager(linearLayoutManager);
        //adds the adapter
        messageRecyclerView.setAdapter(firebaseAdapter);
        FirebaseManagement.getInstance().currentUser.loadContacts(firebaseAdapter);
    }

}
