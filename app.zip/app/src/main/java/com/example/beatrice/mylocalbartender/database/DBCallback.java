package com.example.beatrice.mylocalbartender.database;

/**
 *  a simple callback to be used with Aysnc database
 */
public interface DBCallback {
     void callBack(Object object);
}
