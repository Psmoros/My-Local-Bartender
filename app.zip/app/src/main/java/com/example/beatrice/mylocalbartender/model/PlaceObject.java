package com.example.beatrice.mylocalbartender.model;

import android.os.Parcel;

import com.arlib.floatingsearchview.suggestions.model.SearchSuggestion;

/**
 * Created by Umar on 27/02/2017.
 * This is a search suggestion that is used as a wrapper to display search suggestions
 */

public class PlaceObject implements SearchSuggestion {

    private String locationText;

    private String placeID;

    public PlaceObject(String locationText, String placeID) {
        this.locationText = locationText;
        this.placeID = placeID;
    }

    public String getLocationText() {
        return locationText;
    }

    public void setLocationText(String locationText) {
        this.locationText = locationText;
    }

    public String getPlaceID() {
        return placeID;
    }

    public void setPlaceID(String placeID) {
        this.placeID = placeID;
    }

    public String toString() {

        return placeID + locationText;

    }


    @Override
    public String getBody() {
        return locationText;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

    }
}
