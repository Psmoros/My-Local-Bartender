package com.example.beatrice.mylocalbartender.utils.async;

import android.os.AsyncTask;
import android.widget.EditText;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.auth.FirebaseUser;
import com.loopj.android.http.HttpGet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import cz.msebera.android.httpclient.HttpEntity;
import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.client.ClientProtocolException;
import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;

/**
 * Created by Umar on 04/03/2017.
 * This class is for getting a location from a post code asynchronously
 */

public class AsyncLocation extends AsyncTask<String,Void,LatLng> {


    // the geofire objejct
    protected GeoFire geoFire;
    private FirebaseUser user;
    private EditText postCodeField;

    /**
     * Pass in the geo fire object the edit text and the current firebase user 
     * @param geoFire
     * @param postCodeField
     * @param user
     */
    public AsyncLocation(GeoFire geoFire,EditText postCodeField, FirebaseUser user) {
        super();
        this.geoFire = geoFire;
        this.postCodeField = postCodeField;
        this.user = user;

    }

    public AsyncLocation(GeoFire geoFire){
        super();
        this.geoFire = geoFire;
    }

    /**
     * This is called when there is a result returned from the async doInBackground method
     * @param latLng The latlng returned from the Google api
     */
    @Override
    protected void onPostExecute(LatLng latLng) {



        if(latLng!=null) {

            geoFire.setLocation(user.getUid(), new GeoLocation(latLng.latitude, latLng.longitude));
            restoreTextField(postCodeField);
        }
            else{
                highlightField(postCodeField);
            }


        }


    /**
     *
     * @param params The params here refers(post code) to the address that you pass on
     * @return The latlng returned from the getlocationFromString
     *
     */
    @Override
    protected LatLng doInBackground(String... params) {

        try {
            return getLocationFromString(params[0]);
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        return  null;
    }

    private LatLng getLocationFromString(String address)
            throws JSONException, UnsupportedEncodingException {

        // constuct a get request
        HttpGet httpGet = new HttpGet(
                "http://maps.google.com/maps/api/geocode/json?address="
                        + URLEncoder.encode(address, "UTF-8") + "&ka&sensor=false");
        HttpClient client = new DefaultHttpClient();
        HttpResponse response;
        StringBuilder stringBuilder = new StringBuilder();

        try {
            // execute a the get request
            response = client.execute(httpGet);
            HttpEntity entity = response.getEntity();
            InputStream stream = entity.getContent();
            int b;
            while ((b = stream.read()) != -1) {
                // append the entire body into a string
                stringBuilder.append((char) b);
            }
        } catch (ClientProtocolException e) {

            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // convert that string into a json object
        JSONObject jsonObject = new JSONObject(stringBuilder.toString());

        double lng = ((JSONArray) jsonObject.get("results")).getJSONObject(0)
                .getJSONObject("geometry").getJSONObject("location")
                .getDouble("lng");

        double lat = ((JSONArray) jsonObject.get("results")).getJSONObject(0)
                .getJSONObject("geometry").getJSONObject("location")
                .getDouble("lat");

        // return the information
        return new LatLng(lat, lng);
    }

    private void restoreTextField(EditText editText){
        editText.setTextColor(0xffffffff);
    }


    private void highlightField(EditText editText) {
        editText.setTextColor(0xffff0000);
    }





}
