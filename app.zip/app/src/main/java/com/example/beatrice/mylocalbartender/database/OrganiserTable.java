package com.example.beatrice.mylocalbartender.database;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

/**
* The Java class representation of the SQLite table 'organiser'.
 */
public class OrganiserTable {
    //Database Table User
    public static final String TABLE_ORGANISER = "organiser";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_FIRST_NAME = "firstName";
    public static final String COLUMN_LAST_NAME = "lastName";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_GENDER = "gender";
    public static final String COLUMN_PHONE = "phoneNumber";
    public static final String COLUMN_LOCATION = "location";
    public static final String COLUMN_DOB = "dob";
    public static final String COLUMN_USER_TYPE = "userType";
    public static final String COLUMN_PICTURE = "picture";
    public static final String COLUMN_PROFESSION = "professionalPosition";
    public static final String COLUMN_BUSINESS_NAME = "businessName";
    public static final String COLUMN_BUSINESS_PROFILE = "businessBio";


    private static final String DATABASE_CREATE =
            "create table "
                    + TABLE_ORGANISER
                    +"("
                    +COLUMN_ID + " TEXT PRIMARY KEY, "
                    +COLUMN_FIRST_NAME + " TEXT NOT NULL, "
                    +COLUMN_LAST_NAME + " TEXT NOT NULL, "
                    +COLUMN_EMAIL + " TEXT NOT NULL, "
                    +COLUMN_GENDER + " TEXT, "
                    +COLUMN_PHONE + " TEXT, "
                    +COLUMN_LOCATION + " TEXT, "
                    +COLUMN_DOB + " TEXT, "
                    +COLUMN_USER_TYPE + " TEXT, "
                    +COLUMN_PICTURE + " TEXT, "
                    +COLUMN_PROFESSION + " TEXT, "
                    +COLUMN_BUSINESS_NAME + " TEXT, "
                    +COLUMN_BUSINESS_PROFILE + " TEXT"
                    + ");";

    public static void onCreate(SQLiteDatabase database) {
        database.execSQL(DATABASE_CREATE);
    }

    public static void onUpgrade(SQLiteDatabase database, int oldVersion,
                                 int newVersion) {
        Log.w(OrganiserTable.class.getName(), "Upgrading database from version "
                + oldVersion + " to " + newVersion
                + ", which will destroy all old data");
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_ORGANISER);
        onCreate(database);
    }
}
