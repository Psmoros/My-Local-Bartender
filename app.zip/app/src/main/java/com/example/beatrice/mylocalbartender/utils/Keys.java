package com.example.beatrice.mylocalbartender.utils;

import android.location.Address;

import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.auth.FirebaseAuth;
import com.loopj.android.http.HttpGet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import cz.msebera.android.httpclient.HttpEntity;
import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.client.ClientProtocolException;
import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;

/**
 * Created by Umar on 22/02/2017.
 * A statics list of keys used in {@link android.os.Bundle} objects to avoid typing conflicts
 */

public class Keys {

    public static final LatLng GLOABL_EAST = new LatLng(-85, -180);
    public static final LatLng GLOBAL_WEST = new LatLng(85, 180);
    public static final String[] DAYS_OF_THE_WEEK = {"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
    /*
        The strings below represents constants for search -- Do not remove app will break
     */
    public static final String LONGITUDE = "logitude";
    public static final String LATITUDE = "latitude";
    public static final String SHIFT_RATE = "shift_rate";
    public static final String SHIFT_DAY = "shift_day";
    public static final String STARTING_TIME = "starting_time";
    public static final String ENDGING_TIME = "ending_time";
    public static final String DAY = "day";
    public static final String DISTANCE ="distnace";
    public static final String RATING ="rating";
    public static final String BARTENDER = "bartender";
    public static final String EVENT_GEOFIRE_REF ="EventsGeoFire";

    public static final String BOOKING_REQEUEST_TABLE = "BookingRequest";




}
