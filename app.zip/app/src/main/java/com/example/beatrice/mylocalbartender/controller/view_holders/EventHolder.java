package com.example.beatrice.mylocalbartender.controller.view_holders;

import android.app.Activity;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.controller.ProfilePicManager;
import com.example.beatrice.mylocalbartender.controller.interfaces.OrganiserCallback;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.model.BaseRequest;
import com.example.beatrice.mylocalbartender.model.BookingStatus;
import com.example.beatrice.mylocalbartender.model.Event;
import com.example.beatrice.mylocalbartender.model.Organiser;
import com.example.beatrice.mylocalbartender.model.User;
import com.example.beatrice.mylocalbartender.model.UserType;
import com.example.beatrice.mylocalbartender.utils.Keys;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.w3c.dom.Text;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

/**
 * This class represents a view holder. This view holder will hold information about an Event and will display the information
 */
public class EventHolder extends RecyclerView.ViewHolder {


    private Event event;
    private TextView eventTitle;
    private TextView shiftRate;
    private TextView shiftTime;
    private TextView postCode;
    private ImageButton cancel;
    private ImageView eventImage;
    private Activity activity;
    private Organiser currentOrganiser;

    private String organiserUid;
    private TextView dateAndTime;
    private ImageButton acceptButton;
    private StorageReference storageReference = FirebaseStorage.getInstance().getReference();


    /**
     * Constructor for creating an Event holder object
     * @param itemView The itemview that is inflated and passed
     */
    public EventHolder(View itemView) {
        super(itemView);


        eventTitle = (TextView) itemView.findViewById(R.id.event_title);
        //eventType = (TextView) itemView.findViewById(R.id.event_type);
        postCode = (TextView) itemView.findViewById(R.id.post_code);

        cancel = (ImageButton) itemView.findViewById(R.id.cancel_button);

        shiftRate = (TextView) itemView.findViewById(R.id.shift_rate);

        shiftTime = (TextView) itemView.findViewById(R.id.shift_hours);

        eventImage = (ImageView) itemView.findViewById(R.id.event_image);

        dateAndTime = (TextView) itemView.findViewById(R.id.date_and_time);

        itemView.findViewById(R.id.event_status).setVisibility(View.GONE);

        itemView.findViewById(R.id.qr_code_button).setVisibility(View.GONE);

        itemView.findViewById(R.id.message_button).setVisibility(View.GONE);

        acceptButton = (ImageButton) itemView.findViewById(R.id.accept_job_button);

        itemView.findViewById(R.id.adjust_rate_button).setVisibility(View.GONE);


    }

    /**
     * This method binds the data retrieved to the view
     * @param event The event to be binded
     * @param activity The activity that is displaying the results
     * @param organiser The organiser
     */
    public void bindData(Event event, Activity activity, Organiser organiser) {

        this.activity = activity;

        this.currentOrganiser = organiser;

        this.event = event;

        eventTitle.setText(event.getTitle());

        shiftTime.setText(event.getStartTime() + " : " + event.getFinishTime());

        shiftRate.setText(String.valueOf(event.getShiftRate()));

        postCode.setText(event.getLocation());

        dateAndTime.setText(event.getDate());

        StorageReference eventPicRef = storageReference.child("EventPics");

        ProfilePicManager.loadProfilePicFromStorage(eventImage, activity, event.getEvent_id(), false, eventPicRef);

        acceptButton.setVisibility(View.GONE);

        if(event.isAvailable() == true) {

            addListener();

        }else if(event.isAvailable() == false){

            cancel.setVisibility(View.GONE);
        }

    }

    public void bindDataForSearch(final Event event, Activity activity, final String organiserUid){



        this.activity = activity;

        this.organiserUid = organiserUid;

        this.event = event;



        eventTitle.setText(event.getTitle());

        shiftTime.setText(event.getStartTime() + " : " + event.getFinishTime());

        shiftRate.setText(String.valueOf(event.getShiftRate()));

        postCode.setText(event.getLocation());

        dateAndTime.setText(event.getDate());

        StorageReference eventPicRef = storageReference.child("EventPics");

        ProfilePicManager.loadProfilePicFromStorage(eventImage, activity, event.getEvent_id(), false, eventPicRef);

        eventImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDescriptionEventPopup();
            }
        });

        final User user = FirebaseManagement.getInstance().currentUser;

        cancel.setVisibility(View.GONE);

        acceptButton.setVisibility(View.VISIBLE);


        acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                FirebaseManagement.getInstance().getUser(organiserUid, new OrganiserCallback() {
                    @Override
                    public void provideUser(Organiser organiser) {

                        currentOrganiser = organiser;
                        BaseRequest organiserBookingRequest = new BaseRequest("stub",
                                false,
                                event,
                                currentOrganiser.getUid(),
                                user.getUid(),
                                currentOrganiser.getFirstName(),
                                currentOrganiser.getLastName(),
                                user.getFirstName(),
                                user.getLastName(), event.getShiftRate());
                        pushBookingRequest(organiserBookingRequest);

                    }
                });



            }
        });


    }


    public void pushBookingRequest(BaseRequest baseRequest){

        DatabaseReference pushRef= FirebaseDatabase.getInstance().getReference().child(Keys.BOOKING_REQEUEST_TABLE).push();
        baseRequest.setBookingID(pushRef.getKey());
        baseRequest.setStatus(BookingStatus.APPROVED);
        pushRef.setValue(baseRequest);
        Toast.makeText(activity,"Reqeuest sent!!",Toast.LENGTH_LONG).show();
    }



    /**
     * Adds the listeners to the cancel button controller
     */
    private void addListener() {


        // TODO: 09/03/2017 Add a dilogue pop up that displays the image
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(currentOrganiser.cancelEvent(event)){
                    ProfilePicManager.eraseImage(activity, event.getEvent_id());
                   Toast.makeText(activity,"You have removed the event",Toast.LENGTH_LONG).show();
                }else{

                    Toast.makeText(activity,"You can not delete this event",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        eventImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDescriptionEventPopup();
            }
        });


    }

    private void showDescriptionEventPopup(){

        LayoutInflater inflater = (LayoutInflater) activity.getSystemService(LAYOUT_INFLATER_SERVICE);

        // Inflate the custom layout/view
        final View descriptionPopUp = inflater.inflate(R.layout.event_description_popup, null, false);

        // Initialize a new instance of popup window
        final PopupWindow mPopupWindow = new PopupWindow(descriptionPopUp, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        mPopupWindow.setFocusable(true);
        mPopupWindow.update();

        // Set an elevation value for popup window
        // Call requires API level 21
        if (Build.VERSION.SDK_INT >= 21) {
            mPopupWindow.setElevation(5.0f);
        }


        TextView description = (TextView) descriptionPopUp.findViewById(R.id.event_description_field);
        ImageButton exitPopUp = (ImageButton) descriptionPopUp.findViewById(R.id.exit_popup_button);

        description.setText(event.getDescription());

        mPopupWindow.showAtLocation(descriptionPopUp, Gravity.CENTER, 0, 0);

        // Set a click listener for the popup window close button
        exitPopUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Dismiss the popup window
                mPopupWindow.dismiss();
            }
        });

    }



}
