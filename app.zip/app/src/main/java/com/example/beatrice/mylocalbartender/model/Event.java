package com.example.beatrice.mylocalbartender.model;

import android.support.annotation.VisibleForTesting;

import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;

/**
 * Created by Umar and Chris  on 02/03/2017.
 * This class represents an event that an organiser can create and this event will be linked to a job
 */

public class Event {

    // TODO: 02/03/2017  Change types and make them appropriate -- A lot of them are strings
    // TODO: 10/03/2017 I do not think the noSQL hack is needed at this stage 
    private String event_id;
    private String picURI;
    private String title;
    private String description;
    private String location; // this will be the post code
    private String date;
    private String startTime;
    private String finishTime;
    private String organiserUid;
    private String organiserName;
    private double shiftRate;
    private boolean available;
    private int requiredBartenders;
    private boolean isDayEvent; //// TODO: 10/03/2017 A job theoritcally can last 24+ hours -- This is a weird property 
    //private String organiserIdPublic; // nosql hack use this for and statements
    private boolean isEventPublic;


// TODO: 09/03/2017 Add the shift day or the shift night

    /**
     * @param title              title of the event.
     * @param description        the description of the event.
     * @param location           UK post code.
     * @param date               date event is taking place.
     * @param startTime          time the job starts.
     * @param finishTime         time the job ends.
     * @param organiserUid       the User who created the event.
     * @param shiftRate          The shift rate of the event
     * @param requiredBartenders the # of bartenders required for the job.
     * @param isDayEvent         Specifies if the job is in the day or night
     * @param isEventPublic specifies if the event is a public event
     */
    public Event(String event_id,
                 String title,
                 String description,
                 String location,
                 String date,
                 String startTime,
                 String finishTime,
                 String organiserUid,
                 double shiftRate,
                 int requiredBartenders,
                 boolean isDayEvent,
                 boolean isEventPublic,
                 FirebaseManagement firebaseManagement) {

        this.event_id = event_id;
        this.title = title;
        this.description = description;
        this.location = location;
        this.date = date;
        this.startTime = startTime;
        this.finishTime = finishTime;
        this.organiserUid = organiserUid;
        this.shiftRate = shiftRate;
        this.requiredBartenders = requiredBartenders;
        this.isDayEvent = isDayEvent;
        organiserName = firebaseManagement.getInstance().currentUser.getFirstName() + " " + firebaseManagement.getInstance().currentUser.getLastName();
        this.available = true;
      //  this.organiserIdPublic = organiserUid +"-"+isEventPublic; // noSQL query hack
        this.isEventPublic= isEventPublic;
    }

    @VisibleForTesting
    protected Event(String event_id,
                 String title,
                 String description,
                 String location,
                 String date,
                 String startTime,
                 String finishTime,
                 String organiserUid,
                 double shiftRate,
                 int requiredBartenders,
                 boolean isDayEvent,
                 boolean isEventPublic){

        this.event_id = event_id;
        this.title = title;
        this.description = description;
        this.location = location;
        this.date = date;
        this.startTime = startTime;
        this.finishTime = finishTime;
        this.organiserUid = organiserUid;
        this.shiftRate = shiftRate;
        this.requiredBartenders = requiredBartenders;
        this.isDayEvent = isDayEvent;
        this.available = true;


    }

    public Event(){

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(String finishTime) {
        this.finishTime = finishTime;
    }

    public String getOrganiserUid() {
        return organiserUid;
    }

    public void setOrganiserUid(String organiserUid) {
        this.organiserUid = organiserUid;
    }

    public String getEvent_id() {
        return event_id;
    }

    public void setEvnet_id(String event_id) {
        this.event_id = event_id;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public String getOrganiserName() {
        return organiserName;
    }

    public void setOrganiserName(String organiserName) {
        this.organiserName = organiserName;
    }

    public int getRequiredBartenders() {
        return requiredBartenders;
    }

    public String getPicURI() {
        return picURI;
    }

    public void setPicURI(String picURI) {
        this.picURI = picURI;
    }

    public void setRequiredBartenders(int requiredBartenders) {
        this.requiredBartenders = requiredBartenders;
    }


    /**
     * This method will decrement the number of available places left for an event
     * This method does the opposit of increment {@link #incrementEvent(DatabaseReference)}
     *
     * @param eventReference The database reference for the event
     */
    public void decrementEvent(DatabaseReference eventReference) {

        eventReference.runTransaction(new Transaction.Handler() {
            @Override
            public Transaction.Result doTransaction(MutableData mutableData) {

                Event event = mutableData.getValue(Event.class);
                // if the event does not exist terminate the transaction
                if (event == null) {
                    return Transaction.success(mutableData);

                }

                // if the event is already at 0 terminate the transaction
                if (event.getRequiredBartenders() == 0) {

                    return Transaction.success(mutableData);

                }

                // decrement the count
                event.setRequiredBartenders(event.getRequiredBartenders() - 1);

                if (event.getRequiredBartenders() == 0) {

                    // the event has been fully booked and locked
                    //// TODO: 12/03/2017 This may be an error due to naming conflicts
                    event.setAvailable(false);


                }

                mutableData.setValue(event);

                return Transaction.success(mutableData);


            }

            @Override
            public void onComplete(DatabaseError databaseError, boolean b, DataSnapshot dataSnapshot) {

                // do not know what to do here

            }
        });


    }


    /**
     * This will do opposite of decrement and will increment the availability of an event
     * {@link #incrementEvent(DatabaseReference)}
     *
     * @param eventRef The database reference of the event
     */
    public void incrementEvent(DatabaseReference eventRef) {


        eventRef.runTransaction(new Transaction.Handler() {
            @Override
            public Transaction.Result doTransaction(MutableData mutableData) {

                Event event = mutableData.getValue(Event.class);
                // if the event does not exist terminate the transaction
                if (event == null) {
                    return Transaction.success(mutableData);
                }

                // Increment the counter
                event.setRequiredBartenders(event.getRequiredBartenders() + 1);

                // if we were at 0 when we began this transaction
                if (event.getRequiredBartenders() == 1) {
                    event.setAvailable(true);
                }
                mutableData.setValue(event);

                return Transaction.success(mutableData);


            }

            @Override
            public void onComplete(DatabaseError databaseError, boolean b, DataSnapshot dataSnapshot) {

                // do not know what to do here

            }
        });


    }


    public double getShiftRate() {
        return shiftRate;
    }

    public void setShiftRate(double shiftRate) {
        this.shiftRate = shiftRate;
    }


    /**
     * todo does it make sense for an event to cancel itself
     * This removes an event from the database
     * When it is cancelled the server has to react
     */


    public boolean isDayEvent() {
        return isDayEvent;
    }

    public void setDayEvent(boolean dayEvent) {
        isDayEvent = dayEvent;
    }




    public boolean isEventPublic() {
        return isEventPublic;
    }

    public void setEventPublic(boolean eventPublic) {
        isEventPublic = eventPublic;
    }


}
