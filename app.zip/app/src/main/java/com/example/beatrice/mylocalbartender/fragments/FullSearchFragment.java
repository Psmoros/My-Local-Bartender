package com.example.beatrice.mylocalbartender.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.arlib.floatingsearchview.FloatingSearchView;
import com.arlib.floatingsearchview.suggestions.SearchSuggestionsAdapter;
import com.arlib.floatingsearchview.suggestions.model.SearchSuggestion;
import com.arlib.floatingsearchview.util.adapter.TextWatcherAdapter;
import com.chauthai.swipereveallayout.ViewBinderHelper;
import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.controller.adapters.GenericRecyclerAdapter;
import com.example.beatrice.mylocalbartender.controller.adapters.SeekBarListenerAdapter;
import com.example.beatrice.mylocalbartender.controller.adapters.TagsRecyclerAdapter;
import com.example.beatrice.mylocalbartender.controller.interfaces.Hide;
import com.example.beatrice.mylocalbartender.controller.interfaces.NotifyInterface;
import com.example.beatrice.mylocalbartender.controller.interfaces.OrganiserCallback;
import com.example.beatrice.mylocalbartender.controller.view_holders.BartenderViewHolder;
import com.example.beatrice.mylocalbartender.controller.view_holders.EventHolder;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.model.Bartender;
import com.example.beatrice.mylocalbartender.model.Event;
import com.example.beatrice.mylocalbartender.model.Organiser;
import com.example.beatrice.mylocalbartender.model.PlaceObject;
import com.example.beatrice.mylocalbartender.model.Tag;
import com.example.beatrice.mylocalbartender.model.User;
import com.example.beatrice.mylocalbartender.model.UserType;
import com.example.beatrice.mylocalbartender.utils.TestConstants;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResolvingResultCallbacks;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.AutocompletePrediction;
import com.google.android.gms.location.places.AutocompletePredictionBuffer;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlaceBuffer;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import static android.app.Activity.RESULT_OK;
import static com.example.beatrice.mylocalbartender.utils.Keys.DAY;
import static com.example.beatrice.mylocalbartender.utils.Keys.DAYS_OF_THE_WEEK;
import static com.example.beatrice.mylocalbartender.utils.Keys.DISTANCE;
import static com.example.beatrice.mylocalbartender.utils.Keys.ENDGING_TIME;
import static com.example.beatrice.mylocalbartender.utils.Keys.GLOABL_EAST;
import static com.example.beatrice.mylocalbartender.utils.Keys.GLOBAL_WEST;
import static com.example.beatrice.mylocalbartender.utils.Keys.LATITUDE;
import static com.example.beatrice.mylocalbartender.utils.Keys.LONGITUDE;
import static com.example.beatrice.mylocalbartender.utils.Keys.RATING;
import static com.example.beatrice.mylocalbartender.utils.Keys.SHIFT_DAY;
import static com.example.beatrice.mylocalbartender.utils.Keys.SHIFT_RATE;
import static com.example.beatrice.mylocalbartender.utils.Keys.STARTING_TIME;

/**
 * This fragment is the full search fragment that displays the complex detailed search
 * The google api maps and shows results for event and bartender searches
 */

public class FullSearchFragment extends android.app.Fragment implements GoogleApiClient.OnConnectionFailedListener
        , NotifyInterface, View.OnClickListener {

    private FloatingSearchView floatingSearchView;
    private GoogleApiClient googleApiClient;
    private RecyclerView recyclerView;
    private com.example.beatrice.mylocalbartender.controller.adapters.GenericRecyclerAdapter recyclerAdapter;

    private ArrayList<PlaceObject> searchSuggestion;

    private final int PLACE_PICKER_REQUEST = 1;

    private SeekBar distanceSeekBar;
    private SeekBar ratingSeekBar;

    private View selectDay;
    private View selectStart;
    private View selectEnd;
    private ProgressBar p;
    private TextView dayTextView;
    private TextView starTextView;
    private TextView endTextView;
    private ImageButton[] ratingButtons = new ImageButton[5];

    private Button search;
    private TextView shiftRateTextView;
    private TextView distanceTextView;
    private Button selectSpecialties;

    private TextView changeDayTextView;
    // variables for searching
    // >>start of fields for search
    // two varibales needed for geofire
    private Double mlongitude;
    private Double mlatitude;


    private double rating;
    private int distance;
    private String specialtiesOrEvents;
    private String day;
    private int startTime;
    private int endTime;
    private double shiftRate;
    private boolean isShiftDay = true;

    private Hide hide;

    //<< end of fields for search
    private PlaceObject placeObject;

    private PopupWindow tagsPopWindow;

    private HashMap<Integer, Tag> selectedTags;

    private ArrayList<Tag> specialityTags;


    private Context globalContext;
    private ActionBarDrawerToggle drawerToggle;
    private DrawerLayout drawerLayout;
    private SwitchCompat switchCompat;

    // TODO: 03/03/2017 Get the actual user when running the query

    private User currentUser;


    // this will be used to bind the layout for that nice swipe
    private final ViewBinderHelper binderHelper = new ViewBinderHelper();
    private View view;


    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);



        //// TODO: 07/03/2017 Save the instance the state

        currentUser = FirebaseManagement.getInstance().currentUser;

        specialityTags = new ArrayList<>();

        if(currentUser.getUserType() == UserType.BARTENDER) {

            specialityTags.add(new Tag("1", "Mockito", "Hello"));


            specialityTags.add(new Tag("2", "Mockito", "Hello"));


            specialityTags.add(new Tag("3", "Mockito", "Hello"));


            specialityTags.add(new Tag("4", "Mockito", "Hello"));


            specialityTags.add(new Tag("5", "Mockito", "Hello"));


            specialityTags.add(new Tag("6", "Mockito", "Hello"));



        }else{

            specialityTags.add(new Tag("1", "Mockito", "Hello"));


            specialityTags.add(new Tag("2", "Mockito", "Hello"));


            specialityTags.add(new Tag("3", "Mockito", "Hello"));


            specialityTags.add(new Tag("4", "Mockito", "Hello"));


            specialityTags.add(new Tag("5", "Mockito", "Hello"));


            specialityTags.add(new Tag("6", "Mockito", "Hello"));


        }



        setDefaults();

        selectedTags = new HashMap<>();


    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_search_quick_navigation, null, false);

        p = (ProgressBar) view.findViewById(R.id.progressBarTwo);

        initialise();

        inflateViews(view);

        setSearchListener();

        initialiseController();

        setQueryListener();

        searchSuggestion = new ArrayList<>();

        if (savedInstanceState != null) {

            getDataState(savedInstanceState);

            //displaySavedData();

        } else {

            // this is where I will run the query

        }

        return view;

    }

    private void inflateViews(View view) {


        recyclerView = (RecyclerView) view.findViewById(R.id.search_results_list);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(getActivity(),
                layoutManager.getOrientation());
        recyclerView.addItemDecoration(dividerItemDecoration);

        if (FirebaseManagement.getInstance().currentUser.getUserType() == UserType.BARTENDER) {

            recyclerAdapter = new GenericRecyclerAdapter<Event, EventHolder>(Event.class,
                    R.layout.event_result_layout,
                    EventHolder.class) {

                @Override
                public void bindViewWithData(final EventHolder holder, final Event event, int position) {


                    holder.bindDataForSearch(event,getActivity(),event.getOrganiserUid());

                }
            };
        } else {

            recyclerAdapter = new GenericRecyclerAdapter<Bartender, BartenderViewHolder>(Bartender.class,
                    R.layout.swipable_profile_view,
                    BartenderViewHolder.class) {


                @Override
                public void bindViewWithData(BartenderViewHolder holder, Bartender model, int position) {
                    binderHelper.bind(holder.getSwipeLayout(), currentUser.getUid());
                    holder.bind(model, getActivity());
                }
            };

        }
        recyclerView.setAdapter(recyclerAdapter);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {

                if (dy > 0) {
                    hide.hide();
                } else {
                    hide.reveal();
                }

            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        floatingSearchView = (FloatingSearchView) view.findViewById(R.id.floating_search_view);

        distanceSeekBar = (SeekBar) view.findViewById(R.id.distance_seek_bar);

        distanceSeekBar.setProgress(10);

        ratingSeekBar = (SeekBar) view.findViewById(R.id.shift_rate_seek_bar);

        ratingSeekBar.setProgress(30);

        selectDay = view.findViewById(R.id.select_day);

        selectStart = view.findViewById(R.id.select_start);

        selectEnd = view.findViewById(R.id.select_end);

        dayTextView = (TextView) view.findViewById(R.id.day_text_view);

        starTextView = (TextView) view.findViewById(R.id.start_time_text_view);

        endTextView = (TextView) view.findViewById(R.id.end_time_text_view);

        shiftRateTextView = (TextView) view.findViewById(R.id.shift_rate_text_view);

        distanceTextView = (TextView) view.findViewById(R.id.distance_text_view);

        selectSpecialties = (Button) view.findViewById(R.id.select_specialties);

        drawerLayout = (DrawerLayout) view.findViewById(R.id.drawerLayout);

        ratingButtons[0] = (ImageButton) view.findViewById(R.id.one_star);

        ratingButtons[1] = (ImageButton) view.findViewById(R.id.two_stars);

        ratingButtons[2] = (ImageButton) view.findViewById(R.id.three_stars);

        ratingButtons[3] = (ImageButton) view.findViewById(R.id.four_stars);

        ratingButtons[4] = (ImageButton) view.findViewById(R.id.five_stars);

        for(ImageButton floatingActionButton : ratingButtons) {


            floatingActionButton.setOnClickListener(this);


        }

        ratingButtons[0].setImageResource(R.drawable.full_glass);

        for(int i = 1; i< ratingButtons.length; i++){

            ratingButtons[i].setImageResource(R.drawable.empty_glass);

        }

        search = (Button) view.findViewById(R.id.search_inside_navigation);

        switchCompat = (SwitchCompat) view.findViewById(R.id.switch_compat);

        switchCompat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    isShiftDay = false;
                } else {
                    isShiftDay = true;
                }

            }
        });

        view.findViewById(R.id.change_day).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (switchCompat.isChecked()) {
                    switchCompat.setChecked(false);
                } else {
                    switchCompat.setChecked(true);
                }
            }
        });

        if(TestConstants.CONSTANT == 1){
            drawerLayout.openDrawer(Gravity.RIGHT);
        }


    }

    private void initialiseController() {

        drawerToggle = new ActionBarDrawerToggle(getActivity(), drawerLayout,
                R.string.drawer_open, R.string.drawer_close) {

            /** Called when a drawer has settled in a completely closed state. */
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                // I will reveal what needs to be hidden
                hide.reveal();

            }

            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {

                // the drawer is peaking out
                if (slideOffset != 0) {
                    hide.hide();
                }
                // the drawer has stopped peaking out
                else if (slideOffset == 0) {
                    hide.reveal();
                }

            }


        };

        if (currentUser.getUserType() == UserType.BARTENDER) {
            selectSpecialties.setText("SELECT EVENTS");
        }


        // Set the drawer toggle as the DrawerListener
        drawerLayout.addDrawerListener(drawerToggle);


        distanceSeekBar.setOnSeekBarChangeListener(new SeekBarListenerAdapter() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                distance = progress;
                distanceTextView.setText(String.valueOf(distance) + " miles");
            }
        });

        ratingSeekBar.setOnSeekBarChangeListener(new SeekBarListenerAdapter() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                shiftRate = progress;
                shiftRateTextView.setText(String.valueOf(shiftRate));

            }
        });


        selectDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // start calendar fragement

                Calendar now = Calendar.getInstance();
                DatePickerDialog dpd = DatePickerDialog.newInstance(
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {


                                Calendar c = Calendar.getInstance();
                                c.set(year, monthOfYear, dayOfMonth);

                                int day_of_week = c.get(Calendar.DAY_OF_WEEK);

                                day = DAYS_OF_THE_WEEK[day_of_week - 1];

                                dayTextView.setText(day);


                            }
                        },
                        now.get(Calendar.YEAR),
                        now.get(Calendar.MONTH),
                        now.get(Calendar.DAY_OF_MONTH)
                );
                dpd.show(getFragmentManager(), "Datepickerdialog");

            }
        });


        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (TestConstants.CONSTANT == 1) {
                    mlongitude = 2.0;
                    mlatitude = 2.0;
                    drawerLayout.closeDrawers();
                    constuctQuery();
                    p.setVisibility(ProgressBar.INVISIBLE);
                } else {
                    // this implies that long and lat have to be found
                    drawerLayout.closeDrawers();
                    if (placeObject != null) {

                        recyclerAdapter.clearAllData();

                        getLocationSelected(placeObject.getPlaceID());

                    } else {

                        // I do not need to get the location from the placeId as I have it from the Google activity
                        if (mlatitude != null && mlongitude != null) {

                            recyclerAdapter.clearAllData();
                            constuctQuery();
                            p.setVisibility(ProgressBar.INVISIBLE);
                        } else {

                            Toast.makeText(globalContext, "Please enter a location", Toast.LENGTH_SHORT).show();
                        }
                    }
                }


            }
        });

        selectStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // start time fragment


                com.wdullaer.materialdatetimepicker.time.TimePickerDialog timePickerDialog = com.wdullaer.materialdatetimepicker.time.TimePickerDialog.newInstance(new com.wdullaer.materialdatetimepicker.time.TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(com.wdullaer.materialdatetimepicker.time.TimePickerDialog view, int hourOfDay, int minute, int second) {

                        startTime = hourOfDay;

                        starTextView.setText(String.valueOf(startTime));


                    }
                }, 12, 0, 0, true);

                timePickerDialog.show(getFragmentManager(), "timePickerDialog");


            }
        });


        selectEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // start time fragment


                com.wdullaer.materialdatetimepicker.time.TimePickerDialog timePickerDialog = com.wdullaer.materialdatetimepicker.time.TimePickerDialog.newInstance(new com.wdullaer.materialdatetimepicker.time.TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(com.wdullaer.materialdatetimepicker.time.TimePickerDialog view, int hourOfDay, int minute, int second) {

                        endTime = hourOfDay;

                        endTextView.setText(String.valueOf(endTime));

                    }
                }, 12, 0, 0, true);

                timePickerDialog.show(getFragmentManager(), "timePickerDialog");


            }
        });

/**
 * These two radio handlers shift the state of the day
 */


        /**
         * This method will inflate the pop up
         */
        selectSpecialties.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                inflatePopUp();
            }
        });


        // adding the  overide seeklisteners to the all the seekbars
        addOverideSeekListener(ratingSeekBar, distanceSeekBar);


        if(currentUser.getUserType() == UserType.BARTENDER){
            view.findViewById(R.id.container_rating).setVisibility(View.GONE);
        }

        setDefaults();

    }

    /**
     * Method called if you cannot connect to the google api client
     *
     * @param connectionResult the result of a failed connection
     */
    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

        Log.d("FailedToConnectToGoogle", "Some connection failed");


    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        hide = (Hide) activity;

        globalContext = activity.getBaseContext();

    }

    @Override
    public void onStart() {
        if (googleApiClient != null)
            googleApiClient.connect();
        super.onStart();
    }

    @Override
    public void onStop() {
        if (googleApiClient != null)
            googleApiClient.disconnect();
        super.onStop();

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        googleApiClient.disconnect();

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        saveHelperState(outState);

    }


    // TODO: 07/03/2017 Add the rating
    private void saveHelperState(Bundle outState) {


        outState.putSerializable(LONGITUDE, mlongitude);
        outState.putSerializable(LATITUDE, mlongitude);

        outState.putSerializable(SHIFT_RATE, shiftRate);

        outState.putSerializable(SHIFT_DAY, isShiftDay);

        outState.putSerializable(STARTING_TIME, startTime);

        outState.putSerializable(ENDGING_TIME, endTime);

        outState.putSerializable(DAY, day);

        outState.putSerializable(DISTANCE, distance);

        outState.putSerializable(RATING, rating);

    }


    /**
     * Retrives all the saved state
     *
     * @param bundle The bublde containiing the save state
     */
    private void getDataState(Bundle bundle) {


        mlongitude = (Double) bundle.get(LONGITUDE);
        mlatitude = (Double) bundle.get(LATITUDE);
        shiftRate = (double) bundle.get(SHIFT_RATE);
        isShiftDay = (boolean) bundle.get(SHIFT_DAY);
        startTime = (int) bundle.get(STARTING_TIME);
        endTime = (int) bundle.get(ENDGING_TIME);
        day = (String) bundle.get(DAY);
        distance = (int) bundle.get(DISTANCE);
        rating = (double) bundle.get(RATING);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        googleApiClient.stopAutoManage((FragmentActivity) getActivity());
        googleApiClient.disconnect();

    }

    @Override
    public void onPause() {
        super.onPause();
        googleApiClient.stopAutoManage((FragmentActivity) getActivity());
        googleApiClient.disconnect();
    }

    @Override
    public void onResume() {
        super.onResume();
        googleApiClient.connect();
    }

    /**
     * Displayes teh saved state to the txt views and seekbars
     */
    private void displaySavedData() {

        distanceSeekBar.setProgress(distance);
        distanceTextView.setText(distance + " miles");
        starTextView.setText(String.valueOf(startTime));
        endTextView.setText(String.valueOf(endTime));
        dayTextView.setText(day);

        ratingSeekBar.setProgress((int) shiftRate);
        shiftRateTextView.setText(String.valueOf(shiftRate));


    }

    //// TODO: 07/03/2017 Set the rating
    private void setDefaults() {


        distance = 1;
        startTime = 10;
        endTime = 10;
        day = "Monday";
        isShiftDay = true;
        shiftRate = 50;
        specialtiesOrEvents = "";
        rating = 1;
        // display the seekbars
//        distanceSeekBar.setProgress(distance);
    //    ratingSeekBar.setProgress((int) shiftRate);

    }


    //// TODO: 09/03/2017 Since I am intialising it in a fragment I should not initailise it again --
    private void initialise() {


        if (googleApiClient == null) {
            googleApiClient = new GoogleApiClient
                    .Builder(getActivity())
                    .addApi(Places.GEO_DATA_API)
                    .addApi(LocationServices.API)
                    .addApi(Places.PLACE_DETECTION_API)
                    .enableAutoManage((FragmentActivity) getActivity(), this)
                    .build();

            //googleApiClient.connect();
        }


    }

    /**
     * This method will call the placed api to get the long and lat from a given placeId
     *
     * @param placeId The placeId from a Place given from the GoogleApi
     */
    public void getLocationSelected(String placeId) {


        Places.GeoDataApi.getPlaceById(googleApiClient, placeId)
                .setResultCallback(new ResultCallback<PlaceBuffer>() {
                    @Override
                    public void onResult(PlaceBuffer places) {
                        if (places.getStatus().isSuccess()) {
                            // get the first place from the guess list
                            final Place myPlace = places.get(0);
                            LatLng queriedLocation = myPlace.getLatLng();
                            mlongitude = queriedLocation.longitude;
                            mlatitude = queriedLocation.latitude;
                            constuctQuery();
                            p.setVisibility(ProgressBar.INVISIBLE);
                        }
                        // release the buffer when done
                        places.release();
                    }
                });


    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.globalContext = context;
        hide = (Hide) context;
        Log.d("ContextAttatch", "I have been attatched");

    }


    public void setSearchListener() {

        // TODO: 04/03/2017 Some serious bugs are in this method

        floatingSearchView.setOnMenuItemClickListener(new FloatingSearchView.OnMenuItemClickListener() {
            @Override
            public void onActionMenuItemSelected(MenuItem item) {

                if (TestConstants.CONSTANT == 1) {
                    mlongitude = 2.0;
                    mlatitude = 2.0;
                    constuctQuery();
                    p.setVisibility(ProgressBar.INVISIBLE);
                } else {

                    if (item.getItemId() == R.id.search) {

                        // this implies that long and lat have to be found

                        if (placeObject != null) {

                            recyclerAdapter.clearAllData();

                            getLocationSelected(placeObject.getPlaceID());

                        } else {

                            // I do not need to get the location from the placeId as I have it from the Google activity
                            if (mlatitude != null && mlongitude != null) {

                                recyclerAdapter.clearAllData();
                                constuctQuery();
                                p.setVisibility(ProgressBar.INVISIBLE);
                            } else {

                                Toast.makeText(globalContext, "Please enter a location", Toast.LENGTH_SHORT).show();
                            }
                        }

                    } else if (item.getItemId() == R.id.show_full_search) {


                        startMapActivity();
                    }
                }

                // add more items to bring out the navigation bar and add a listener to the nav bar

            }
        });


        floatingSearchView.setOnBindSuggestionCallback(new SearchSuggestionsAdapter.OnBindSuggestionCallback() {

            @Override
            public void onBindSuggestion(View suggestionView, ImageView leftIcon, TextView textView, SearchSuggestion item, int itemPosition) {

                textView.setTextColor(getResources().getColor(android.R.color.white));

            }
        });


    }

    /**
     * Setting the query listener for the filter view
     */
    public void setQueryListener() {


        floatingSearchView.setOnSearchListener(new FloatingSearchView.OnSearchListener() {
            @Override
            public void onSuggestionClicked(SearchSuggestion searchSuggestion) {

                resetLongLat();
                PlaceObject suggestion = (PlaceObject) searchSuggestion;
                placeObject = suggestion;

            }

            @Override
            public void onSearchAction(String currentQuery) {

            }
        });


        floatingSearchView.setOnQueryChangeListener(new FloatingSearchView.OnQueryChangeListener() {
            /**
             *
             * @param oldQuery The old query
             * @param newQuery The new Query being entered
             */
            @Override
            public void onSearchTextChanged(String oldQuery, final String newQuery) {

                //get suggestions based on newQuery
                final List<PlaceObject> searchSuggestionList = new ArrayList<>();

                // create an async pending result
                PendingResult<AutocompletePredictionBuffer> result =
                        Places.GeoDataApi.getAutocompletePredictions(googleApiClient, newQuery,
                                new LatLngBounds(GLOABL_EAST, GLOBAL_WEST), null);

                // add a callback for when the async work is done
                result.setResultCallback(new ResolvingResultCallbacks<AutocompletePredictionBuffer>(getActivity(), 0) {
                    @Override
                    public void onSuccess(@NonNull AutocompletePredictionBuffer autocompletePredictions) {

                        // loop over all the predictions and add them to the search list
                        for (final AutocompletePrediction prediction : autocompletePredictions) {

                            prediction.freeze();

                            searchSuggestionList.add(new PlaceObject(prediction.getFullText(null).toString(), prediction.getPlaceId()) {


                                @Override
                                public String getBody() {
                                    return this.getLocationText();
                                }
                            });
                        }


                        // swap out suggestions
                        floatingSearchView.swapSuggestions(searchSuggestionList);

                        autocompletePredictions.release();

                    }

                    @Override
                    public void onUnresolvableFailure(@NonNull Status status) {

                        Log.d("failedToConnectMap", "failed");

                    }
                });

            }

        });

    }


    private void resetLongLat() {
        mlongitude = null;
        mlatitude = null;
    }


    /**
     * This starts a google maps activity and goes into there work flow
     */

    private void startMapActivity() {

        PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();

        try {
            startActivityForResult(builder.build(getActivity()), PLACE_PICKER_REQUEST);
        } catch (GooglePlayServicesRepairableException e) {
            e.printStackTrace();
        } catch (GooglePlayServicesNotAvailableException e) {
            e.printStackTrace();
        }


    }


    /**
     * This will be called when activity has a result to give
     *
     * @param requestCode The request code of the started activity
     * @param resultCode  The results code to signify a useless or viable result
     * @param data        The data given back from the started activity
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == PLACE_PICKER_REQUEST) {
            if (resultCode == RESULT_OK) {

                // get the place
                Place place = PlacePicker.getPlace(data, globalContext);

                mlongitude = place.getLatLng().longitude;
                mlatitude = place.getLatLng().latitude;

                floatingSearchView.setSearchText(place.getAddress());
                String toastMsg = String.format("Place: %s", place.getName());
                Toast.makeText(globalContext, toastMsg, Toast.LENGTH_LONG).show();
            }
        }

    }

    private void constuctQuery() {

        p.setVisibility(ProgressBar.VISIBLE);
        runSelectedUserQuery(currentUser, isShiftDay);

    }

    /**
     * This method allows me to overide the navigation listener for all the seekbars
     *
     * @param seekbars The arrya of seekbars in this activity
     */
    private void addOverideSeekListener(SeekBar... seekbars) {

        // loop through the seekbars and overide them 
        for (SeekBar seekbar : seekbars) {

            seekbar.setOnTouchListener(new ListView.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    int action = event.getAction();
                    switch (action) {
                        case MotionEvent.ACTION_DOWN:
                            // Disallow Drawer to intercept touch events.
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                            break;

                        case MotionEvent.ACTION_UP:
                            // Allow Drawer to intercept touch events.
                            v.getParent().requestDisallowInterceptTouchEvent(false);
                            break;
                    }

                    // Handle seekbar touch events.
                    v.onTouchEvent(event);
                    return true;
                }
            });


        }


    }


    /**
     * This method will create the pop an inflate the pop up
     * The pop up will have a recycler view
     * Is everything created locally????
     */
    public void inflatePopUp() {

        final View tagsPopView = LayoutInflater.from(globalContext).inflate(R.layout.tag_popup_layout, null, false);

        RecyclerView recyclerView = (RecyclerView) tagsPopView.findViewById(R.id.recyclerView_tags);

        EditText editText = (EditText) tagsPopView.findViewById(R.id.enter_tags);

        ImageView closePopupButton = (ImageView) tagsPopView.findViewById(R.id.close_popup_button);

        recyclerView.setVerticalScrollBarEnabled(true);




        //  setting a grid layout with a column count of 4


        final TagsRecyclerAdapter tagsRecyclerAdapter = new TagsRecyclerAdapter(specialityTags, this);

        editText.addTextChangedListener(new TextWatcherAdapter() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                tagsRecyclerAdapter.replaceList(getFilteredTagList(s.toString().trim()));

            }
        });
        recyclerView.setLayoutManager(new GridLayoutManager(globalContext, 2));
        recyclerView.setAdapter(tagsRecyclerAdapter);


        tagsPopWindow = new PopupWindow(tagsPopView, LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);

        tagsPopWindow.setFocusable(true);
        tagsPopWindow.update();

        // Set an elevation value for popup window
        // Call requires API level 21
        if (Build.VERSION.SDK_INT >= 21) {
            tagsPopWindow.setElevation(5.0f);
        }

        closePopupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tagsPopWindow.dismiss();
            }
        });

        tagsPopWindow.showAtLocation(tagsPopView, Gravity.NO_GRAVITY, 0, 0);

    }


    @Override
    public void incomingTag(int position, Tag tag) {

        this.selectedTags.put(position, tag);

    }

    @Override
    public void removeTag(int position) {

        this.selectedTags.remove(position);

    }


    // todo this method should me moved to utils

    /**
     * @param query
     * @return
     */
    public ArrayList<Tag> getFilteredTagList(final String query) {


        ArrayList<Tag> filteredList = new ArrayList<>();

        for (Tag tag : specialityTags) {
            if (tag.getName().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(tag);
            }
        }
        return filteredList;


    }

    public String getConcatonatedSpecialties() {

        ArrayList<String> strings = new ArrayList<>();

        // loop through the key set and put it in the strings
        for (int value : selectedTags.keySet()) {
            strings.add(selectedTags.get(value).getName());
        }

        // sorting the array
        Collections.sort(strings, new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
                return s1.compareToIgnoreCase(s2);
            }
        });

        StringBuilder stringBuilder = new StringBuilder();

        // building the array
        for (String special : strings) {
            stringBuilder.append(special + "/");
        }


        specialtiesOrEvents = stringBuilder.toString();

        return specialtiesOrEvents;

    }


    // TODO: 09/03/2017 Add the getContacatonated specialities when the time is right
    private void runSelectedUserQuery(User user, boolean isShiftDay) {

        if (isShiftDay) {
            user.search(
                    mlatitude,
                    mlongitude,
                    distance,
                    rating,
                    shiftRate,
                    0,
                    getConcatonatedSpecialties(),
                    day,
                    startTime,
                    endTime,
                    recyclerAdapter);
        } else {
            user.search(
                    mlatitude,
                    mlongitude,
                    distance,
                    rating,
                    0,
                    shiftRate,
                    getConcatonatedSpecialties(),
                    day,
                    startTime,
                    endTime,
                    recyclerAdapter);
        }

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.one_star:
                setFloatingActionButtonsBackground(1);
                break;
            case R.id.two_stars:
                setFloatingActionButtonsBackground(2);
                break;
            case R.id.three_stars:
                setFloatingActionButtonsBackground(3);
                break;
            case R.id.four_stars:
                setFloatingActionButtonsBackground(4);
                break;
            case R.id.five_stars:
                setFloatingActionButtonsBackground(5);

                break;

        }
    }

    private void setFloatingActionButtonsBackground(int rating) {

        if(rating == this.rating){
            ratingButtons[rating-1].setImageResource(R.drawable.empty_glass);
            this.rating -=1;
        }else {

            this.rating = rating;

            for (int i = 0; i <= rating - 1; i++) {
                ratingButtons[i].setImageResource(R.drawable.full_glass);
            }

            for (int i = ratingButtons.length-1; i >= rating; i--) {
                ratingButtons[i].setImageResource(R.drawable.empty_glass);

            }

        }

    }

}
