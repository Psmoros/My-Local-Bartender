package com.example.beatrice.mylocalbartender.controller.view_holders;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.chauthai.swipereveallayout.SwipeRevealLayout;
import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.activity.BartenderProfile;
import com.example.beatrice.mylocalbartender.controller.ProfilePicManager;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.activity.MessagingActivity;
import com.example.beatrice.mylocalbartender.model.Bartender;
import com.example.beatrice.mylocalbartender.utils.Keys;
import com.example.beatrice.mylocalbartender.utils.MyFlowLayout;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

/**
 * Created by Umar on 17/03/2017.
 * This class holds all the information the is displayed when a bartender is retrieved from the server
 */


public class BartenderViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {


    private View root;
    private SwipeRevealLayout swipeLayout;
    private ImageButton contactsButton;
    private TextView nameValue;
    private ImageView profilePic;
    private ImageView bartenderRating;
    private TextView shiftRateDaily;
    private TextView shiftRateNightly;
    private MyFlowLayout flowLayout;
    private Bartender bartender;
    private ImageView viewProfile;




    public BartenderViewHolder(View itemView) {

        super(itemView);

        profilePic = (ImageView) itemView.findViewById(R.id.profile_pic);
        swipeLayout = (SwipeRevealLayout) itemView.findViewById(R.id.root_profile_layout);

        nameValue = (TextView) itemView.findViewById(R.id.name_field);
        contactsButton = (ImageButton) itemView.findViewById(R.id.contactsButton);
        flowLayout = (MyFlowLayout) itemView.findViewById(R.id.specialities_flow_layout);
        shiftRateDaily = (TextView) itemView.findViewById(R.id.shift_rate_daily);
        shiftRateNightly = (TextView) itemView.findViewById(R.id.shift_rate_nightly);
        bartenderRating = (ImageView) itemView.findViewById(R.id.rating_value);

        viewProfile = (ImageView) itemView.findViewById(R.id.view_profile_button);

    }

    public void bind(final Bartender bartender, final Activity activity) {

        flowLayout.removeAllViews();

        this.bartender  = bartender;

        final FirebaseManagement m = FirebaseManagement.getInstance();

        contactsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseManagement.getInstance().addContact(m.currentUser.getUid(),
                        m.currentUser.getFirstName() + " " + m.currentUser.getLastName(),
                        bartender.getUid(),
                        bartender.getFirstName() + " " + bartender.getLastName());
                Intent intent = new Intent(v.getContext(), MessagingActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("Contact_ID", bartender.getUid());
                intent.putExtra("Contact_Name",bartender.getFirstName() + " " + bartender.getLastName());
                v.getContext().startActivity(intent);
            }
        });

        viewProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(v.getContext(),BartenderProfile.class);
                intent.putExtra(Keys.BARTENDER,bartender);
                intent.putExtra("Previous Act", "Bartender View Holder");
                v.getContext().startActivity(intent);

            }
        });


        swipeLayout.setOnClickListener(this);

        nameValue.setText(bartender.getFirstName());

        shiftRateNightly.setText(String.valueOf(bartender.getNightlyRate()));

        shiftRateDaily.setText(String.valueOf(bartender.getHourlyRate()));

        FirebaseStorage storage = FirebaseStorage.getInstance();

        StorageReference storageRef = storage.getReference();

        StorageReference profilePicRef = storageRef.child("ProfilePictures");

        ProfilePicManager.setPicFromDB(profilePicRef, activity,profilePic,bartender.getUid(), true, false);

        //setbackGroundRating(bartender,activity);

        for (String speciality:bartender.getSpecialities().split("/")) {
            if(!speciality.isEmpty())
                 flowLayout.addToLayout(speciality,bartender,false);
        }

        setbackGroundRating(bartender,activity);

    }

    private void setbackGroundRating(Bartender bartender,Activity activity){

        if(bartender.getRate() == 0.0)
            bartenderRating.setBackground(activity.getResources().getDrawable(R.drawable.glass_rating_0));
        else if(Math.floor(bartender.getRate()) <= 1.0)
            bartenderRating.setBackground(activity.getResources().getDrawable(R.drawable.glass_rating_1));
        else if(bartender.getRate() > 1.0 && Math.floor(bartender.getRate()) <= 1.5)
            bartenderRating.setBackground(activity.getResources().getDrawable(R.drawable.glass_rating_15));
        else if(bartender.getRate() > 1.5 && Math.floor(bartender.getRate()) <= 2.0)
            bartenderRating.setBackground(activity.getResources().getDrawable(R.drawable.glass_rating_2));
        else if(bartender.getRate() > 2.0 && Math.floor(bartender.getRate()) <= 2.5)
            bartenderRating.setBackground(activity.getResources().getDrawable(R.drawable.glass_rating_25));
        else if(bartender.getRate() > 2.5 && Math.floor(bartender.getRate()) <= 3.0)
            bartenderRating.setBackground(activity.getResources().getDrawable(R.drawable.glass_rating_3));
        else if(bartender.getRate() > 3.0 && Math.floor(bartender.getRate()) <= 3.5)
            bartenderRating.setBackground(activity.getResources().getDrawable(R.drawable.glass_rating_35));
        else if(bartender.getRate() > 3.5 && Math.floor(bartender.getRate()) <= 4.0)
            bartenderRating.setBackground(activity.getResources().getDrawable(R.drawable.glass_rating_4));
        else if(bartender.getRate() > 4.0 && Math.floor(bartender.getRate()) <= 4.5)
            bartenderRating.setBackground(activity.getResources().getDrawable(R.drawable.glass_rating_45));
        else if(bartender.getRate() > 4.5 && Math.floor(bartender.getRate()) <= 5.0)
            bartenderRating.setBackground(activity.getResources().getDrawable(R.drawable.glass_rating_5));
        
    }


    @Override
    public void onClick(View v) {

        Intent intent = new Intent(v.getContext(), BartenderProfile.class);
        intent.putExtra(Keys.BARTENDER,bartender);
        v.getContext().startActivity(intent);
    }

    public SwipeRevealLayout getSwipeLayout(){
        return swipeLayout;
    }

}
