package com.example.beatrice.mylocalbartender.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.controller.OnSwipeTouchListener;
import com.example.beatrice.mylocalbartender.controller.interfaces.Hide;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.fragments.ContactFragment;
import com.example.beatrice.mylocalbartender.fragments.FullSearchFragment;
import com.example.beatrice.mylocalbartender.fragments.JobsFragment;
import com.example.beatrice.mylocalbartender.fragments.WorkFragment;
import com.example.beatrice.mylocalbartender.model.User;
import com.example.beatrice.mylocalbartender.model.UserType;
import com.example.beatrice.mylocalbartender.utils.Colours;
import com.example.beatrice.mylocalbartender.utils.alertDialog.GeneralDialogFragment;
import com.google.firebase.auth.FirebaseAuth;

//import com.braintreepayments.api.dropin.DropInActivity;
//import com.braintreepayments.api.dropin.DropInResult;


/**
 * This class is the main fragment holder that displys the bottom navigation bar
 */
public class MainNavigationActivity extends FragmentActivity implements Hide, GeneralDialogFragment.OnDialogFragmentClickListener {

    private User currentUser;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseManagement m = FirebaseManagement.getInstance().getInstance();

        currentUser = m.currentUser;
        m.pushNotification();

        RelativeLayout mainlayout = (RelativeLayout) findViewById(R.id.activity_main);
        mainlayout.setOnTouchListener(new OnSwipeTouchListener(this) {
            @Override
            public void onSwipeRight() {
                Intent intent = new Intent(MainNavigationActivity.this, CustomQrActivity.class);
                startActivity(intent);
            }
        });
        if(currentUser.getBgColorPref()!=null && !currentUser.getBgColorPref().isEmpty() && !currentUser.getBgColorPref().equals(" ")) {
            Colours.backgroundColour = currentUser.getBgColorPref();
            mainlayout.setBackgroundColor(Color.parseColor(Colours.backgroundColour));
                    Colours.isDefault = false;
            }

        Intent i;
        int f;
       try{
           i = getIntent();
           if(i != null) {
               f = (int) i.getExtras().get("fragmentOption");
               if (f == 2) {
                   android.app.Fragment fragment = new ContactFragment();
                   getFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).commit();

               }
           }
       } catch(Exception e){

               android.app.Fragment fragment = new FullSearchFragment();
               getFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).commit();
           }



        // the main navigation menu should already have the search feed inflated

        // the search feed should inflate and if there is nothign run a quert

        bottomNavigationView = (BottomNavigationView)
                findViewById(R.id.bottom_navigation);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);


        bottomNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {


                        Fragment fragment = null;

                        switch (item.getItemId()) {
                            case R.id.action_home:

                                android.app.Fragment searchFragment = new FullSearchFragment();
                                getFragmentManager().beginTransaction().replace(R.id.fragment_container, searchFragment).commit();

                                break;

                            case R.id.action_dashboard:

                                if(FirebaseManagement.getInstance().currentUser.getUserType() == UserType.ORGANISER) {
                                    android.app.Fragment workFragment = new WorkFragment();
                                    getFragmentManager().beginTransaction().replace(R.id.fragment_container, workFragment).commit();

                                }else{
                                    android.app.Fragment jobFragment = new JobsFragment();
                                    getFragmentManager().beginTransaction().replace(R.id.fragment_container, jobFragment).commit();
                                }




                                break;

                            case R.id.action_profile:
                                Intent profileIntent = checkBartender()? new Intent(MainNavigationActivity.this, BartenderProfileSettings.class)
                                        :new Intent(MainNavigationActivity.this, OrganiserProfileSettings.class);
                                startActivity(profileIntent);
                                break;

                            case R.id.action_messages:

                                android.app.Fragment contactFragment = new ContactFragment();
                                getFragmentManager().beginTransaction().replace(R.id.fragment_container, contactFragment).commit();

                                break;
                        }

                        //// TODO: 01/03/2017 Remove this if method when the time is right
                        if(fragment!=null)
                            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).commit();
                        return true;
                    }
                });
    }

    @Override
    public void onBackPressed() {
        showLogOutDialog();
    }

    private boolean checkBartender(){
        if(currentUser.getUserType() == UserType.BARTENDER){
            return true;
        }
      return false;
    }

    @Override
    public void hide() {
        bottomNavigationView.setVisibility(View.GONE);
    }

    @Override
    public void reveal() {
        bottomNavigationView.setVisibility(View.VISIBLE);
    }

    private  void showLogOutDialog(){
        GeneralDialogFragment setUserDialogFragment = GeneralDialogFragment.newInstance("Logging out", "Do you want to log out ?", "No", "Yes");
        setUserDialogFragment.show(getSupportFragmentManager(),"dialog");
    }

    @Override
    public void onAlertDialogLeftClicked(GeneralDialogFragment dialog) {
        dialog.dismiss();
    }

    @Override
    public void onAlertDialogRightClicked(GeneralDialogFragment dialog) {
        FirebaseManagement.getInstance().currentUser = null;
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(MainNavigationActivity.this, LoginActivity1.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        dialog.dismiss();
        startActivity(intent);
        finish();
    }

/*

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // result returned from the the paypal drop in ui
        if (requestCode == 401) {

            if (resultCode == Activity.RESULT_OK) {
                DropInResult result = data.getParcelableExtra(DropInResult.EXTRA_DROP_IN_RESULT);
                //serverInterface.postNonceToServer(result.getPaymentMethodNonce().getNonce());

            } else if (resultCode == Activity.RESULT_CANCELED) {

                Log.v("result", "failed");
                // the user canceled
                // TODO ADD TOAST
            } else {
                //// TODO: 13/03/2017 ADD TOAST
                Exception error = (Exception) data.getSerializableExtra(DropInActivity.EXTRA_ERROR);
                Log.v("result", error.toString());
            }
        }
    }

*/



}
