package com.example.beatrice.mylocalbartender.controller.interfaces;

import android.app.Activity;
import android.app.Fragment;
import android.support.annotation.VisibleForTesting;
import android.util.Log;

import com.braintreepayments.api.dropin.DropInRequest;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.model.BaseRequest;
import com.example.beatrice.mylocalbartender.model.Organiser;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

/**
 * Created by Umar on 16/03/2017.
 * This class represents a Server Face that will be used to contact the server asynchronously for tokens
 *
 */

public class ServerFace {


    private static final int REQUEST_CODE = 401;
    private String clientToken;
    private Activity hostingActivity;
    private BaseRequest baseRequest;
    private Organiser organiser;
    private AsyncHttpClient client;
    private Fragment hostingFragment;



    public ServerFace(Fragment hostingFragment, Organiser organiser) {

        this.hostingFragment = hostingFragment;
        this.organiser = organiser;
        this.client = new AsyncHttpClient();


    }



    @VisibleForTesting
    protected ServerFace(Activity activity, Organiser organiser, AsyncHttpClient client){
        this.hostingActivity  = activity;
        this.organiser = organiser;
        this.client = client;
    }



    public void getTokenFromServer(){

        final AsyncHttpClient client = new AsyncHttpClient();
        client.get("http://mlb-server.herokuapp.com/client_token", new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, String responseString, Throwable throwable) {
                Log.v("responseString", responseString);
                // // TODO: 13/03/2017 Make toast
            }

            @Override
            public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, String responseString) {
                clientToken = responseString;
                onBraintreeSubmit(clientToken); // then start the brain submit
                Log.d("response", responseString);

            }
        });

    }


    public void onBraintreeSubmit(String token) {

        DropInRequest dropInRequest = new DropInRequest()
                .clientToken(token);
        hostingFragment.startActivityForResult(dropInRequest.getIntent(hostingFragment.getActivity()), REQUEST_CODE);
    }

    /**
     * This posts nonce to the server once the PayPal flow has been completed
     * @param nonce The nonce that needs to be sent to server
     */
    public void postNonceToServer(String nonce) {

        client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        params.put("payment_method_nonce", nonce);

        // this will be the real server of the address
        client.post("http://mlb-server.herokuapp.com/checkout", params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {

                Log.v("success", headers.toString());

                //// TODO: 13/03/2017 Get the actual organiser


                // We post it to the server  --

                Organiser organiser = (Organiser) FirebaseManagement.getInstance().currentUser;
                organiser.acceptRequest(true,baseRequest);

            }

            @Override
            public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {

                Log.v("fail", headers.toString());

                // TODO: 16/03/2017 Display toast

            }
        });
    }

    public void setBaseRequest(BaseRequest baseRequest){
        this.baseRequest = baseRequest;

    }

    public BaseRequest getBaseRequest(){
      return baseRequest;
    }

}
