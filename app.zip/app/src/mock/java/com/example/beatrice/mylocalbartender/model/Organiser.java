package com.example.beatrice.mylocalbartender.model;


import android.app.Activity;
import android.support.annotation.VisibleForTesting;
import android.view.View;

import com.example.beatrice.mylocalbartender.controller.interfaces.ResultsInterface;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.utils.Keys;
import com.example.beatrice.mylocalbartender.utils.MyLinearLayout;
import com.example.beatrice.mylocalbartender.utils.async.AsyncEventLocation;
import com.firebase.geofire.GeoFire;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Organiser extends User {

    private String professionalPosition, businessName, businessBio;
    private DatabaseReference root;
    private ArrayList<Event> selectedEvents;

    //TO DO
    //Add setter and getter for background picture

    public Organiser() {
        super();
    }


    public Organiser(String email, String uid) {
        super(email, uid);
    }

    public Organiser(String firstName, String lastName, String email, String uid) {
        super(firstName, lastName, email, uid);

    }


    /**
     * Returns value of professionalPosition
     *
     * @return
     */
    public String getProfessionalPosition() {
        return professionalPosition;
    }

    /**
     * Sets new value of professionalPosition
     *
     * @param
     */
    public void setProfessionalPosition(String professionalPosition) {
        this.professionalPosition = professionalPosition;
    }


    /**
     * Returns value of businessName
     *
     * @return
     */
    public String getBusinessName() {
        return businessName;
    }

    /**
     * Sets new value of businessName
     *
     * @param
     */
    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    /**
     * Returns value of businessBio
     *
     * @return
     */
    public String getBusinessBio() {
        return businessBio;
    }

    /**
     * Sets new value of businessBio
     *
     * @param
     */
    public void setBusinessBio(String businessBio) {
        this.businessBio = businessBio;
    }


    public void fetchEvents(final MyLinearLayout layout, final View window) {

        layout.addToLayout(new Event(), Organiser.this, window);
    }

    /**
     * This fetches public or private events that an organiser has
     * @param eventResultsInterface The interface used to display the results
     * @param isPublicEvent Is the method public or private
     */
    public void fetchEvents(final ResultsInterface<Event> eventResultsInterface, boolean isPublicEvent){

        eventResultsInterface.addToList(new Event());


    }

    public void fetchEventsFromDB(final ResultsInterface<Event> eventResultsInterface, final boolean isPublicEvent){
        root = FirebaseDatabase.getInstance().getReference();

        root.child("Events").child(getUid()).orderByChild("eventPublic").equalTo(isPublicEvent)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        if(dataSnapshot.getValue()!=null) {
                            for (DataSnapshot snap : dataSnapshot.getChildren()) {
                                Event event = snap.getValue(Event.class);
                                eventResultsInterface.addToList(event);
                            }
                        }else{
                            eventResultsInterface.notifyEmptyDataSet();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        eventResultsInterface.notifyEmptyDataSet();
                    }
                });

    }


    public void addToSelectedEvents(Event event){
        selectedEvents.add(event);
    }

    public void eraseFromSelectedEvents(Event event){
        selectedEvents.remove(event);
    }

    public ArrayList<Event> fetchSelectedEvents(){
        return selectedEvents;
    }

    // TODO: 10/03/2017 Make a white list that a user can remove himself from -- test with security rules

    /**
     * An event cannot be deleted if it is not fully unlocked
     * When an organiser cancels an event -- The event is deleted from the database
     * and all associated booking requests are set STATUS: REJECTED
     *
     * @param event The event to be cancelled
     */
    public boolean cancelEvent(Event event) {

        if (canDelete(event)) {

            cancel(event);
            return true;
        }

        return false;
    }


    public void acceptRequest(boolean accept, BaseRequest baseRequest) {

    }





    /**
     * An event can only be deleted if the required bartenders is 0
     *
     * @param event The event to be deletd
     * @return whether the bartneders are 0
     */
    private boolean canDelete(Event event) {
        return event.getRequiredBartenders() == 0;
    }


    public void cancel(Event event) {

        }

    public Event createEvent(int numberBartenders,
                             boolean isDayEvent,
                             boolean isPublic,
                             final Activity activity,
                             String... details) {




        final Event event = new Event(
                "2",
                details[0],
                details[1],
                details[2],
                details[3],
                details[4],
                details[5],
                getUid(),
                Double.valueOf(details[6]),
                numberBartenders,
                isDayEvent,
                isPublic
        );

        return event;

    }

    @VisibleForTesting
    protected void addLocationAsync(String location, String eventId){

        new AsyncEventLocation(
                new GeoFire(FirebaseDatabase.getInstance().getReference().child(Keys.EVENT_GEOFIRE_REF)),eventId,this.getUid())
                .execute(location);

    }


}

