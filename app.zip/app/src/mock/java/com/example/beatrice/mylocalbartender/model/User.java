package com.example.beatrice.mylocalbartender.model;


import com.example.beatrice.mylocalbartender.controller.interfaces.ResultsInterface;
import com.firebase.geofire.GeoQuery;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.Serializable;

public class User implements Serializable {
    // TODO: 02/03/2017 Set persistence in this data
    // TODO: 04/03/2017 Change the rating < to what it was 
    private FirebaseDatabase database;
    private DatabaseReference root;
    private String firstName, lastName, email, gender, location, summary, picURI, doB, uid, phone;
    private String bgColorPref;
    private double rate;
    private UserType userType;
    private GeoQuery geoQuery;


    public User() {

    }

    public User(String email, String uid) {
        this.uid = uid;
        this.email = email;
        database = FirebaseDatabase.getInstance();
        root = database.getReference();
    }

    public User(String firstName, String lastName, String email, String uid) {
        this.uid = uid;
        this.firstName = firstName;
        this.email = email;
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String toString() {
        return "User " + email + " | Username : " + firstName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getPicURI() {
        return picURI;
    }

    public void setPicURI(String picURI) {
        this.picURI = picURI;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public String getDoB() {
        return doB;
    }

    public void setDoB(String doB) {
        this.doB = doB;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    public UserType getUserType() {
        return userType;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getBgColorPref() {
        return bgColorPref;
    }

    public void setBgColorPref(String bgColorPref) {
        this.bgColorPref = bgColorPref;
    }


    /**
     * Method to Search for another user or an event, depending on all of those queries.
     * Depending on the userType : specify the right GeoFire node, specify the right ResultsInterface (ResultsInterface<User> or ResultsInterface<Event>)
     * Default value for :
     * rate : 5
     * radius : 5
     * nightlyRate : 0
     * hourlyRate : 0
     * speciality : null
     * startTime : 24
     * endTime : 24
     *
     * @param latitude
     * @param longitude
     * @param radius
     * @param rate
     * @param nightlyRate
     * @param hourlyRate
     * @param speciality
     * @param day
     * @param startTime
     * @param endTime
     * @return
     */
    public void search(double latitude, double longitude, double radius, final double rate, final double nightlyRate, final double hourlyRate, final String speciality, String day, int startTime, int endTime, ResultsInterface searchQueryInterface) {

        for(int i =0; i<3; i++){


            if(userType == UserType.ORGANISER){
                Bartender user = new Bartender("Name "+i, "LastName "+i, "Email "+i, "uid");
                searchQueryInterface.addToList(user);


            }
            else if (userType == UserType.BARTENDER) {
                   Event event = new Event("Name " + i, "LastName " + i, "Email " + i, "uid","date", "10", "22", "uid", 10, 3, true, true);
                     searchQueryInterface.addToList(event);
            }


        }
    }

    // TODO: 02/03/2017 Dispose of the child listener when done
    // TODO: 09/03/2017 Remove the instantiation of root when done

    /**
     * This method retrieves the completed jobs from the database and addded to a results interface
     * @param resultsInterface The interface to be added
     * @param orderByChild The first query
     */
    public void fetchCompletedJobs(final ResultsInterface resultsInterface, String orderByChild, String equalTo) {


            Event event = new Event(
                    "1",
                    "df",
                    "d",
                    ",",
                    ",",
                    ",",
                    ",",
                    ",",
                    2,
                    1,
                    true,
                    true
            );


            resultsInterface.addToList(new Job("1",event,"test","test","test","test","test","test","test"));

    }

    public void fetchPendingJobs(final ResultsInterface<BaseRequest> resultsInterface){


        Event event = new Event(
                "1",
                "df",
                "d",
                ",",
                ",",
                ",",
                ",",
                ",",
                2,
                1,
                true,
                true
        );

        BaseRequest b = new BaseRequest("3",false,event,"10","1","3","e","","",1);
        resultsInterface.addToList(b);
        BaseRequest b1 = new BaseRequest("4",false,event,"10","2","","","","",1);
        resultsInterface.addToList(b1);

    }

    public void loadContacts(final ResultsInterface<Contacts> contactsResultsInterface){


        contactsResultsInterface.addToList(new Contacts("1234","FDDGF"));

    }









}



