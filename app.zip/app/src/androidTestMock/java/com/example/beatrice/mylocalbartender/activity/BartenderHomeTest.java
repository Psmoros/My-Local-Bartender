package com.example.beatrice.mylocalbartender.activity;


import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.example.beatrice.mylocalbartender.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.hamcrest.core.IsInstanceOf;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.action.ViewActions.scrollTo;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;


/**
 * This class tests the bartender profile activity in the form of Espresso instrumentation testing
 */

@LargeTest
@RunWith(AndroidJUnit4.class)
public class BartenderHomeTest {

    @Rule
    public ActivityTestRule<SplashActivity> mActivityTestRule = new ActivityTestRule<>(SplashActivity.class);

    @Test
    public void bartenderHomeTest() {

        // Signing into app as organiser
        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.sign_in_Email), withText("Sign In"),
                        withParent(allOf(withId(R.id.activity_login1),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton.perform(click());

        ViewInteraction editText = onView(
                allOf(withId(R.id.emailField), isDisplayed()));
        editText.perform(replaceText("james"), closeSoftKeyboard());

        ViewInteraction editText2 = onView(
                allOf(withId(R.id.PasswordField), isDisplayed()));
        editText2.perform(replaceText("123"), closeSoftKeyboard());

        ViewInteraction button = onView(
                allOf(withId(R.id.sign_in), withText("Sign In"), isDisplayed()));
        button.perform(click());


        // Checks distance settings
        ViewInteraction seekBar = onView(
                allOf(withId(R.id.distance_seek_bar),
                        childAtPosition(
                                allOf(withId(R.id.distance_seek_bar_layout),
                                        childAtPosition(
                                                IsInstanceOf.<View>instanceOf(android.widget.RelativeLayout.class),
                                                1)),
                                0),
                        isDisplayed()));
        seekBar.check(matches(isDisplayed()));

        onView(withId(R.id.distance_text_view)).check(matches(withText("0 miles"))).check(matches(isDisplayed()));
        onView(withId(R.id.distance_text)).check(matches(withText("Distance"))).check(matches(isDisplayed()));
        onView(withId(R.id.distance_seek_bar)).check(matches(isDisplayed()));


        // Checks date and time settings
        onView(withId(R.id.date_and_time)).check(matches(withText("Date and Time")));

        ViewInteraction relativeLayout = onView(
                withId(R.id.select_start));
        relativeLayout.perform(scrollTo(), click());

        ViewInteraction button2 = onView(
                allOf(withId(R.id.cancel), withText("Cancel"),
                        withParent(allOf(withId(R.id.done_background),
                                withParent(withId(R.id.time_picker_dialog)))),
                        isDisplayed()));
        button2.perform(click());

        ViewInteraction relativeLayout2 = onView(
                withId(R.id.select_start));
        relativeLayout2.perform(scrollTo(), click());

        ViewInteraction button3 = onView(
                allOf(withId(R.id.ok), withText("OK"),
                        withParent(allOf(withId(R.id.done_background),
                                withParent(withId(R.id.time_picker_dialog)))),
                        isDisplayed()));
        button3.perform(click());

        ViewInteraction relativeLayout3 = onView(
                withId(R.id.select_end));
        relativeLayout3.perform(scrollTo(), click());

        ViewInteraction button4 = onView(
                allOf(withId(R.id.cancel), withText("Cancel"),
                        withParent(allOf(withId(R.id.done_background),
                                withParent(withId(R.id.time_picker_dialog)))),
                        isDisplayed()));
        button4.perform(click());

        ViewInteraction relativeLayout4 = onView(
                withId(R.id.select_end));
        relativeLayout4.perform(scrollTo(), click());

        ViewInteraction button5 = onView(
                allOf(withId(R.id.ok), withText("OK"),
                        withParent(allOf(withId(R.id.done_background),
                                withParent(withId(R.id.time_picker_dialog)))),
                        isDisplayed()));
        button5.perform(click());

        ViewInteraction relativeLayout5 = onView(
                allOf(withId(R.id.select_day),
                        withParent(withId(R.id.time_container))));
        relativeLayout5.perform(scrollTo(), click());

        ViewInteraction button6 = onView(
                allOf(withId(R.id.cancel), withText("Cancel"),
                        withParent(withId(R.id.done_background)),
                        isDisplayed()));
        button6.perform(click());

        ViewInteraction relativeLayout6 = onView(
                allOf(withId(R.id.select_day),
                        withParent(withId(R.id.time_container))));
        relativeLayout6.perform(scrollTo(), click());

        ViewInteraction button7 = onView(
                allOf(withId(R.id.ok), withText("OK"),
                        withParent(withId(R.id.done_background)),
                        isDisplayed()));
        button7.perform(click());


        // Checks shift rate setings
        ViewInteraction seekBar2 = onView(
                allOf(withId(R.id.shift_rate_seek_bar),
                        childAtPosition(
                                allOf(withId(R.id.shift_rate_seek_bar_container),
                                        childAtPosition(
                                                IsInstanceOf.<View>instanceOf(android.widget.RelativeLayout.class),
                                                5)),
                                0),
                        isDisplayed()));
        seekBar2.check(matches(isDisplayed()));

        onView(withId(R.id.shift_rate_text_view)).check(matches(withText("£0"))).check(matches(isDisplayed()));
        onView(withId(R.id.shift_rate)).check(matches(withText("Shift rate"))).check(matches(isDisplayed()));


        // Checks shift rate button
        ViewInteraction switchCompat = onView(
                allOf(withId(R.id.switch_compat),
                        withParent(allOf(withId(R.id.change_day),
                                withParent(withId(R.id.shift_rate_seek_bar_container))))));
        switchCompat.perform(scrollTo(), click());


        // Checks events setting
        ViewInteraction button8 = onView(
                allOf(withId(R.id.select_specialties), withText("SELECT EVENTS"),
                        withParent(withId(R.id.select_buttons))));
        button8.perform(scrollTo(), click());

        ViewInteraction imageView = onView(
                allOf(withId(R.id.close_popup_button), isDisplayed()));
        imageView.perform(click());


        // Checks search button is functional
        ViewInteraction button9 = onView(
                allOf(withId(R.id.search_inside_navigation), withText("Search"),
                        withParent(withId(R.id.select_buttons))));
        button9.perform(scrollTo(), click());


        // Checks search bar functionality
        ViewInteraction searchInputView = onView(
                allOf(withId(R.id.search_bar_text),
                        withParent(withId(R.id.search_input_parent)),
                        isDisplayed()));
        searchInputView.perform(replaceText("se11"), closeSoftKeyboard());

    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }
}
