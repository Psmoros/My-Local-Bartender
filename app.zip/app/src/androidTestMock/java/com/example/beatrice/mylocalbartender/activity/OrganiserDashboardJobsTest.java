package com.example.beatrice.mylocalbartender.activity;


import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.example.beatrice.mylocalbartender.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.hamcrest.core.IsInstanceOf;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

/**
 * This class tests the organiser dashboard jobs activity in the form of Espresso instrumentation testing
 */

@LargeTest
@RunWith(AndroidJUnit4.class)
public class OrganiserDashboardJobsTest {

    @Rule
    public ActivityTestRule<SplashActivity> mActivityTestRule = new ActivityTestRule<>(SplashActivity.class);

    @Test
    public void organiserDashboardJobsTest() throws InterruptedException {

        // Signing into app as organiser
        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.sign_in_Email), withText("Sign In"),
                        withParent(allOf(withId(R.id.activity_login1),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton.perform(click());

        ViewInteraction editText = onView(
                allOf(withId(R.id.emailField), isDisplayed()));
        editText.perform(replaceText("max"), closeSoftKeyboard());

        ViewInteraction editText2 = onView(
                allOf(withId(R.id.PasswordField), isDisplayed()));
        editText2.perform(replaceText("123"), closeSoftKeyboard());

        ViewInteraction button = onView(
                allOf(withId(R.id.sign_in), withText("Sign In"), isDisplayed()));
        button.perform(click());


        // Checks dashboard is clickable
        ViewInteraction bottomNavigationItemView = onView(
                allOf(withId(R.id.action_dashboard), isDisplayed()));
        bottomNavigationItemView.perform(click());


        // Checks tab shows correct text
        onView(withId(R.id.current_tab_title)).check(matches(isDisplayed())).check(matches(withText("Completed Jobs")));
        onView(withId(R.id.completed_jobs)).check(matches(isDisplayed()));


        // Checks buttons shown in container
        onView(withId(R.id.button_container)).check(matches(isDisplayed()));
        onView(withId(R.id.qr_code_button)).check(matches(isDisplayed()));
        onView(withId(R.id.message_button)).check(matches(isDisplayed()));


        // Checks qr code button
        ViewInteraction imageButton3 = onView(
                allOf(withId(R.id.qr_code_button),
                        withParent(withId(R.id.button_container)),
                        isDisplayed()));
        imageButton3.perform(click());

        onView(withId(R.id.alert_dialog_title)).check(matches(isDisplayed())).check(matches(withText("Scan me !")));
        onView(withId(R.id.qr_code_imageview)).check(matches(isDisplayed()));
        onView(withId(R.id.exit_popup_button)).check(matches(isDisplayed()));

        ViewInteraction imageButton4 = onView(
                allOf(withId(R.id.exit_popup_button), isDisplayed()));
        imageButton4.perform(click());


        // Checks the tab buttons
        ViewInteraction floatingActionButton = onView(
                allOf(withId(R.id.completed_jobs), isDisplayed()));
        floatingActionButton.perform(click());

        ViewInteraction floatingActionButton2 = onView(
                allOf(withId(R.id.current_jobs), isDisplayed()));
        floatingActionButton2.perform(click());
        onView(withId(R.id.current_tab_title)).check(matches(isDisplayed())).check(matches(withText("Current Jobs")));

        ViewInteraction floatingActionButton3 = onView(
                allOf(withId(R.id.pending_jobs), isDisplayed()));
        floatingActionButton3.perform(click());
        onView(withId(R.id.current_tab_title)).check(matches(isDisplayed())).check(matches(withText("Pending")));


        // Checks button shown in container
        onView(withId(R.id.action_dashboard)).check(matches(isDisplayed()));
        onView(withId(R.id.action_messages)).check(matches(isDisplayed()));


        // Checks pending jobs fragment
        ViewInteraction imageButton5 = onView(
                allOf(withId(R.id.adjust_rate_button),
                        withParent(withId(R.id.button_container)),
                        isDisplayed()));
        imageButton5.perform(click());

        onView(withId(R.id.negotiated_rate_edit_text)).check(matches(withText("2.0"))).perform(replaceText("32.0")).check(matches(isDisplayed()));
        onView(withId(R.id.alert_dialog_title)).check(matches(withText("Negotiate rate"))).check(matches(isDisplayed()));
        onView(withId(R.id.negotiate_done_button)).check(matches(withText("Done"))).check(matches(isDisplayed()));

        onView(withId(R.id.exit_popup_button)).check(matches(isDisplayed()));
        ViewInteraction imageButton6 = onView(
                allOf(withId(R.id.exit_popup_button), isDisplayed()));
        imageButton6.perform(click());

        ViewInteraction imageButton7 = onView(
                allOf(withId(R.id.adjust_rate_button),
                        withParent(withId(R.id.button_container)),
                        isDisplayed()));
        imageButton7.perform(click());

        onView(withId(R.id.negotiated_rate_edit_text)).check(matches(withText("2.0"))).perform(replaceText("32.0")).check(matches(isDisplayed()));

        ViewInteraction button2 = onView(
                allOf(withId(R.id.negotiate_done_button), withText("Done"), isDisplayed()));
        button2.perform(click());

    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }
}
