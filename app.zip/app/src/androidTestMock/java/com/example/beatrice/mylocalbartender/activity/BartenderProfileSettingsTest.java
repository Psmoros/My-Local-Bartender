package com.example.beatrice.mylocalbartender.activity;


import android.support.test.espresso.UiController;
import android.support.test.espresso.ViewAction;
import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.widget.TextView;

import com.example.beatrice.mylocalbartender.R;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onData;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.pressBack;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.pressImeActionButton;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.action.ViewActions.scrollTo;
import static android.support.test.espresso.action.ViewActions.swipeUp;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isClickable;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.isEnabled;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

/**
 * This class tests the bartender profile activity in the form of Espresso instrumentation testing
 */

@LargeTest
@RunWith(AndroidJUnit4.class)
public class BartenderProfileSettingsTest {

    @Rule
    public ActivityTestRule<SplashActivity> mActivityTestRule = new ActivityTestRule<>(SplashActivity.class);

    @Test
    public void bartenderProfileSettingsTest2() throws InterruptedException {

        // Signing into app as bartender
        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.sign_in_Email), withText("Sign In"),
                        withParent(allOf(withId(R.id.activity_login1),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton.perform(click());

        ViewInteraction editText = onView(
                allOf(withId(R.id.emailField), isDisplayed()));
        editText.perform(replaceText("james"), closeSoftKeyboard());

        ViewInteraction editText2 = onView(
                allOf(withId(R.id.PasswordField), isDisplayed()));
        editText2.perform(replaceText("123"), closeSoftKeyboard());

        ViewInteraction button = onView(
                allOf(withId(R.id.sign_in), withText("Sign In"), isDisplayed()));
        button.perform(click());


        // Check if profile setting is clickable
        ViewInteraction bottomNavigationItemView = onView(
                allOf(withId(R.id.action_profile), isDisplayed()));
        bottomNavigationItemView.perform(click());


        // Checks first and last name fields input value
        ViewInteraction appCompatEditText = onView(
                allOf(withId(R.id.edit_text_firstName), withText("Test"), isDisplayed()));
        appCompatEditText.perform(click());

        onView(withId(R.id.edit_text_firstName)).perform(replaceText("Testing"), closeSoftKeyboard()).check(matches(withText("Testing")));

        onView(withId(R.id.edit_text_lastName)).perform(replaceText("Testing"), closeSoftKeyboard()).check(matches(withText("Testing")));


        // Checks email field input value
       ViewInteraction appCompatEditText4 = onView(
                allOf(withId(R.id.edit_text_email), withText("Email"), isDisplayed()));
        appCompatEditText4.perform(click());

        onView(withId(R.id.edit_text_email)).perform(replaceText("test@gmail.com"), closeSoftKeyboard()).check(matches(withText("test@gmail.com")));


        // Checks change password button functionality
        ViewInteraction appCompatButton2 = onView(
                allOf(withId(R.id.change_password_button), withText("CHANGE PASSWORD"), isDisplayed()));
        appCompatButton2.perform(click());

        onView(withId(R.id.alert_dialog_title)).check(matches(withText("Change password")));

        onView(withId(R.id.alert_dialog_content)).check(matches(withText("Are you sure you want to change your password ?")));

        ViewInteraction appCompatButton3 = onView(
                allOf(withId(R.id.alert_dialog_right_button), withText("Yes"), isDisplayed()));

        ViewInteraction appCompatButton4 = onView(
                allOf(withId(R.id.alert_dialog_left_button), withText("No"), isDisplayed()));
        appCompatButton4.perform(click());


        // Checks phone field input value
        ViewInteraction appCompatEditText6 = onView(
                allOf(withId(R.id.edit_text_phone), isDisplayed()));
        appCompatEditText6.perform(replaceText("999"), closeSoftKeyboard());


        // Checks gender field button is clickable and image bitmap are changed
        onView(withId(R.id.male_button)).check(matches(allOf( isEnabled(), isClickable()))).perform(
                new ViewAction() {
                    @Override
                    public Matcher<View> getConstraints() {
                        return isEnabled(); // no constraints, they are checked above
                    }

                    @Override
                    public String getDescription() {
                        return "click male button";
                    }

                    @Override
                    public void perform(UiController uiController, View view) {
                        view.performClick();
                    }
                }
        );

        onView(withId(R.id.profile_settings_profile_picture_button)).check(matches(isDisplayed()));


        onView(withId(R.id.female_button)).check(matches(allOf( isEnabled(), isClickable()))).perform(
                new ViewAction() {
                    @Override
                    public Matcher<View> getConstraints() {
                        return isEnabled(); // no constraints, they are checked above
                    }

                    @Override
                    public String getDescription() {
                        return "click female button";
                    }

                    @Override
                    public void perform(UiController uiController, View view) {
                        view.performClick();
                    }
                }
        );


        onView(withId(R.id.edit_text_dob)).check(matches(allOf( isEnabled(), isClickable()))).perform(
                new ViewAction() {
                    @Override
                    public Matcher<View> getConstraints() {
                        return isEnabled(); // no constraints, they are checked above
                    }

                    @Override
                    public String getDescription() {
                        return "click female button";
                    }

                    @Override
                    public void perform(UiController uiController, View view) {
                        view.performClick();
                    }
                }
        );


        // Checks dob text field
        onView(withId(R.id.edit_text_dob)).check(matches(allOf( isEnabled(), isClickable()))).perform(
                new ViewAction() {
                    @Override
                    public Matcher<View> getConstraints() {
                        return isEnabled(); // no constraints, they are checked above
                    }

                    @Override
                    public String getDescription() {
                        return "click dob field";
                    }

                    @Override
                    public void perform(UiController uiController, View view) {
                        view.performClick();
                    }
                }
        );


        // Checks post code field
        onView(withId(R.id.edit_text_postcode)).check(matches(allOf( isEnabled(), isClickable()))).perform(
                new ViewAction() {
                    @Override
                    public Matcher<View> getConstraints() {
                        return isEnabled(); // no constraints, they are checked above
                    }

                    @Override
                    public String getDescription() {
                        return "click postcode field";
                    }

                    @Override
                    public void perform(UiController uiController, View view) {
                        view.performClick();
                    }
                }
        );


        // Checks bar experience field
        onView(withId(R.id.edit_text_bar_experience)).check(matches(allOf( isEnabled(), isClickable()))).perform(
                new ViewAction() {
                    @Override
                    public Matcher<View> getConstraints() {
                        return isEnabled(); // no constraints, they are checked above
                    }

                    @Override
                    public String getDescription() {
                        return "click bar experience field";
                    }

                    @Override
                    public void perform(UiController uiController, View view) {
                        view.performClick();
                    }
                }
        );


        // Checks rates field
        onView(withId(R.id.edit_text_rate_per_hour)).check(matches(allOf( isEnabled(), isClickable()))).perform(
                new ViewAction() {
                    @Override
                    public Matcher<View> getConstraints() {
                        return isEnabled(); // no constraints, they are checked above
                    }

                    @Override
                    public String getDescription() {
                        return "click female button";
                    }

                    @Override
                    public void perform(UiController uiController, View view) {
                        view.performClick();
                    }
                }
        );

        onView(withId(R.id.edit_text_rate_per_night)).check(matches(allOf( isEnabled(), isClickable()))).perform(
                new ViewAction() {
                    @Override
                    public Matcher<View> getConstraints() {
                        return isEnabled(); // no constraints, they are checked above
                    }

                    @Override
                    public String getDescription() {
                        return "click female button";
                    }

                    @Override
                    public void perform(UiController uiController, View view) {
                        view.performClick();
                    }
                }
        );


        // Checks view profile button
        ViewInteraction appCompatButton6 = onView(
                allOf(withId(R.id.view_profile_button), withText("View Profile"), isDisplayed()));
        appCompatButton6.perform(click());

        onView(withId(R.id.bartender_profile_pic_field)).check(matches(isDisplayed()));
        onView(withId(R.id.bartender_name_field)).check(matches(isDisplayed()));
        onView(withId(R.id.hourly_shift_rate_field)).check(matches(isDisplayed()));
        onView(withId(R.id.nightly_shift_rate_field)).check(matches(isDisplayed()));
        onView(withId(R.id.bartender_rating)).check(matches(isDisplayed()));
        onView(withId(R.id.bartender_description_field)).check(matches(isDisplayed()));

        pressBack();


        // Checks logout functionality
        ViewInteraction appCompatButton5 = onView(
                allOf(withId(R.id.sign_out_image_button), isDisplayed()));
        appCompatButton5.perform(click());

        onView(withId(R.id.alert_dialog_title)).check(matches(withText("Logging out")));

        onView(withId(R.id.alert_dialog_content)).check(matches(withText("Do you want to log out ?")));

        ViewInteraction appCompatButton7 = onView(
                allOf(withId(R.id.alert_dialog_right_button), withText("Yes"), isDisplayed()));

        ViewInteraction appCompatButton8 = onView(
                allOf(withId(R.id.alert_dialog_left_button), withText("No"), isDisplayed()));
        appCompatButton8.perform(click());


        // Checks save button is functional
        ViewInteraction appCompatButton9 = onView(
                allOf(withId(R.id.done_button), withText("DONE"), isDisplayed()));
        appCompatButton9.perform(click());




    }

}
