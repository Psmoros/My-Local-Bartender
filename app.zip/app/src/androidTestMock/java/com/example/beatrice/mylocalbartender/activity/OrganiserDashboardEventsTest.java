package com.example.beatrice.mylocalbartender.activity;


import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.example.beatrice.mylocalbartender.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.hamcrest.core.IsInstanceOf;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.pressBack;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.action.ViewActions.scrollTo;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

/**
 * This class tests the organiser dashboard events activity in the form of Espresso instrumentation testing
 */

@LargeTest
@RunWith(AndroidJUnit4.class)
public class OrganiserDashboardEventsTest {

    @Rule
    public ActivityTestRule<SplashActivity> mActivityTestRule = new ActivityTestRule<>(SplashActivity.class);

    @Test
    public void organiserDashboardEventsTest() {

        // Signing into app as organiser
        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.sign_in_Email), withText("Sign In"),
                        withParent(allOf(withId(R.id.activity_login1),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton.perform(click());

        ViewInteraction editText = onView(
                allOf(withId(R.id.emailField), isDisplayed()));
        editText.perform(replaceText("max"), closeSoftKeyboard());

        ViewInteraction editText2 = onView(
                allOf(withId(R.id.PasswordField), isDisplayed()));
        editText2.perform(replaceText("123"), closeSoftKeyboard());

        ViewInteraction button = onView(
                allOf(withId(R.id.sign_in), withText("Sign In"), isDisplayed()));
        button.perform(click());


        // Checks dashboard is clickable
        ViewInteraction bottomNavigationItemView = onView(
                allOf(withId(R.id.action_dashboard), isDisplayed()));
        bottomNavigationItemView.perform(click());


        // Checks events tab is clickable
        ViewInteraction textView = onView(
                allOf(withText("Events"), isDisplayed()));
        textView.perform(click());


        // Checks tab buttons are correct
        ViewInteraction floatingActionButton = onView(
                allOf(withId(R.id.off_market_events), isDisplayed()));
        floatingActionButton.perform(click());

        onView(withId(R.id.current_tab_title)).check(matches(withText("Private Events"))).check(matches(isDisplayed()));

        ViewInteraction floatingActionButton2 = onView(
                allOf(withId(R.id.on_market_events), isDisplayed()));
        floatingActionButton2.perform(click());

        onView(withId(R.id.current_tab_title)).check(matches(withText("Public Events"))).check(matches(isDisplayed()));

        onView(withId(R.id.create_event)).check(matches(isDisplayed()));


        // Checks frag view is correct
        ViewInteraction textView3 = onView(
                allOf(withId(R.id.no_events_text_view), withText("You have no events on the market"),
                        childAtPosition(
                                childAtPosition(
                                        withId(R.id.events_framelayout),
                                        1),
                                0),
                        isDisplayed()));
        textView3.check(matches(withText("You have no events on the market")));

        ViewInteraction button2 = onView(
                allOf(withId(R.id.create_event_button),
                        childAtPosition(
                                childAtPosition(
                                        withId(R.id.events_framelayout),
                                        1),
                                1),
                        isDisplayed()));
        button2.check(matches(isDisplayed()));

        ViewInteraction button3 = onView(
                allOf(withId(R.id.create_event_button), withText("Create event"), isDisplayed()));
        button3.perform(click());

        ViewInteraction appCompatButton2 = onView(
                allOf(withId(R.id.cancel_event_button), withText("Cancel"), isDisplayed()));
        appCompatButton2.perform(click());


        // Checks dashboard is clickable
        ViewInteraction bottomNavigationItemView2 = onView(
                allOf(withId(R.id.action_dashboard), isDisplayed()));
        bottomNavigationItemView2.perform(click());

        ViewInteraction textView4 = onView(
                allOf(withText("Events"), isDisplayed()));
        textView4.perform(click());

        ViewInteraction floatingActionButton3 = onView(
                allOf(withId(R.id.create_event), isDisplayed()));
        floatingActionButton3.perform(click());


        // Checks correct input value for new event
        ViewInteraction appCompatEditText = onView(
                withId(R.id.evnet_name_edit_text));
        appCompatEditText.perform(scrollTo(), replaceText("test"), closeSoftKeyboard());
        onView(withId(R.id.evnet_name_edit_text)).check(matches(withText("test")));

        ViewInteraction appCompatEditText2 = onView(
                withId(R.id.location));
        appCompatEditText2.perform(scrollTo(), replaceText("test"), closeSoftKeyboard());
        onView(withId(R.id.location)).check(matches(withText("test")));

        ViewInteraction appCompatEditText3 = onView(
                withId(R.id.date));
        appCompatEditText3.perform(scrollTo(), replaceText("01/01/2018"), closeSoftKeyboard());
        onView(withId(R.id.date)).check(matches(withText("01/01/2018")));

        ViewInteraction appCompatEditText4 = onView(
                withId(R.id.start_time));
        appCompatEditText4.perform(scrollTo(), replaceText("12:00"), closeSoftKeyboard());
        onView(withId(R.id.start_time)).check(matches(withText("12:00")));

        ViewInteraction appCompatEditText5 = onView(
                withId(R.id.end_time));
        appCompatEditText5.perform(scrollTo(), replaceText("12:30"), closeSoftKeyboard());
        onView(withId(R.id.end_time)).check(matches(withText("12:30")));

        ViewInteraction appCompatEditText6 = onView(
                withId(R.id.edit_text_event_description));
        appCompatEditText6.perform(scrollTo(), replaceText("test"), closeSoftKeyboard());
        onView(withId(R.id.edit_text_event_description)).check(matches(withText("test")));

        ViewInteraction appCompatEditText7 = onView(
                withId(R.id.number_of_bartender_edit_text));
        appCompatEditText7.perform(scrollTo(), replaceText("4"), closeSoftKeyboard());
        onView(withId(R.id.number_of_bartender_edit_text)).check(matches(withText("4")));

        ViewInteraction appCompatEditText8 = onView(
                withId(R.id.rate_edit_text));
        appCompatEditText8.perform(scrollTo(), replaceText("4"), closeSoftKeyboard());
        onView(withId(R.id.rate_edit_text)).check(matches(withText("4")));

        ViewInteraction appCompatButton3 = onView(
                allOf(withId(R.id.public_event_button), withText("Public Event")));
        appCompatButton3.perform(scrollTo(), click());

        ViewInteraction appCompatButton4 = onView(
                allOf(withId(R.id.public_event_button), withText("PRIVATE EVENT")));
        appCompatButton4.perform(scrollTo(), click());

        ViewInteraction appCompatButton5 = onView(
                allOf(withId(R.id.done_button), withText("Done"), isDisplayed()));
        appCompatButton5.perform(click());

    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }
}
