package com.example.beatrice.mylocalbartender.activity;


import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import com.example.beatrice.mylocalbartender.R;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.pressImeActionButton;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

/**
 * This class tests the sign in popup activity in the form of Espresso instrumentation testing
 */

@LargeTest
@RunWith(AndroidJUnit4.class)
public class Sign_in_PopupTest {

    @Rule
    public ActivityTestRule<SplashActivity> mActivityTestRule = new ActivityTestRule<>(SplashActivity.class);

    @Test
    public void sign_in_PopupTest() {

        // Checks sign-in button is clickable
        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.sign_in_Email), withText("Sign In"),
                        withParent(allOf(withId(R.id.activity_login1),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton.perform(click());


        // Checks headers and images are shown
        onView(withId(R.id.alert_dialog_title)).check(matches(withText("Sign in")));
        onView(withId(R.id.exit_popup_button)).check(matches(isDisplayed()));


        // Checks email field is clickable and validates text inputted
        ViewInteraction editText = onView(
                allOf(withId(R.id.emailField), isDisplayed()));
        editText.perform(replaceText("max"), closeSoftKeyboard());

        onView(withId(R.id.emailField)).check(matches(withText("max")));


        // Checks password field is clickable and validates text inputted
        ViewInteraction editText2 = onView(
                allOf(withId(R.id.PasswordField), isDisplayed()));
        editText2.perform(replaceText("123"), closeSoftKeyboard());

        onView(withId(R.id.PasswordField)).check(matches(withText("123")));


        // Checks sign in button is shown and clickable
        ViewInteraction button = onView(
                allOf(withId(R.id.sign_in), withText("Sign In"), isDisplayed()));
        button.perform(click());

    }

}
