package com.example.beatrice.mylocalbartender.model;

import com.example.beatrice.mylocalbartender.database.BartenderTable;
import com.example.beatrice.mylocalbartender.database.BookingTable;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.stubbing.Answer;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.when;

/**
 * Created by Umar on 12/03/2017.
 */
@RunWith(JUnit4.class)
public class TagTest {


    @Rule
    public MockitoRule mockito = MockitoJUnit.rule();

    @Mock
    Transaction.Handler handler;

    @Mock
    DatabaseReference reference;

    @Mock
    MutableData mutableData;

    private Tag tag;

    @Before
    public void init(){


        tag = new Tag();


    }

    @Test
    public void increasePopularity() throws Exception {

        doAnswer(new Answer<Void>() {
            public Void answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                Transaction.Handler transaction = (Transaction.Handler) args[0];
                transaction.doTransaction(mutableData);
                return null;
            }
        }).when(reference).runTransaction((Transaction.Handler) any());


        when(mutableData.getValue(Tag.class)).thenReturn(tag);

        int expectedPopularity =1;

        tag.increasePopularity(reference);

        assertEquals(expectedPopularity,tag.getPopularity());

        // the same scenario this time testing that the tags pop does not increase because there is no tag
        when(mutableData.getValue(Tag.class)).thenReturn(null);

        assertEquals(expectedPopularity,tag.getPopularity());



    }

}