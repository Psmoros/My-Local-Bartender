package com.example.beatrice.mylocalbartender.firebase;

import android.app.Activity;

import com.example.beatrice.mylocalbartender.controller.interfaces.OrganiserCallback;
import com.example.beatrice.mylocalbartender.model.Bartender;
import com.example.beatrice.mylocalbartender.model.Organiser;
import com.example.beatrice.mylocalbartender.model.User;
import com.example.beatrice.mylocalbartender.model.UserType;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mock;
import org.mockito.asm.ClassAdapter;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.stubbing.Answer;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static org.mockito.BDDMockito.*;


@RunWith(JUnit4.class)
public class FirebaseManagementTest {

    @Rule
    public MockitoRule mockito = MockitoJUnit.rule();

    @Mock
    Activity activity;

    @Mock
    FirebaseAuth firebaseAuth;

    @Mock
    Task<AuthResult> task;

    @Mock
    FirebaseUser user;

    @Mock
    DatabaseReference root;

    @Mock
    Task<Void> voidTask;

    @Mock
    DatabaseReference dummyReference;

    @Mock
    Callback callback;


    private FirebaseManagement firebaseManagement;

    private FirebaseManagement spyFirebaseManagment;


    @Before
    public void init() {

        firebaseManagement = new FirebaseManagement(firebaseAuth, root);

    }


    @Test
    public void registerWithEmailFail() throws Exception {


        when(firebaseAuth.createUserWithEmailAndPassword(anyString(), anyString())).thenReturn(task);

        when(task.addOnCompleteListener((OnCompleteListener<AuthResult>) any()))
                .thenAnswer(new Answer<Object>() {
                    @Override
                    public Object answer(InvocationOnMock invocation) throws Throwable {
                        Object[] args = invocation.getArguments();
                        OnCompleteListener<AuthResult> onComplete = (OnCompleteListener<AuthResult>) args[0];
                        onComplete.onComplete(task);
                        return null;
                    }
                });


        when(task.isSuccessful()).thenReturn(false);

        firebaseManagement.registerWithEmail(activity, "", "", "", "", UserType.BARTENDER, callback);

        verify(callback).loginFailed();

        verify(callback, never()).loginSuccessful();

    }


    @Test
    public void registerWithEmailSuccess() {


        FirebaseManagement spyManagement = spy(firebaseManagement);


        when(firebaseAuth.createUserWithEmailAndPassword(anyString(), anyString())).thenReturn(task);

        when(task.addOnCompleteListener((OnCompleteListener<AuthResult>) any()))
                .thenAnswer(new Answer<Object>() {
                    @Override
                    public Object answer(InvocationOnMock invocation) throws Throwable {
                        Object[] args = invocation.getArguments();
                        OnCompleteListener<AuthResult> onComplete = (OnCompleteListener<AuthResult>) args[0];
                        onComplete.onComplete(task);
                        return null;
                    }
                });

        when(task.isSuccessful()).thenReturn(true);

        when(firebaseAuth.getCurrentUser()).thenReturn(user);

        when(user.getUid()).thenReturn("Some randomness");

        doNothing().when(spyManagement).createUserInDatabase((UserType) any(),anyString(),anyString(),anyString(),anyString());

        spyManagement.registerWithEmail(activity, "", "", "", "", UserType.BARTENDER, callback);

        verify(callback).loginSuccessful();

        verify(user).sendEmailVerification();
        verify(callback, never()).loginFailed();

    }


    @Test
    public void signInWithEmail() throws Exception {

        when(firebaseAuth.signInWithEmailAndPassword("", "")).thenReturn(task);

        when(task.addOnCompleteListener((OnCompleteListener<AuthResult>) any()))
                .thenAnswer(new Answer<Object>() {
                    @Override
                    public Object answer(InvocationOnMock invocation) throws Throwable {
                        Object[] args = invocation.getArguments();
                        OnCompleteListener<AuthResult> onComplete = (OnCompleteListener<AuthResult>) args[0];
                        onComplete.onComplete(task);
                        return null;
                    }
                });

        when(task.isSuccessful()).thenReturn(true);

        when(firebaseAuth.getCurrentUser()).thenReturn(user);

        when(user.isEmailVerified()).thenReturn(false);

        when(user.getUid()).thenReturn("some_random_string");

        firebaseManagement.signInWithEmail("", "", callback);

        verify(callback).loginFailed();

        verify(callback, never()).loginSuccessful();


    }


    @Test
    public void setValue() throws Exception {

        String table = "Table";

        String id = "3";

        Object object = new Object();

        when(root.child(anyString())).thenReturn(dummyReference);

        when(dummyReference.child(anyString())).thenReturn(dummyReference);

        firebaseManagement.setValue(object, table, id);

        verify(dummyReference).setValue(any());

    }

    @Test
    public void getUserUid() throws Exception {

        when(firebaseAuth.getCurrentUser()).thenReturn(user);

        when(user.getUid()).thenReturn(null);

        String expected = null;

        String result = firebaseManagement.getUserUid();

        assertEquals(expected, result);

        when(firebaseAuth.getCurrentUser()).thenReturn(user);

        when(user.getUid()).thenReturn("Some random string");

        String expecteduid = "Some random string";

        assertEquals(expecteduid, firebaseManagement.getUserUid());

    }

    @Test
    public void setUniversalUser() throws Exception {

        User user = mock(User.class);

        firebaseManagement.currentUser = user;

        Callback callback1 = mock(Callback.class);

        firebaseManagement.setUniversalUser(dummyReference, callback1);

        verify(callback1).loginFailed();

        verify(callback1, never()).loginSuccessful();

        assertEquals(user, firebaseManagement.currentUser);

        Bartender bartender = mock(Bartender.class);

        Organiser organiser = mock(Organiser.class);

        final DataSnapshot dataSnapshot = mock(DataSnapshot.class);

        ValueEventListener valueEventListener = mock(ValueEventListener.class);

        firebaseManagement.currentUser = null;

        doAnswer(new Answer<Void>() {
            public Void answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                ValueEventListener valueEventListener1 = (ValueEventListener) args[0];
                valueEventListener1.onDataChange(dataSnapshot);
                return null;
            }
        }).when(dummyReference).addListenerForSingleValueEvent((ValueEventListener) any());


        when(dataSnapshot.getValue()).thenReturn(user);

        when(dataSnapshot.getValue(User.class)).thenReturn(user);

        when(dataSnapshot.getValue(Bartender.class)).thenReturn(bartender);

        when(dataSnapshot.getValue(Organiser.class)).thenReturn(organiser);

        when(user.getUserType()).thenReturn(UserType.BARTENDER);

        Callback callback2 = mock(Callback.class);

        firebaseManagement.currentUser = null;

        firebaseManagement.setUniversalUser(dummyReference, callback2);

        assertEquals(bartender, firebaseManagement.currentUser);

        verify(callback2).loginSuccessful();

        verify(callback2, never()).loginFailed();


    }


    @Test
    public void loginFacebook(){

        List<String> strings = new ArrayList<>();

        strings.add("facebook.com");

        when(firebaseAuth.getCurrentUser()).thenReturn(user);

        when(user.getProviders()).thenReturn(strings);


        assertEquals(true,firebaseManagement.loggedInViaFB());

        strings.clear();

        strings.add("notFacebook");

        assertEquals(false,firebaseManagement.loggedInViaFB());



    }


    @Test
    public void getUser(){

        OrganiserCallback organiserCallback =mock(OrganiserCallback.class);

        when(root.child(anyString())).thenReturn(root);

        final DataSnapshot dataSnapshot = mock(DataSnapshot.class);

        doAnswer(new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {


                ValueEventListener valueEventListener = (ValueEventListener) invocation.getArguments()[0];

                valueEventListener.onDataChange(dataSnapshot);


                return null;

            }
        }).when(root).addListenerForSingleValueEvent((ValueEventListener) any());

        Organiser organisr = mock(Organiser.class);

        when(dataSnapshot.getValue()).thenReturn(organisr);

        firebaseManagement.getUser("",organiserCallback);

        verify(organiserCallback).provideUser((Organiser) any());



    }


}

