package com.example.beatrice.mylocalbartender.database;


import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class BartenderTableTest {
    public static final String TABLE_BARTENDER = "bartender";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_FIRST_NAME = "firstName";
    public static final String COLUMN_LAST_NAME = "lastName";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_GENDER = "gender";
    public static final String COLUMN_PHONE = "phoneNumber";
    public static final String COLUMN_LOCATION = "location";
    public static final String COLUMN_DOB = "dob";
    public static final String COLUMN_USER_TYPE = "userType";
    public static final String COLUMN_PICTURE = "picture";
    public static final String COLUMN_BARTENDER_EXPERIENCE = "barExperience";
    public static final String COLUMN_SPECIALITY = "speciality";
    public static final String COLUMN_NIGHTLY_RATE = "nightlyRate";
    public static final String COLUMN_HOURLY_RATE = "hourlyRate";

    @Test
    public void testAssertions(){
        assertEquals(TABLE_BARTENDER,BartenderTable.TABLE_BARTENDER);
        assertEquals(COLUMN_ID, BartenderTable.COLUMN_ID);
        assertEquals(COLUMN_FIRST_NAME, BartenderTable.COLUMN_FIRST_NAME);
        assertEquals(COLUMN_LAST_NAME, BartenderTable.COLUMN_LAST_NAME);
        assertEquals(COLUMN_EMAIL, BartenderTable.COLUMN_EMAIL);
        assertEquals(COLUMN_GENDER, BartenderTable.COLUMN_GENDER);
        assertEquals(COLUMN_PHONE, BartenderTable.COLUMN_PHONE);
        assertEquals(COLUMN_LOCATION, BartenderTable.COLUMN_LOCATION);
        assertEquals(COLUMN_DOB, BartenderTable.COLUMN_DOB);
        assertEquals(COLUMN_USER_TYPE, BartenderTable.COLUMN_USER_TYPE);
        assertEquals(COLUMN_PICTURE, BartenderTable.COLUMN_PICTURE);
        assertEquals(COLUMN_BARTENDER_EXPERIENCE, BartenderTable.COLUMN_BARTENDER_EXPERIENCE);
        assertEquals(COLUMN_SPECIALITY, BartenderTable.COLUMN_SPECIALITY);
        assertEquals(COLUMN_NIGHTLY_RATE, BartenderTable.COLUMN_NIGHTLY_RATE);
        assertEquals(COLUMN_HOURLY_RATE, BartenderTable.COLUMN_HOURLY_RATE);

    }


}