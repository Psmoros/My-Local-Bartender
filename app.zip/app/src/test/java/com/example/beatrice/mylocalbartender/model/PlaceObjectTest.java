package com.example.beatrice.mylocalbartender.model;

import static org.junit.Assert.*;

/**
 * Created by Umar on 27/03/2017.
 */
public class PlaceObjectTest {

}