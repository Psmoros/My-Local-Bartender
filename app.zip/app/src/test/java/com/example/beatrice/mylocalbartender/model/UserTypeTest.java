package com.example.beatrice.mylocalbartender.model;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Umar on 27/03/2017.
 */
public class UserTypeTest {
    @Test
    public void toStringTest() throws Exception {

        UserType userType = UserType.BARTENDER;

        assertEquals("BARTENDER",userType.toString());

        UserType userType1=  UserType.ORGANISER;

        assertEquals("ORGANISER",userType1.toString());

    }

}