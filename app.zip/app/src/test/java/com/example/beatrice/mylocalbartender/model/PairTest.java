package com.example.beatrice.mylocalbartender.model;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Umar on 27/03/2017.
 */
public class PairTest {



    @Test
    public void testGetterSetters(){

        Pair pair = new Pair(1,2);

        pair.setId("1");

        assertEquals("1",pair.getId());

        pair.setAvailable(true);


        pair.setStartTime(1);

        pair.setEndTime(2);

        assertEquals(1,pair.getStartTime());

        assertEquals(2,pair.getEndTime());



    }

}