package com.example.beatrice.mylocalbartender.model;

import com.example.beatrice.mylocalbartender.controller.interfaces.ResultsInterface;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.only;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by Umar on 27/03/2017.
 */
@RunWith(JUnit4.class)
public class SearchValueListenerTest {

    @Mock
    ResultsInterface resultsInterface;

    @Rule
    public MockitoRule mockito = MockitoJUnit.rule();


    @Mock
    DataSnapshot dataSnapshot;

    private Bartender bartender;

    private SearchValueListener searchValueListener;




    @Before
    public void init(){


        searchValueListener = new SearchValueListener("Umar",resultsInterface);

        DatabaseReference reference = mock(DatabaseReference.class);

        bartender = new Bartender(reference);

        bartender.setSpecialities("Umar");

        when(dataSnapshot.getValue(Bartender.class)).thenReturn(bartender);


        when(dataSnapshot.getValue()).thenReturn(bartender);




    }

    @Test
    public void onDataChange() throws Exception {

        searchValueListener.onDataChange(dataSnapshot);

        bartender.setSpecialities("KFDS");

        searchValueListener.onDataChange(dataSnapshot);

        verify(resultsInterface,times(1)).addToList(Matchers.any());

}

    @Test
    public void profileHiddenTest(){

        ResultsInterface results = mock(ResultsInterface.class);

        searchValueListener = new SearchValueListener(null,results);

        bartender.setProfileHidden(true);

        searchValueListener.onDataChange(dataSnapshot);

        verify(results,never()).addToList(Matchers.any());

    }



}