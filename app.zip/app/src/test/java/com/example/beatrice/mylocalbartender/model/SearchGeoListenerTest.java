package com.example.beatrice.mylocalbartender.model;

import com.example.beatrice.mylocalbartender.controller.interfaces.ResultsInterface;
import com.example.beatrice.mylocalbartender.firebase.FirebaseChildAdapter;
import com.firebase.geofire.GeoLocation;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.stubbing.Answer;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.when;

/**
 *
 * Created by Umar on 27/03/2017.
 *
 */
@RunWith(JUnit4.class)
public class SearchGeoListenerTest {


    @Rule
    public MockitoRule mockito = MockitoJUnit.rule();


    @Mock
    DataSnapshot thirdSnapshot;

    @Mock
    DataSnapshot datasnapshot;

    @Mock
    DataSnapshot fouthSnapshot;

    @Mock
    DataSnapshot rateSnapshot;

    @Mock
    DataSnapshot secondSnapshot;

    @Mock
    DatabaseReference root;

    @Mock
    DatabaseReference selectedRef;

    @Mock
    DatabaseReference userRef;

    @Mock
    DatabaseReference userTypeRef;

    @Mock
    DatabaseReference rateReference;

    @Mock
    DatabaseReference hourlyRef;

    @Mock
    DatabaseReference nightlyReference;

    @Mock
    ResultsInterface resultsInterface;

    private SearchGeoListener searchGeoListener;

    private double nightlyRate = 0.0;

    private double hourlyRate =1;

    private SearchGeoListener bartenderSearchGeoListen;

    @Before
    public void init(){

        searchGeoListener = new SearchGeoListener(UserType.ORGANISER,
                1,
                nightlyRate,
                hourlyRate,
                null,
                "Monday",
                1,
                1,
                resultsInterface,
                userRef,
                root);

        bartenderSearchGeoListen = new SearchGeoListener(UserType.BARTENDER,
                1,
                1,
                0,
                null,
                "Monday",
                1,
                1,
                resultsInterface,userRef,root);

        when(root.child("AvailableDate")).thenReturn(userRef);

        when(root.child("Events")).thenReturn(userRef);

        when(userRef.child("dsfjksdfjk")).thenReturn(userRef);

        when(userRef.child("sdfsdfSPECIALSPLITdsfjksdfjk")).thenReturn(userRef);

        when(userRef.child("Monday")).thenReturn(userRef);

        when(userRef.child("userType")).thenReturn(userTypeRef);

        when(userRef.child("rate")).thenReturn(rateReference);

        when(userRef.child("hourlyRate")).thenReturn(hourlyRef);

        when(userRef.child("nightlyRate")).thenReturn(nightlyReference);

        doAnswer(new Answer<Void>() {
            public Void answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                ValueEventListener valueEventListener1 = (ValueEventListener) args[0];
                valueEventListener1.onDataChange(rateSnapshot);
                return null;
            }
        }).when(nightlyReference).addListenerForSingleValueEvent((ValueEventListener) any());


        when(userRef.addChildEventListener((ChildEventListener) any()))
                .thenAnswer(new Answer<Object>() {
                    @Override
                    public Object answer(InvocationOnMock invocation) throws Throwable {
                        FirebaseChildAdapter firebaseAdapter = (FirebaseChildAdapter) invocation.getArguments()[0];
                        firebaseAdapter.onChildAdded(datasnapshot,"ss");
                        return null;
                    }
                });


        doAnswer(new Answer<Void>() {
            public Void answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                ValueEventListener valueEventListener1 = (ValueEventListener) args[0];
                valueEventListener1.onDataChange(secondSnapshot);
                return null;
            }
        }).when(userTypeRef).addListenerForSingleValueEvent((ValueEventListener) any());


        doAnswer(new Answer<Void>() {
            public Void answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                ValueEventListener valueEventListener1 = (ValueEventListener) args[0];
                valueEventListener1.onDataChange(rateSnapshot);
                return null;
            }
        }).when(rateReference).addListenerForSingleValueEvent((ValueEventListener) any());

        doAnswer(new Answer<Void>() {
            public Void answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                ValueEventListener valueEventListener1 = (ValueEventListener) args[0];
                valueEventListener1.onDataChange(rateSnapshot);
                return null;
            }
        }).when(hourlyRef).addListenerForSingleValueEvent((ValueEventListener) any());

        Pair pair = new Pair(1,1);

        when(datasnapshot.getValue())
                .thenReturn(pair);

        when(datasnapshot.getValue(Pair.class)).thenReturn(pair);

        when(secondSnapshot.getValue()).thenReturn("BARTENDER");

        when(thirdSnapshot.getValue()).thenReturn(1);

        when(fouthSnapshot.getValue()).thenReturn(1);

        when(rateSnapshot.getValue()).thenReturn(new Long(1));

        Event event = new Event("",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                2,
                1,
                true,
                true);

        when(datasnapshot.getValue(Event.class)).thenReturn(event);
    }




    @Test
    public void onKeyEnteredForBartender() throws Exception {

        searchGeoListener.onKeyEntered("sdfsdfSPECIALSPLITdsfjksdfjk",new GeoLocation(1,1));

    }


    @Test
    public void onKeyEnteredForOrganiser(){

        bartenderSearchGeoListen.onKeyEntered("sdfsdfSPECIALSPLITdsfjksdfjk", new GeoLocation(1,1));

    }


    @Test
    public void hourlyRateTest(){

        searchGeoListener =getSearchGeo(0.0,1);

        searchGeoListener.onKeyEntered("sdfsdfSPECIALSPLITdsfjksdfjk",new GeoLocation(1,1));

    }


    private SearchGeoListener getSearchGeo(double hourly, double nightly){

        return  new SearchGeoListener(UserType.ORGANISER,
                1,
                nightly,
                hourly,
                null,
                "Monday",
                1,
                1,
                resultsInterface,
                userRef,
                root);

    }

}