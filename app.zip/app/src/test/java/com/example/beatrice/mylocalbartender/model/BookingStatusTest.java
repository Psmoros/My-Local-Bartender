package com.example.beatrice.mylocalbartender.model;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import static org.junit.Assert.*;

/**
 * Created by Umar on 12/03/2017.
 */
@RunWith(JUnit4.class)
public class BookingStatusTest {

    private BookingStatus status;

    @Before
    public void init(){
         status = BookingStatus.REJECTED;
    }


    @Test
    public void toStringTest() throws Exception {


        assertEquals("REJECTED",status.toString());
        status = BookingStatus.ACCEPTED;
        assertEquals("ACCEPTED",status.toString());
        status = BookingStatus.APPROVED;
        assertEquals("APPROVED",status.toString());
        status = BookingStatus.OFFERED;
        assertEquals("OFFERED",status.toString());


    }

}