package com.example.beatrice.mylocalbartender.database;


import org.junit.Test;

import static org.junit.Assert.assertEquals;
public class JobTableTest {
    public static final String TABLE_JOB = "job";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_EVENT = "event_id";
    public static final String COLUMN_COMPLETED = "is_completed";
    public static final String COLUMN_BARTENDER_NAME = "bartenderName";
    public static final String COLUMN_BARTENDER_ID = "bartenderId";
    public static final String COLUMN_ORGANISER_ID = "organiserId";
    public static final String COLUMN_QR = "qrCode";

    @Test
    public void testAssertions() {
        assertEquals(TABLE_JOB, JobTable.TABLE_JOB);
        assertEquals(COLUMN_ID, JobTable.COLUMN_ID);
        assertEquals(COLUMN_EVENT, JobTable.COLUMN_EVENT);
        assertEquals(COLUMN_COMPLETED, JobTable.COLUMN_COMPLETED);
        assertEquals(COLUMN_BARTENDER_NAME, JobTable.COLUMN_BARTENDER_NAME);
        assertEquals(COLUMN_BARTENDER_ID, JobTable.COLUMN_BARTENDER_ID);
        assertEquals(COLUMN_ORGANISER_ID, JobTable.COLUMN_ORGANISER_ID);
        assertEquals(COLUMN_QR, JobTable.COLUMN_QR);
    }

}