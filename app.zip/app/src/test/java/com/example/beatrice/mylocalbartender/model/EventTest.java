package com.example.beatrice.mylocalbartender.model;

import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.stubbing.Answer;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by Umar on 12/03/2017.
 */
@RunWith(JUnit4.class)
public class EventTest {

    @Rule
    public MockitoRule mockito = MockitoJUnit.rule();

    @Mock
    Transaction.Handler handler;

    @Mock
    MutableData mutableData;

    @Mock
    DatabaseReference reference;

    private Event event;

    @Before
    public void init(){

        event = new Event();
        event.setRequiredBartenders(3); // setting the required for bartenders

        doAnswer(new Answer<Void>() {
            public Void answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                Transaction.Handler transaction = (Transaction.Handler) args[0];
                transaction.doTransaction(mutableData);
                return null;
            }
        }).when(reference).runTransaction((Transaction.Handler) any());

        when(mutableData.getValue(Event.class)).thenReturn(event);

    }

    @Test
    public void decrementEvent() throws Exception {

        event.decrementEvent(reference);

        assertEquals(2,event.getRequiredBartenders());


    }

    @Test
    public void incrementEvent() throws Exception {

        event.setRequiredBartenders(2);

        event.incrementEvent(reference);

        assertEquals(3,event.getRequiredBartenders());
    }

    @Test
    public void lockEvent(){
        event.setRequiredBartenders(1);
        event.decrementEvent(reference);
        assertEquals(false,event.isAvailable());
    }

    @Test
    public void getterSetterTest(){


        Event event = new Event("1","1","1","1","1","1","1","1",2,2,true,true);

        event.setAvailable(true);
        event.setRequiredBartenders(2);
        event.setDate("1");
        event.setDayEvent(true);
        event.setEventPublic(true);
        event.setDate("1");
        event.setEvnet_id("1");
        event.setFinishTime("1");
        event.setLocation("1");
        event.setOrganiserName("1");
        event.setShiftRate(2);
        event.setDescription("1");
        assertEquals("1",event.getEvent_id());
        assertEquals("1",event.getTitle());
        assertEquals("1",event.getDescription());
        assertEquals("1",event.getLocation());

        assertEquals("1",event.getDate());

        assertEquals("1",event.getStartTime());

        assertEquals("1",event.getFinishTime());

        assertEquals("1",event.getOrganiserUid());

        assertEquals(true,event.isDayEvent());

        assertEquals(true,event.isEventPublic());



    }



}