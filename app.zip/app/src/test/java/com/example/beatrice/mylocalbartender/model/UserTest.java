package com.example.beatrice.mylocalbartender.model;

import com.example.beatrice.mylocalbartender.controller.interfaces.ResultsInterface;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.stubbing.Answer;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static org.mockito.BDDMockito.*;

/**
 * Created by Umar on 12/03/2017.
 */
@RunWith(JUnit4.class)
public class UserTest {

    @Rule
    public MockitoRule mockito = MockitoJUnit.rule();

    @Mock
    FirebaseDatabase database;


    @Mock
    DataSnapshot dataSnapshot;

    @Mock
    DatabaseReference databaseReference;

    @Mock
    Query query;

    @Mock
    Query secondQuery;

    @Mock
    Query thirdQuery;


    @Mock
    ValueEventListener valueEventListener;

    private User user;

    @Before
    public void init(){

        when(database.getReference()).thenReturn(databaseReference);
        user = new User(databaseReference);

        when(databaseReference.child(anyString())).thenReturn(databaseReference);

        when(databaseReference.orderByChild(anyString())).thenReturn(query);

        when(query.equalTo(anyString())).thenReturn(query);





        doAnswer(new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {

                ValueEventListener valueEventListener = (ValueEventListener) invocation.getArguments()[0];

                valueEventListener.onDataChange(dataSnapshot);

                return null;

            }
        }).when(query).addListenerForSingleValueEvent((ValueEventListener) any());

        final List<DataSnapshot> dataSnapshotList = new ArrayList<>();

        dataSnapshotList.add(dataSnapshot);

        when(dataSnapshot.getValue()).thenReturn(new Job());

        when(dataSnapshot.getChildren()).thenReturn(dataSnapshotList);




    }

    @Test
    public void fetchCompletedJobs(){


        ResultsInterface resultsInterface = mock(ResultsInterface.class);

        user.fetchCompletedJobs(resultsInterface,"","");

        verify(resultsInterface).addToList(Matchers.any());

        when(dataSnapshot.getValue()).thenReturn(null);

        user.fetchCompletedJobs(resultsInterface,"","");

        verify(resultsInterface).notifyEmptyDataSet();


        doAnswer(new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {

                ValueEventListener valueEventListener = (ValueEventListener) invocation.getArguments()[0];

                DatabaseError error  = mock(DatabaseError.class);
                valueEventListener.onCancelled(error);

                return null;

            }
        }).when(query).addListenerForSingleValueEvent((ValueEventListener) any());


        verify(resultsInterface).notifyEmptyDataSet();


    }


    @Test
    public void fetchPendingJobs(){


        when(query.addChildEventListener((ChildEventListener) any()))
                .thenAnswer(new Answer<Object>() {
                    @Override
                    public Object answer(InvocationOnMock invocation) throws Throwable {

                        ChildEventListener childEventListner = (ChildEventListener) invocation.getArguments()[0];

                        childEventListner.onChildAdded(dataSnapshot,"");

                        return null;
                    }
                });


        ResultsInterface resultsInterface = mock(ResultsInterface.class);

        when(dataSnapshot.getValue()).thenReturn(null);

        user.fetchPendingJobs(resultsInterface);

        verify(resultsInterface).notifyEmptyDataSet();


        when(dataSnapshot.getValue()).thenReturn(new BaseRequest());

        user.fetchPendingJobs(resultsInterface);

        verify(resultsInterface).addToList(Matchers.any());


    }



    @Test
    public void fetchContacts(){

        ResultsInterface resultInterface = mock(ResultsInterface.class);

        when(databaseReference.child(anyString())).thenReturn(databaseReference);
        when(databaseReference.orderByChild(anyString())).thenReturn(query);

        when(query.addChildEventListener((ChildEventListener) any()))
                .thenAnswer(new Answer<Object>() {
                    @Override
                    public Object answer(InvocationOnMock invocation) throws Throwable {

                        ChildEventListener child = (ChildEventListener) invocation.getArguments()[0];
                        child.onChildAdded(dataSnapshot,"");
                        return null;
                    }
                });
        when(dataSnapshot.getValue()).thenReturn(new Contacts());
        user.loadContacts(resultInterface);
        verify(resultInterface).addToList(any());

    }


    @Test
    public void getterSetterTest(){

        User user = new User(databaseReference);
        user.setUserType(UserType.BARTENDER);
        assertEquals("BARTENDER",user.getUserType().toString());
        user.setLastName("");
        assertEquals("",user.getLastName());
        user.setBgColorPref("");
        assertEquals("",user.getBgColorPref());
        user.setDoB("");
        assertEquals("",user.getDoB());
        user.setEmail("");
        assertEquals("",user.getEmail());
        user.setFirstName("");
        assertEquals("",user.getFirstName());
        user.setGender("");
        assertEquals("",user.getGender());
        user.setLocation("");
        assertEquals("",user.getLocation());

    }







}