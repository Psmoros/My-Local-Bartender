package com.example.beatrice.mylocalbartender.database;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class OrganiserTableTest {
    public static final String TABLE_ORGANISER = "organiser";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_FIRST_NAME = "firstName";
    public static final String COLUMN_LAST_NAME = "lastName";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_GENDER = "gender";
    public static final String COLUMN_PHONE = "phoneNumber";
    public static final String COLUMN_LOCATION = "location";
    public static final String COLUMN_DOB = "dob";
    public static final String COLUMN_USER_TYPE = "userType";
    public static final String COLUMN_PICTURE = "picture";
    public static final String COLUMN_PROFESSION = "professionalPosition";
    public static final String COLUMN_BUSINESS_NAME = "businessName";
    public static final String COLUMN_BUSINESS_PROFILE = "businessBio";

    @Test
    public void testAssertions(){
        assertEquals(TABLE_ORGANISER,OrganiserTable.TABLE_ORGANISER);
        assertEquals(COLUMN_ID, OrganiserTable.COLUMN_ID);
        assertEquals(COLUMN_FIRST_NAME, OrganiserTable.COLUMN_FIRST_NAME);
        assertEquals(COLUMN_LAST_NAME, OrganiserTable.COLUMN_LAST_NAME);
        assertEquals(COLUMN_EMAIL, OrganiserTable.COLUMN_EMAIL);
        assertEquals(COLUMN_GENDER, OrganiserTable.COLUMN_GENDER);
        assertEquals(COLUMN_PHONE, OrganiserTable.COLUMN_PHONE);
        assertEquals(COLUMN_LOCATION, OrganiserTable.COLUMN_LOCATION);
        assertEquals(COLUMN_DOB, OrganiserTable.COLUMN_DOB);
        assertEquals(COLUMN_USER_TYPE, OrganiserTable.COLUMN_USER_TYPE);
        assertEquals(COLUMN_PICTURE, OrganiserTable.COLUMN_PICTURE);
        assertEquals(COLUMN_PROFESSION, OrganiserTable.COLUMN_PROFESSION);
        assertEquals(COLUMN_BUSINESS_NAME, OrganiserTable.COLUMN_BUSINESS_NAME);
        assertEquals(COLUMN_BUSINESS_PROFILE, OrganiserTable.COLUMN_BUSINESS_PROFILE);
    }

}
















































