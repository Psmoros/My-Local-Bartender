package com.example.beatrice.mylocalbartender.database;


import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class BookingTableTest {
    public static final String TABLE_BOOKING = "booking";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_EVENT = "event_id";
    public static final String COLUMN_ORGANISER = "organiser_id";
    public static final String COLUMN_BARTENDER = "bartender_id";
    public static final String COLUMN_BOOKING_STATUS = "status";
    public static final String COLUMN_ACCEPTED = "bartenderAccepted";

    @Test
    public void testAssertions() {
        assertEquals(TABLE_BOOKING, BookingTable.TABLE_BOOKING);
        assertEquals(COLUMN_ID, BookingTable.COLUMN_ID);
        assertEquals(COLUMN_EVENT, BookingTable.COLUMN_EVENT);
        assertEquals(COLUMN_ORGANISER, BookingTable.COLUMN_ORGANISER);
        assertEquals(COLUMN_BARTENDER, BookingTable.COLUMN_BARTENDER);
        assertEquals(COLUMN_BOOKING_STATUS, BookingTable.COLUMN_BOOKING_STATUS);
        assertEquals(COLUMN_ACCEPTED, BookingTable.COLUMN_ACCEPTED);
    }
}