package com.example.beatrice.mylocalbartender.model;

import com.example.beatrice.mylocalbartender.controller.MyFlowLayoutInterface;
import com.example.beatrice.mylocalbartender.firebase.FirebaseChildAdapter;
import com.example.beatrice.mylocalbartender.utils.MyFlowLayout;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertSame;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by ChouJ on 05/03/2017.
 */

public class BartenderTest {

    private Bartender bartender;

    @Mock private DatabaseReference databaseRefMock;

    /**
     * Create instance of Bartender class before testing the getters and setters
     */
    @Before
    public void setUp(){

        bartender = new Bartender(databaseRefMock);
        databaseRefMock = mock(DatabaseReference.class);
        when(databaseRefMock.child(anyString())).thenReturn(databaseRefMock);
    }

    /**
     * Validate attribute values being correctly retrieved and set to the variable
     */
    @Test
    public void testGettersSetters(){

        bartender.setBarExperience("barexp");
        assertEquals("barexp", bartender.getBarExperience());

        bartender.setProfileHidden(true);
        assertEquals(true, bartender.isProfileHidden());

        bartender.setSpecialities("speciality");
        assertEquals("speciality", bartender.getSpecialities());

        bartender.setNightlyRate(10.00);
        assertEquals(10.00, bartender.getNightlyRate());

        bartender.setHourlyRate(5.00);
        assertEquals(5.00, bartender.getHourlyRate());
    }

    @Test
    public void deleteAvailableDateTest(){

        //Nullpointerexception
       /* bartender.deleteAvailableDate("monday", new Pair(1,2), databaseRefMock);
        verify(databaseRefMock, times(4)).child("Child called 4 times");*/
    }

    /**
     * Checks if string specialities is split into array
     */
    @Test
    public void fetchSpecialitiesTestingSplit(){

        bartender.setSpecialities("test/ing");
        assertEquals("test", bartender.fetchSpecialities()[0]);
        assertEquals("ing", bartender.fetchSpecialities()[1]);
        try {
            assertEquals(null, bartender.fetchSpecialities()[2]);
        } catch(ArrayIndexOutOfBoundsException e){
        }
    }

    /**
     * Checks return value is null if specialities value is null
     */
    @Test
    public void fetchSpeciailitiesTestNull(){

        bartender.setSpecialities(null);
        assertEquals(null, bartender.fetchSpecialities());
    }

}