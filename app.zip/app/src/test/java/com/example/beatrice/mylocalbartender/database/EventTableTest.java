package com.example.beatrice.mylocalbartender.database;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
public class EventTableTest {
    public static final String TABLE_EVENT = "event";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_PICTURE = "picURI";
    public static final String COLUMN_TITLE = "event_title";
    public static final String COLUMN_DESCRIPTION = "event_description";
    public static final String COLUMN_LOCATION = "location";
    public static final String COLUMN_DATE = "event_date";
    public static final String COLUMN_START = "start_time";
    public static final String COLUMN_END = "end_time";
    public static final String COLUMN_ORGANISER_UID = "organiser_uid";
    public static final String COLUMN_ORGANISER_NAME = "organiser_name";
    public static final String COLUMN_SHIFT_RATE = "shiftRate";
    public static final String COLUMN_AVAILABLE = "availability";
    public static final String COLUMN_BARTENDERS = "required_bartenders";
    public static final String COLUMN_DAY_EVENT = "isDayEvent";
    public static final String COLUMN_PUBLIC = "isEventPublic";

    @Test
    public void testAssertions() {
        assertEquals(TABLE_EVENT, EventTable.TABLE_EVENT);
        assertEquals(COLUMN_ID, EventTable.COLUMN_ID);
        assertEquals(COLUMN_PICTURE, EventTable.COLUMN_PICTURE);
        assertEquals(COLUMN_TITLE, EventTable.COLUMN_TITLE);
        assertEquals(COLUMN_DESCRIPTION, EventTable.COLUMN_DESCRIPTION);
        assertEquals(COLUMN_LOCATION, EventTable.COLUMN_LOCATION);
        assertEquals(COLUMN_DATE, EventTable.COLUMN_DATE);
        assertEquals(COLUMN_START, EventTable.COLUMN_START);
        assertEquals(COLUMN_END, EventTable.COLUMN_END);
        assertEquals(COLUMN_ORGANISER_UID, EventTable.COLUMN_ORGANISER_UID);
        assertEquals(COLUMN_ORGANISER_NAME, EventTable.COLUMN_ORGANISER_NAME);
        assertEquals(COLUMN_SHIFT_RATE, EventTable.COLUMN_SHIFT_RATE);
        assertEquals(COLUMN_AVAILABLE, EventTable.COLUMN_AVAILABLE);
        assertEquals(COLUMN_BARTENDERS, EventTable.COLUMN_BARTENDERS);
        assertEquals(COLUMN_DAY_EVENT, EventTable.COLUMN_DAY_EVENT);
        assertEquals(COLUMN_PUBLIC, EventTable.COLUMN_PUBLIC);
    }

}