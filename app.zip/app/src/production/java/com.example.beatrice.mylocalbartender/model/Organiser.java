package com.example.beatrice.mylocalbartender.model;


import android.app.Activity;
import android.support.annotation.VisibleForTesting;
import android.util.Log;
import android.view.View;

import com.example.beatrice.mylocalbartender.controller.ProfilePicManager;
import com.example.beatrice.mylocalbartender.utils.async.AsyncEventLocation;
import com.example.beatrice.mylocalbartender.controller.interfaces.ResultsInterface;
import com.example.beatrice.mylocalbartender.database.DBCallback;
import com.example.beatrice.mylocalbartender.database.DBReader;
import com.example.beatrice.mylocalbartender.database.DBWriter;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.example.beatrice.mylocalbartender.utils.Keys;
import com.example.beatrice.mylocalbartender.utils.MyLinearLayout;
import com.example.beatrice.mylocalbartender.utils.async.AsyncEventLocation;
import com.firebase.geofire.GeoFire;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class Organiser extends User {

    private String professionalPosition, businessName, businessBio;
    private transient DatabaseReference root;
    private ArrayList<Event> selectedEvents;

    //TO DO
    //Add setter and getter for background picture

    public Organiser() {
        super();
        root = FirebaseDatabase.getInstance().getReference();
    }

    @VisibleForTesting
    protected Organiser(DatabaseReference reference){
        super(reference);
        this.root = reference;

    }


    public Organiser(String email, String uid) {
        super(email, uid);
        root = FirebaseDatabase.getInstance().getReference();
    }

    public Organiser(String firstName, String lastName, String email, String uid) {
        super(firstName, lastName, email, uid);
        root = FirebaseDatabase.getInstance().getReference();

    }



    /**
     * Returns value of professionalPosition
     *
     * @return
     */
    public String getProfessionalPosition() {
        return professionalPosition;
    }

    /**
     * Sets new value of professionalPosition
     *
     * @param
     */
    public void setProfessionalPosition(String professionalPosition) {
        this.professionalPosition = professionalPosition;
    }


    /**
     * Returns value of businessName
     *
     * @return
     */
    public String getBusinessName() {
        return businessName;
    }

    /**
     * Sets new value of businessName
     *
     * @param
     */
    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    /**
     * Returns value of businessBio
     *
     * @return
     */
    public String getBusinessBio() {
        return businessBio;
    }

    /**
     * Sets new value of businessBio
     *
     * @param
     */
    public void setBusinessBio(String businessBio) {
        this.businessBio = businessBio;
    }


    public void fetchEvents(final MyLinearLayout layout, final View window) {


        selectedEvents = new ArrayList<>();

        root.child("Events").child(getUid())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        if(dataSnapshot.getValue()!=null) {
                            for (DataSnapshot snap : dataSnapshot.getChildren()) {
                                Event event = (Event) snap.getValue(Event.class);
                                layout.addToLayout(event, Organiser.this, window);
                            }
                        }

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });
    }

    public void fetchEventsFromDB(final ResultsInterface<Event> eventResultsInterface, final boolean isPublicEvent){


        root.child("Events").child(getUid()).orderByChild("eventPublic").equalTo(isPublicEvent)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        if(dataSnapshot.getValue()!=null) {
                            for (DataSnapshot snap : dataSnapshot.getChildren()) {
                                Event event = snap.getValue(Event.class);
                                eventResultsInterface.addToList(event);
                            }
                        }else{
                            eventResultsInterface.notifyEmptyDataSet();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        eventResultsInterface.notifyEmptyDataSet();
                    }
                });

    }


    public void addToSelectedEvents(Event event){
        selectedEvents.add(event);
    }

    public void eraseFromSelectedEvents(Event event){
        selectedEvents.remove(event);
    }

    public ArrayList<Event> fetchSelectedEvents(){
        return selectedEvents;
    }

    // TODO: 10/03/2017 Make a white list that a user can remove himself from -- test with security rules

    /**
     * An event cannot be deleted if it is not fully unlocked
     * When an organiser cancels an event -- The event is deleted from the database
     * and all associated booking requests are set STATUS: REJECTED
     *
     * @param event The event to be cancelled
     */
    public boolean cancelEvent(Event event) {

        if (canDelete(event)) {
            cancel(event);
            return true;
        }

        return false;
    }


    public void acceptRequest(boolean accept, BaseRequest baseRequest) {

        if(accept){

            Event event  = baseRequest.getEvent();

            DatabaseReference pushRef=root.child("Jobs").push();

            String id = pushRef.getKey();

            String organiserId = baseRequest.getOrganiserId();

            Job job = new Job(
                    id,
                    event,
                    event.getOrganiserName(),
                    baseRequest.getBartenderId(),
                    baseRequest.getOrganiserId(),
                    baseRequest.getBartenderFirstName(),
                    baseRequest.getBartenderLastName(),
                    baseRequest.getOrganiserFirstName(),
                    baseRequest.getOrganierLastName()
            );

            pushRef.setValue(job);

            DatabaseReference reference = root.child("Queue").child("tasks");

            Log.v("SecuredData",job.getSecuredData());
            Log.v("SecuredData",job.getSecuredData().split("\\$").toString());
            String key = job.getSecuredData().split("\\$")[4];
            String jobId = job.getJobId();
            HashMap map = new HashMap<>();
            map.put("job_id",jobId);
            map.put("secret_key",key);
            reference.push().setValue(map);


            removeBookingRequest(baseRequest);

            // decrementing the event
            Event event1 = baseRequest.getEvent();
            event1.decrementEvent(root.child("Events").child(event1.getEvent_id()));


        }else{

            // changing the base booking request value to be rejected
            baseRequest.setStatus(BookingStatus.REJECTED);

            rejectBookingRequest(baseRequest);


        }

    }

    private void rejectBookingRequest(BaseRequest baseRequest){

        FirebaseManagement
                .getInstance()
                .setValue(baseRequest,"Bookingrequest",baseRequest.getBookingID());

    }


    private void removeBookingRequest(BaseRequest baseRequest){

        FirebaseManagement
                .getInstance()
                .setValue(null,"BookingRequest",baseRequest.getBookingID());




    }





    /**
     * An event can only be deleted if the required bartenders is 0
     *
     * @param event The event to be deletd
     * @return whether the bartneders are 0
     */
    private boolean canDelete(Event event) {
        return event.getRequiredBartenders() == 0;
    }


    public void cancel(Event event) {

            FirebaseManagement.getInstance()
                    .removeValue(FirebaseDatabase.getInstance().getReference().child("Events").child(event.getEvent_id()));

        }

    public Event createEvent(int numberBartenders,
                            boolean isDayEvent,
                            boolean isPublic,
                            final Activity activity,
                            String... details) {

        DatabaseReference reference = root;

        DatabaseReference pushRef = reference.child("Events")
                .child(FirebaseManagement.getInstance().currentUser.getUid())
                .push();

        String id = pushRef.getKey();


        final Event event = new Event(
                id,
                details[0],
                details[1],
                details[2],
                details[3],
                details[4],
                details[5],
                getUid(),
                Double.valueOf(details[6]),
                numberBartenders,
                isDayEvent,
                isPublic,
                FirebaseManagement.getInstance()
        );

        pushRef.setValue(event);
        /*.addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                DBWriter writer = new DBWriter(activity);
                writer.execute(event, new DBCallback() {
                    @Override
                    public void callBack(Object object) {
                        Log.v("Event created, local DB", event.getEvent_id());
                    }
                });
            }
        });*/
        // making an async location
        addLocationAsync(details[2],id);
        return event;

    }

    @VisibleForTesting
    protected void addLocationAsync(String location, String eventId){

        new AsyncEventLocation(
                new GeoFire(FirebaseDatabase.getInstance().getReference().child(Keys.EVENT_GEOFIRE_REF)),eventId,this.getUid())
                .execute(location);

    }


}

