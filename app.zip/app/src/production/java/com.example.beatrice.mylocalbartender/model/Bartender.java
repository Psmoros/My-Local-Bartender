package com.example.beatrice.mylocalbartender.model;

import android.support.annotation.VisibleForTesting;

import com.example.beatrice.mylocalbartender.controller.MyFlowLayoutInterface;
import com.example.beatrice.mylocalbartender.firebase.FirebaseChildAdapter;
import com.example.beatrice.mylocalbartender.firebase.FirebaseManagement;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class Bartender extends User {

    private transient FirebaseDatabase database;
    private transient DatabaseReference root;
    private String barExperience, specialities;
    private double nightlyRate, hourlyRate;
    private transient ArrayList<DatabaseReference> daysRefs;
    private transient ChildEventListener availableDatesEventListener;
    private boolean profileHidden;
    private ArrayList<Pair> pairExistCheck;

    public Bartender() {
        super();
        root = FirebaseDatabase.getInstance().getReference();
    }

    @VisibleForTesting
    protected Bartender(DatabaseReference reference){

        super(reference);
        this.root = reference;
    }

    public Bartender(String firstName, String lastName, String email, String uid) {
        super(firstName, lastName, email, uid);
        database = FirebaseDatabase.getInstance();
        root = database.getReference();
        daysRefs = new ArrayList<>();
        specialities = "";
    }

    @VisibleForTesting
    protected Bartender(FirebaseDatabase database, String firstName, String lastName, String email, String uid){
        super(firstName, lastName, email, uid);
        this.database = database;
        this.root = database.getReference();
    }

    /**
     * Returns value of barExperience
     *
     * @return
     */
    public String getBarExperience() {
        return barExperience;
    }

    /**
     * @return
     */
    public boolean isProfileHidden() {
        return profileHidden;
    }

    /**
     * @param profileHidden
     */
    public void setProfileHidden(boolean profileHidden) {
        this.profileHidden = profileHidden;
    }

    /**
     * Sets new value of barExperience
     *
     * @param
     */
    public void setBarExperience(String barExperience) {
        this.barExperience = barExperience;
    }


    /**
     * Returns value of speciality
     *
     * @return
     */
    public String getSpecialities() {
        return specialities;
    }

    /**
     * Sets new value of speciality
     *
     * @param
     */
    public void setSpecialities(String specialities) {
        this.specialities = specialities;
    }

    /**
     * Returns value of nightlyRate
     *
     * @return
     */
    public double getNightlyRate() {
        return nightlyRate;
    }

    /**
     * Sets new value of nightlyRate
     *
     * @param
     */
    public void setNightlyRate(double nightlyRate) {
        this.nightlyRate = nightlyRate;
    }

    /**
     * Returns value of hourlyRate
     *
     * @return
     */
    public double getHourlyRate() {
        return hourlyRate;
    }

    /**
     * Sets new value of hourlyRate
     *
     * @param
     */
    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }


    public void addSpeciality(String speciality) {
        boolean add = false;
        if(fetchSpecialities()!=null) {
            if (!Arrays.asList(fetchSpecialities()).contains(speciality)) {
               add = true;
            }
        }
        else{
            add = true;
        }
        if(add){
            StringBuffer buffer = new StringBuffer(specialities);
            buffer.append(speciality + "/");
            setSpecialities(buffer.toString());
        }
    }


    public String[] fetchSpecialities() {
        if (getSpecialities() != null && !getSpecialities().isEmpty())
            return getSpecialities().split("/");
        else {
            return null;
        }
    }

    public void eraseSpeciality(String speciality) {
        String newSpecialities = getSpecialities().replace(speciality + "/", "");
        setSpecialities(newSpecialities);
    }

    public void clearSpecialities(){
        specialities = "";
    }


    /**
     * @param weekDay
     * @param pair
     */
    public void deleteAvailableDate(String weekDay, final Pair pair) {
        DatabaseReference dateRef = root.child("AvailableDate");
        dateRef.child(getUid()).child(weekDay).child(pair.getId()).removeValue();
    }

    /**
     * @param weekDay
     * @param pair
     */
    public void addAvailableDate(String weekDay, Pair pair) {
        //Interact with the DB

        DatabaseReference dateRef = root.child("AvailableDate");
        dateRef.child(getUid()).child(weekDay).child(pair.getId()).setValue(pair);
    }

    /**
     * @param weekDay
     */
    public void fetchAvailableDates(final String weekDay, final MyFlowLayoutInterface shiftHoursInterface) {

        pairExistCheck = new ArrayList<>();

        DatabaseReference dateRef = root.child("AvailableDate").child(getUid()).child(weekDay);
        daysRefs.add(dateRef);
        availableDatesEventListener = dateRef.addChildEventListener(new FirebaseChildAdapter() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Pair pair = dataSnapshot.getValue(Pair.class);
                if (pair != null && !checkIfPairExist(pair)) {
                    pairExistCheck.add(pair);
                    shiftHoursInterface.addToLayout(pair, Bartender.this, weekDay);
                }
            }
        });
    }

    public void disposeAvailableDateEventListener() {
        for (DatabaseReference ref : daysRefs) {
            ref.removeEventListener(availableDatesEventListener);
        }
    }

    private boolean checkIfPairExist(Pair pairToCheck) {
        for (Pair pair : pairExistCheck) {
            if (pair.equals(pairToCheck))
                return true;
        }
        return false;
    }


}

