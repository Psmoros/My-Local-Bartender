package com.example.beatrice.mylocalbartender.model;


import android.support.annotation.VisibleForTesting;

import com.example.beatrice.mylocalbartender.controller.EventListenersCleaner;
import com.example.beatrice.mylocalbartender.controller.interfaces.ResultsInterface;
import com.example.beatrice.mylocalbartender.firebase.FirebaseChildAdapter;
import com.example.beatrice.mylocalbartender.utils.Keys;
import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQuery;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;

public class User implements Serializable {
    // TODO: 02/03/2017 Set persistence in this data
    // TODO: 04/03/2017 Change the rating < to what it was 
    private transient FirebaseDatabase database;
    private transient DatabaseReference root;
    private String firstName;
    private String lastName;
    private String email;
    private String gender;
    private String location;
    private String summary;
    private String picURI;
    private String doB;
    private String uid;
    private String phone;
    private String bgColorPref;
    private double rate;
    private UserType userType;
    private GeoQuery geoQuery;


    public User() {

        root = FirebaseDatabase.getInstance().getReference();
    }

    public User(String email, String uid) {
        this.uid = uid;
        this.email = email;
        database = FirebaseDatabase.getInstance();
        root = database.getReference();
    }

    public User(String firstName, String lastName, String email, String uid) {
        this.uid = uid;
        this.firstName = firstName;
        this.email = email;
        this.lastName = lastName;
        database = FirebaseDatabase.getInstance();
        root = database.getReference();
    }

    @VisibleForTesting User(DatabaseReference databaseReference){
        this.root = databaseReference;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String toString() {
        return "User " + email + " | Username : " + firstName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getPicURI() {
        return picURI;
    }

    public void setPicURI(String picURI) {
        this.picURI = picURI;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public String getDoB() {
        return doB;
    }

    public void setDoB(String doB) {
        this.doB = doB;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    public UserType getUserType() {
        return userType;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getBgColorPref() {
        return bgColorPref;
    }

    public void setBgColorPref(String bgColorPref) {
        this.bgColorPref = bgColorPref;
    }


    /**
     * Method to Search for another user or an event, depending on all of those queries.
     * Depending on the userType : specify the right GeoFire node, specify the right ResultsInterface (ResultsInterface<User> or ResultsInterface<Event>)
     * Default value for :
     * rate : 0
     * radius : 5
     * nightlyRate : 0
     * hourlyRate : 0
     * speciality : null
     * startTime : 24
     * endTime : 24
     *
     * @param latitude
     * @param longitude
     * @param radius
     * @param rate
     * @param nightlyRate
     * @param hourlyRate
     * @param speciality
     * @param day
     * @param startTime
     * @param endTime
     * @return
     */
    public void search(double latitude, double longitude, double radius, final double rate, final double nightlyRate, final double hourlyRate, final String speciality, String day, int startTime, int endTime, ResultsInterface searchQueryInterface) {

        GeoFire geoFire = null;
        if (userType == UserType.BARTENDER) {

            geoFire = new GeoFire(root.child(Keys.EVENT_GEOFIRE_REF));

        } else {

            geoFire = new GeoFire(root.child("GeoFire"));

        }
        final UserType typeOfUser = userType;
        //To Filter vy location
        geoQuery = geoFire.queryAtLocation(new GeoLocation(latitude, longitude), radius);
        geoQuery.addGeoQueryEventListener(new SearchGeoListener(typeOfUser, rate, nightlyRate, hourlyRate, speciality, day, startTime, endTime, searchQueryInterface));
    }


    /**
     * This method retrieves the completed jobs from the database and addded to a results interface
     * @param resultsInterface The interface to be added
     * @param orderByChild The first query
     */
    public void fetchCompletedJobs(final ResultsInterface resultsInterface, String orderByChild, String equalTo) {

        root.child("Jobs").orderByChild(orderByChild).equalTo(equalTo).addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        if (dataSnapshot.getValue() != null) {
                            for (DataSnapshot snap : dataSnapshot.getChildren()) {
                                Job job = snap.getValue(Job.class);
                                resultsInterface.addToList(job);
                            }
                        }else{
                            resultsInterface.notifyEmptyDataSet();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                        resultsInterface.notifyEmptyDataSet();
                    }
                }
        );
    }

    public void fetchPendingJobs(final ResultsInterface<BaseRequest> resultsInterface){

        String whereClause = userType == UserType.BARTENDER ? "bartenderId" : "organiserId";

        root.child("BookingRequest").orderByChild(whereClause).equalTo(uid).addChildEventListener(
                new ChildEventListener() {
                    @Override
                    public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                        if(dataSnapshot.getValue()!=null){
                            BaseRequest baseRequest = dataSnapshot.getValue(BaseRequest.class);
                            resultsInterface.addToList(baseRequest);
                        }else{

                            resultsInterface.notifyEmptyDataSet();

                        }

                    }

                    @Override
                    public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                        BaseRequest baseRequest = dataSnapshot.getValue(BaseRequest.class);
                        resultsInterface.notifyDataChanged(baseRequest);

                    }

                    @Override
                    public void onChildRemoved(DataSnapshot dataSnapshot) {

                        BaseRequest baseRequest = dataSnapshot.getValue(BaseRequest.class);
                        resultsInterface.removeFromList(baseRequest);


                    }

                    @Override
                    public void onChildMoved(DataSnapshot dataSnapshot, String s) {


                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {


                    }
                }
        );





    }


    public void loadContacts(final ResultsInterface<Contacts> contactsResultsInterface){


        Query query = root.child("Contacts").child(this.getUid()).orderByChild("time");

        query.addChildEventListener(new FirebaseChildAdapter(){

            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                Contacts contacts = dataSnapshot.getValue(Contacts.class);
                contactsResultsInterface.addToList(contacts);

            }
        });



    }





}



