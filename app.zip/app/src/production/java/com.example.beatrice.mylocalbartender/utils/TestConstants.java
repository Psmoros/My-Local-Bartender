package com.example.beatrice.mylocalbartender.utils;

/**
 * Created by louis on 22/03/17.
 */

public class TestConstants {

    public static int CONSTANT = 2;

}
