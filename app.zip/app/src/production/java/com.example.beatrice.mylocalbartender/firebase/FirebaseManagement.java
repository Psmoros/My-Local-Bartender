package com.example.beatrice.mylocalbartender.firebase;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.VisibleForTesting;
import android.util.Log;
import android.widget.Toast;

import com.example.beatrice.mylocalbartender.R;
import com.example.beatrice.mylocalbartender.activity.Registering1;
import com.example.beatrice.mylocalbartender.async.MessagingAsync;
import com.example.beatrice.mylocalbartender.controller.interfaces.OrganiserCallback;
import com.example.beatrice.mylocalbartender.database.DBCallback;
import com.example.beatrice.mylocalbartender.database.DBWriter;
import com.example.beatrice.mylocalbartender.model.Bartender;
import com.example.beatrice.mylocalbartender.model.Organiser;
import com.example.beatrice.mylocalbartender.model.User;
import com.example.beatrice.mylocalbartender.model.UserType;
import com.facebook.AccessToken;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;

/**
 * Created by Umar on 08/02/2017.
 * This class represents the entry point for many Firebase functions such as sign in and basic CRUD operations
 * This class is a singleton so the contents can be accessed from anywhere
 */

public class FirebaseManagement {


    public static final int SIGN_IN_GMAIL = 100;
    private static boolean authorised = false;
    private static boolean signedIn = false;
    private static DatabaseReference root;
    private static DatabaseReference usersRef;
    private static FirebaseAuth auth;


    public User currentUser;

    private static FirebaseManagement firebaseManagementInstance = new FirebaseManagement();

    public static FirebaseManagement getInstance() {

        root = FirebaseDatabase.getInstance().getReference();

        auth = FirebaseAuth.getInstance();

        usersRef = root.child("Users");

        return firebaseManagementInstance;

    }

    private FirebaseManagement() {
    }

    @VisibleForTesting
    protected FirebaseManagement(FirebaseAuth firebaseAuth, DatabaseReference reference){

        auth = firebaseAuth;
        this.root = reference;

    }


    //// TODO: 10/02/2017 Fix a concurrency issue, the auth runs on a different thread
    // TODO: 09/03/2017 The above issue has been resolved with callbacks but the thread dies when you kill the activitiy 

    /**
     * Registering with standard email and password
     *
     * @param activity  The activity that this method is being called from
     * @param email     Email from the user
     * @param password  The password from the user
     * @param firstName The username
     * @param userType  If the user wishes to be a bartender then the different information will be stored in the DB
     * @return
     */
    public void registerWithEmail(final Activity activity, final String email, String password, final String firstName, final String lastName, final UserType userType, final Callback callback) {


        auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {


            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                // Successfully created a user
                if (task.isSuccessful()) {


                    // get a ref to the the Users
                    DatabaseReference usersRef = root.child("Users");

                    // get the uid
                    String uid = auth.getCurrentUser().getUid();


                    createUserInDatabase(userType,uid,firstName,lastName,email);

                    auth.getCurrentUser().sendEmailVerification();

                    authorised = true;

                    callback.loginSuccessful();


                } else {
                    callback.loginFailed();

                }
            }
        });
    }


    @VisibleForTesting
    protected void createUserInDatabase(UserType userType,
                                        String uid,
                                        String firstName,
                                        String lastName,
                                        String email){

        User user;

        switch (userType) {
            case BARTENDER:

                user = new Bartender(firstName, lastName, email, uid);
                user.setUserType(userType);
                usersRef.child(uid).setValue(user);
                break;
            case ORGANISER:

                user = new Organiser(firstName, lastName, email, uid);

                user.setUserType(userType);
                usersRef.child(uid).setValue(user);
                break;
        }




    }


    /**
     * Sign in with standard email and password
     *
     * @param email    Email from the user
     * @param password Password from the user
     * @return If the sign in was successful or not
     */
    public void signInWithEmail(String email, String password, final Callback callback) {
        auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()  && auth.getCurrentUser().isEmailVerified()) {
                    // if the sign in succeeds
                    setUniversalUser(root.child("Users").child(auth.getCurrentUser().getUid()), callback);
                } else {
                    // if the sign in fails

                    callback.loginFailed();
                }
            }
        });

    }

    /**
     * This method will start an activity that will open the Google picker, this method should be used in tandem with onResult
     *
     * @param activity           The activity that this method is being called from
     * @param onConnectionFailed The activity that calls this method should implement this method
     * @param statusCode         The activity result status code
     */
    public void signInWithGoogle(Activity activity, GoogleApiClient.OnConnectionFailedListener onConnectionFailed, final int statusCode) {

        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(getGoogleApiClient(activity, onConnectionFailed));
        activity.startActivityForResult(signInIntent, statusCode);
    }


    /**
     * This method should be called in the onResult method in the activity that it is being called from
     * todo change the method name when you add facebook
     *
     * @param activity The activity that this method is being called from
     * @param data     the data from the intent that was returned from the result
     */
    public void onResult(Activity activity, final int resultCode, Intent data, Callback callback) {


        if (resultCode == SIGN_IN_GMAIL) {

            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            if (result.isSuccess()) {

                // Authenticate with firebase
                GoogleSignInAccount account = result.getSignInAccount();

                firebaseAuthWithGoogle(account, activity, callback);

            }

        }

    }

    /**
     * Returns a google api client object
     *
     * @param context A context must be given to this activity. Essentially this is the activity.
     * @param onConnectionFailedListener The activity must implement a connection failed listener. The activity can be passed so long as it implements the interface
     * @return GoogleAPIClient object that is create
     */
    private GoogleApiClient getGoogleApiClient(Context context, GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener) {


        /*
        Making a gso object
         */
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(context.getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        /*
        Making a connection to the google api client - this will fail if there is not internet
         */
        GoogleApiClient googleApiClient = new GoogleApiClient.Builder(context)
                .addOnConnectionFailedListener(onConnectionFailedListener)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();

        return googleApiClient;


    }


    private void firebaseAuthWithGoogle(final GoogleSignInAccount account,  final Activity activity, final Callback callback) {

        // get the credentials from the google acount
        AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
        // TODO: 19/03/2017 This causes an error 
        //auth.getCurrentUser().updateEmail(account.getEmail());


        // pass these credentials to firebase for a sign in
        auth.signInWithCredential(credential)
                .addOnCompleteListener(activity, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                       
                        // fail callback
                        if (!task.isSuccessful()) {
                            Toast.makeText(activity, "Login failed",
                                    Toast.LENGTH_LONG).show();
                            Log.d("Sign in google failed",task.getResult().toString());
                        } else{
			        // success callbackOB
				registerWithoutEmail(activity,auth.getCurrentUser().getUid(),callback);
			
			
			}
                    }
                });

    }


    public void onResultFacebook(AccessToken accessToken, final Activity activity, final Callback callback) {


            AuthCredential credential = FacebookAuthProvider.getCredential(accessToken.getToken());
            auth.signInWithCredential(credential)
                    .addOnCompleteListener(activity, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            // If sign in fails, display a message to the user. If sign in succeeds
                            // the auth state listener will be notified and logic to handle the
                            // signed in user can be handled in the listener.
                            if (!task.isSuccessful()) {
                                Toast.makeText(activity, "Login failed",
                                        Toast.LENGTH_LONG).show();
                                Log.d("Sign in with fb failed", task.getResult().toString());

                            } else {

                                registerWithoutEmail(activity, auth.getCurrentUser().getUid(), callback);
                            }

                        }
                    });



    }

    private void registerWithoutEmail(final Activity activity, String uid, final Callback callback){

        // get a ref to the the Users
        usersRef.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.getValue() != null){
                    setUniversalUser(root.child("Users").child(auth.getCurrentUser().getUid()), callback);
                }
                else{
                    callback.loginFailed();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }


    /**
     *
     * Sets the universal user for this application that can be accessed from anywhere
     * @param reference The reference for the user
     * @param callback The method to be "called back" when the work in this method is done
     */
    public void setUniversalUser(DatabaseReference reference, final Callback callback) {

        if (currentUser == null) {

            reference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    if(dataSnapshot.getValue() ==null){
                        callback.loginFailed();
                        return;
                    }

                    // casting the objects to all three types to avoid class cast exception
                    User user = dataSnapshot.getValue(User.class);
                    Bartender bartender = dataSnapshot.getValue(Bartender.class);
                    Organiser organiser = dataSnapshot.getValue(Organiser.class);

                    if (user.getUserType() == UserType.BARTENDER) {

                        currentUser = bartender;

                    } else {

                        currentUser = organiser;
                    }

                    callback.loginSuccessful();
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                    Log.v("noConnectionError", databaseError.toString());
                    callback.loginFailed();

                }
            });


        }else {
            callback.loginFailed();
        }


    }

    /**
     * Removes a value from the database
     *
     * @param databaseReference The databaseReference to be removed
     */
    public void removeValue(@NonNull DatabaseReference databaseReference) {

        databaseReference.removeValue();


    }


    /**
     * This is just a wrapper for FirebaseAuth.getInstance().getCurrentUser().getuid()
     *
     * @return The uid of the person signed in
     * @throws IllegalStateException If the user is somehow in the app without being signed in -- throw this error
     */
    public String getUserUid()  {

        String returnedUid = auth.getCurrentUser().getUid();
        if (returnedUid == null) {
            return  null;
        }
        return returnedUid;

    }

    /**
     * The really bas way
     * @param object
     * @param id
     */
    public void setValue(Object object,@NonNull String table,@NonNull String id){

        root.child(table).child(id).setValue(object);

    }

    public void createNewUserInDB(UserType userType, String email, Callback callback){
        if(userType == UserType.BARTENDER){
            // get the uid
            String uid = auth.getCurrentUser().getUid();

            User user = new Bartender("", "", email, uid);

            user.setUserType(UserType.BARTENDER);

            usersRef.child(uid).setValue(user);


            authorised = true;

            setUniversalUser(root.child("Users").child(auth.getCurrentUser().getUid()), callback);

        }else{
            // get the uid
            String uid = auth.getCurrentUser().getUid();

            User user = new Organiser("", "", email, uid);

            user.setUserType(UserType.ORGANISER);

            usersRef.child(uid).setValue(user);

            authorised = true;

            setUniversalUser(root.child("Users").child(auth.getCurrentUser().getUid()), callback);
        }
    }

    public boolean loggedInViaFB(){
        if(auth.getCurrentUser().getProviders().get(0).equals("facebook.com"))
            return true;
        return false;
    }

    public void addContact(String userUid, String userName, String contactUid, String contactName){

        DatabaseReference firebaseDatabaseRef = FirebaseDatabase.getInstance().getReference();

        DatabaseReference one = firebaseDatabaseRef.child("Contacts").child(userUid).child(contactUid);
        DatabaseReference two = firebaseDatabaseRef.child("Contacts").child(contactUid).child(userUid);

        one.child("UID").setValue(contactUid);
        one.child("name").setValue(contactName);
        one.child("chatLength").setValue(0);

        two.child("UID").setValue(userUid);
        two.child("name").setValue(userName);
        two.child("chatLength").setValue(0);
    }

    public void instantiateLocalDB(Context context){

        DBWriter writer = new DBWriter(context);

        try{
            writer.execute(currentUser,new DBCallback() {
                @Override
                public void callBack(Object object) {
                    Log.v("db_written", object.toString());
                }
            });
        }catch (Exception e){
            Log.v("db_write", e.getMessage());
        }

    }

    public void getUser(String uid, final OrganiserCallback callback){

        root.child("Users").child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.getValue() ==null){
                    //callback.loginFailed();
                    return;
                }
                Organiser organiser = dataSnapshot.getValue(Organiser.class);
                callback.provideUser(organiser);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.v("noConnectionError", databaseError.toString());
            }
        });


    }

    public void pushNotification(){

        new MessagingAsync().execute(FirebaseInstanceId.getInstance().getToken()
                ,FirebaseAuth.getInstance().getCurrentUser().getUid());

    }

}


