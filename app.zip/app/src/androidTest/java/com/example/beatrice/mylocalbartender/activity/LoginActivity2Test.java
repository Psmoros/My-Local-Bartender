/*package com.example.beatrice.mylocalbartender.activity;


import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import com.example.beatrice.mylocalbartender.R;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.pressBack;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.pressImeActionButton;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withHint;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class LoginActivity2Test {

    @Rule
    public ActivityTestRule<LoginActivity1> mActivityTestRule = new ActivityTestRule<>(LoginActivity1.class);

    @Test
    public void loginActivity2Test() {

        // Action to go to LoginActivity2 from LoginActivity1
        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.sign_in_Email), withText("Sign In"),
                        withParent(allOf(withId(R.id.activity_login1),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton.perform(click());


        // Checks email field editText hint
        onView(withId(R.id.emailField)).check(matches(withHint("Enter email")));


        // Checks inputted text in email field
        ViewInteraction appCompatEditText = onView(
                allOf(withId(R.id.emailField),
                        withParent(allOf(withId(R.id.activity_login2),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatEditText.perform(replaceText("test@hotmail.com"), closeSoftKeyboard());

        onView(withId(R.id.emailField)).check(matches(withText("test@hotmail.com")));


        // Checks password field editText hint
        onView(withId(R.id.passwordField)).check(matches(withHint("PASSWORD")));


        // Checks inputted text in password field
        ViewInteraction appCompatEditText2 = onView(
                allOf(withId(R.id.passwordField),
                        withParent(allOf(withId(R.id.activity_login2),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatEditText2.perform(replaceText("test"), closeSoftKeyboard());

        ViewInteraction appCompatEditText3 = onView(
                allOf(withId(R.id.passwordField), withText("test"),
                        withParent(allOf(withId(R.id.activity_login2),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatEditText3.perform(pressImeActionButton());


        // Checks password field has correct input
        onView(withId(R.id.passwordField)).check(matches(withText("test")));


        // Checks imageviews are shown
        onView(withId(R.id.imageView4)).check(matches(isDisplayed()));
        onView(withId(R.id.imageView5)).check(matches(isDisplayed()));
        onView(withId(R.id.imageView10)).check(matches(isDisplayed()));


        // Checks inputted text in password field
        ViewInteraction appCompatButton2 = onView(
                allOf(withId(R.id.sign_in), withText("Sign In"),
                        withParent(allOf(withId(R.id.activity_login2),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton2.perform(click());


        // Checks Sign in button is shown
        onView(withId(R.id.activity_login2)).check(matches(isDisplayed()));

        pressBack();

    }
}*/
