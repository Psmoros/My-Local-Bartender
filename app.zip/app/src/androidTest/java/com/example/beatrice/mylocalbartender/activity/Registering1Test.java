package com.example.beatrice.mylocalbartender.activity;


import android.support.test.espresso.ViewInteraction;
import android.support.test.espresso.matcher.ViewMatchers;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.example.beatrice.mylocalbartender.R;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.pressBack;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.isEnabled;
import static android.support.test.espresso.matcher.ViewMatchers.withEffectiveVisibility;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.allOf;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class Registering1Test {

    @Rule
    public ActivityTestRule<Registering1> mActivityTestRule = new ActivityTestRule<>(Registering1.class);

    @Test
    public void registering1Test() {

        // Checks correct text and logos are shown
        onView(withId(R.id.who_are_you)).check(matches(withText("Who are you ?")));
        onView(withId(R.id.imageView14)).check(matches(isDisplayed()));
        onView(withId(R.id.imageView15)).check(matches(isDisplayed()));


        // Checks bartender icon is clickable
        ViewInteraction appCompatImageButton = onView(
                allOf(withId(R.id.bartender_image_button),
                        withParent(allOf(withId(R.id.activity_registering1),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatImageButton.perform(click());


        // Checks text shows up when bartender icon is clicked
        onView(withId(R.id.user_type)).check(matches(withText("I am a Bartender")));
        onView(withId(R.id.organiser_glow_divider)).check(matches(isDisplayed()));


        // Checks organiser icon is clickable
        ViewInteraction appCompatImageButton2 = onView(
                allOf(withId(R.id.organiser_image_button),
                        withParent(allOf(withId(R.id.activity_registering1),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatImageButton2.perform(click());


        // Checks text shows up when organiser icon is clicked
        onView(withId(R.id.user_type)).check(matches(withText("I am an Organiser")));
        onView(withId(R.id.bartender_glow_divider)).check(matches(isDisplayed()));


        // Checks next button is clickable
        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.next_button), withText("Next"),
                        withParent(allOf(withId(R.id.activity_registering1),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton.perform(click());

        pressBack();

    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }
}
