package com.example.beatrice.mylocalbartender.activity;


import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import com.example.beatrice.mylocalbartender.R;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.pressBack;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.pressImeActionButton;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class Registering2Test {

    @Rule
    public ActivityTestRule<Registering2> mActivityTestRule = new ActivityTestRule<>(Registering2.class);

    @Test
    public void registering3Test() {

        // Checks if logo and text are shown
        onView(withId(R.id.textView2)).check(matches(withText("Welcome")));
        onView(withId(R.id.logo)).check(matches(isDisplayed()));
        onView(withId(R.id.imageView2)).check(matches(isDisplayed()));
        onView(withId(R.id.imageView4)).check(matches(isDisplayed()));
        onView(withId(R.id.imageView5)).check(matches(isDisplayed()));


        // Checks edit text boxes are shown
        onView(withId(R.id.firstNameField)).check(matches(isDisplayed()));
        onView(withId(R.id.lastNameField)).check(matches(isDisplayed()));
        onView(withId(R.id.emailField)).check(matches(isDisplayed()));
        onView(withId(R.id.passwordField)).check(matches(isDisplayed()));
        onView(withId(R.id.confirmPasswordField)).check(matches(isDisplayed()));
        onView(withId(R.id.sign_up_button)).check(matches(isDisplayed()));
        

        // Checks process of inputting information
        ViewInteraction appCompatEditText = onView(
                allOf(withId(R.id.firstNameField),
                        withParent(allOf(withId(R.id.activity_registering3),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatEditText.perform(replaceText("Test"), closeSoftKeyboard());

        ViewInteraction appCompatEditText2 = onView(
                allOf(withId(R.id.lastNameField),
                        withParent(allOf(withId(R.id.activity_registering3),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatEditText2.perform(replaceText("ing"), closeSoftKeyboard());

        ViewInteraction appCompatEditText3 = onView(
                allOf(withId(R.id.lastNameField), withText("ing"),
                        withParent(allOf(withId(R.id.activity_registering3),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatEditText3.perform(pressImeActionButton());

        ViewInteraction appCompatEditText4 = onView(
                allOf(withId(R.id.emailField),
                        withParent(allOf(withId(R.id.activity_registering3),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatEditText4.perform(replaceText("test@hotmail.com"), closeSoftKeyboard());

        ViewInteraction appCompatEditText5 = onView(
                allOf(withId(R.id.emailField), withText("test@hotmail.com"),
                        withParent(allOf(withId(R.id.activity_registering3),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatEditText5.perform(pressImeActionButton());

        ViewInteraction appCompatEditText6 = onView(
                allOf(withId(R.id.passwordField),
                        withParent(allOf(withId(R.id.activity_registering3),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatEditText6.perform(replaceText("test"), closeSoftKeyboard());

        ViewInteraction appCompatEditText7 = onView(
                allOf(withId(R.id.passwordField), withText("test"),
                        withParent(allOf(withId(R.id.activity_registering3),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatEditText7.perform(pressImeActionButton());

        ViewInteraction appCompatEditText8 = onView(
                allOf(withId(R.id.confirmPasswordField),
                        withParent(allOf(withId(R.id.activity_registering3),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatEditText8.perform(replaceText("test"), closeSoftKeyboard());

        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.sign_up_button), withText("Sign Up"),
                        withParent(allOf(withId(R.id.activity_registering3),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatButton.perform(click());

        ViewInteraction appCompatImageButton = onView(
                allOf(withId(R.id.signup_back_button),
                        withParent(allOf(withId(R.id.activity_registering3),
                                withParent(withId(android.R.id.content)))),
                        isDisplayed()));
        appCompatImageButton.perform(click());

    }

}
